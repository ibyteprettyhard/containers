/****************************************************************/
/* Version: 17.2                                           */
/* File   : client_app2.c                                           */
/* Changed: 5/28/97                                           */
/****************************************************************/
/* Rick Christiansen 5/24/95 Added non-named pipes  V1.2 */
#include <stdio.h>
#include <unistd.h>	/* Added for RS/6000 */
#include <string.h>

#include <randcurses.h>    /*   SA 6/16/94 */

#include <ctype.h>  /* To use isalpha functions */
#include <fcntl.h>  /* To use open() call */
#include <errno.h>  /* To use errno returns from reads and writes */
#include <sys/types.h>
#include <sys/times.h>

#include <keys.h>   /* Function key definition header file */
#define DEFINE_HERE
#include <paint_menu.h>
#include <mm_var.h>
#include <envname.h>
#undef DEFINE_HERE

/* #define DEBUG */

#ifdef DEBUG
#define D(x) x
#else
#define D(x)
#endif

#ifdef HPUX
#define NOTIMES
#endif

#ifdef SOLARIS
#define NOTIMES
#endif

/* Removed Start Block V1.2
#ifndef CLIENT_LOG_PATH
# define	CLIENT_LOG_PATH	"/usr/micro/g19/data/request.log" 
#endif CLIENT_LOG_PATH
   Removed End Block V1.2 */

/* Terminal/keyboard emulation functions */
int get_input();
int get_input_ansi();
int get_input_att705();
int get_input_ibm3151();
int get_input_vt100();
int get_input_vt220();
int get_input_wyse50();
int get_input_wyse60();
int get_input_wyse370();
int get_input_suncmd();
char	*TERM;            	/* Terminal emulation run by user */
int term_screen_type = 0;
int process_input();
int process_input_53();
extern	void get_env();
int checkconfig();

char	PRESSKEY[]  =	"Press Any Key to Continue";
char	user_rqst;
FILE	*log_ptr;
int	return_code;
int hhg48_enable;

/* The following structure is for formatted ACA requests */
typedef struct req_struct 
{
    char rec_type[2];

    union  
    {
	struct trailer_record
	{
	    char trailer_length[2];
	} trailer_rec;

	struct header_record
	{
	    char req_type[2];
	    char opt_num[2];
	    char header_info[18];
	} hdr_rec;

	struct point_info
	{
            char city[18];
	    char cnty[2];
	    char state[2];
	} city_info;
    } rec_u;
} REQ_STRUCT;

/* The following structure is for answers to ACA requests */
typedef struct ans_struct 
{
    char rec_type[2];		/* Record type */

    struct point
    {
	char city1[18];		/* Origin city */
	char cnty1[2];		/* Origin county */
	char state1[2];		/* Origin state */
	char city2[18];		/* Destination city */
	char cnty2[2];		/* Destination county */
	char state2[2];		/* Destination state */
    } city_info;
    char miles[4];		/* Mileage between cities */
} ANS_STRUCT;

/* Union to simplify putting together requests */
typedef union request_union
{
    char request[25];
    REQ_STRUCT req_struct;
}REQ_U;

/* Union to simplify access to response records */
typedef union answer_union
{
    char ans_rec[72];
    ANS_STRUCT ans_struct;
}ANS_U;

ANS_U	ans_buf;		/* Buffer for formatted ACA responses. */
char	out_buf[sizeof(union request_union)];	/* ACA request records */
char	mybuf[72];		/* Buffer for raw ACA responses */
int	to_aca;		/* File descriptor for sending requests to ACA */
int	from_aca;	/* File descriptor for reading ACA responses */
int     aca_named_pipes = TRUE;  /* V1.2 */

main(argc, argv)   /* V1.2 */
int argc;          /* V1.2 */
char *argv[];      /* V1.2 */
{

    /* Screen drawing functions */
    initscr();
    nonl();
    raw();
    noecho();

    get_env();
    TERM = getenv ("TERM\0");

    log_ptr = fopen(CLIENT_LOG_PATH, "w");
    if (log_ptr == NULL)
    {
	printf("BAD open(%s)\n", CLIENT_LOG_PATH);
        sleep (3);
    }
    else
    {
       D(fprintf(log_ptr, "GOOD fopen(%s)\n", CLIENT_LOG_PATH);)
    }
    D(fflush(log_ptr);)

   hhg48_enable = checkconfig(); 

    /* Start Block V1.2 */
    if (argc == 3)                
    {                             
        aca_named_pipes = FALSE;  
        to_aca = atoi(argv[1]);
        from_aca = atoi(argv[2]);
    }                             
    else
    {
       D(fprintf(log_ptr, "BEFORE open(to_server)\n");)
       D(fflush(log_ptr);)
       to_aca = open(NAMED_PIPE_TO_SERVER, O_WRONLY);	/* TO ACA */
       D(fprintf(log_ptr, "to_aca %d\n", to_aca);)
       D(fflush(log_ptr);)

       from_aca = open(NAMED_PIPE_FROM_SERVER, O_RDONLY);/* FROM ACA */
       D(fprintf(log_ptr, "from_aca %d\n", from_aca);)
       D(fflush(log_ptr);)
    }
    /* End Block V1.2 */

    paint_scrn(MAIN_MENU);
    D(fprintf(log_ptr, "After paint_scrn(MAIN_MENU)\n");)
    D(fflush(log_ptr);)
    move(0, 0);
    refresh();
    user_rqst = get_input();
    while (user_rqst != F2)
    {
	D(fprintf(log_ptr, "KEY %d <%c>\n", user_rqst, user_rqst);)
	D(fflush(log_ptr);)
	user_rqst = user_rqst;
	switch (user_rqst)
	{
	    case F1:
		D(fprintf(log_ptr, "Input F1 request\n");)
		D(fflush(log_ptr);)
		paint_scrn(GEO_INQ);
		D(fprintf(log_ptr, "AFTER paint_scrn(GEO_INQ)\n");)
		D(fflush(log_ptr);)

                if (hhg48_enable)
		   return_code = process_input(user_rqst);
                else
		   return_code = process_input_53(user_rqst);
		D(fprintf(log_ptr, "process_input(user_rqst) ");)
		D(fprintf(log_ptr, "RC %d\n", return_code);)
		D(fflush(log_ptr);)

		paint_scrn(MAIN_MENU);
		D(fprintf(log_ptr, "AFTER paint_scrn(MAIN_MENU)\n");)
		D(fflush(log_ptr);)

		refresh();
		break;

	    default:
		D(fprintf(log_ptr, "Input NON-F1 user_rqst %d\n", user_rqst);)
		D(fflush(log_ptr);)
		break;
	}
	user_rqst = get_input();
    }
    D(fprintf(log_ptr, "<-- EXITING main()\n");)
    D(fflush(log_ptr);)
    clear();
    refresh();
    close(log_ptr);
    endwin();
}


int process_input(pf_key)
char pf_key;
{
    int cur_row, cur_col;
    int pos_row, pos_col;
    char in_char;
    short i, in_cnt;

    memset(in_city1, SPACE, sizeof(in_city1));
    memset(in_cnty1, SPACE, sizeof(in_cnty1));
    memset(in_state1, SPACE, sizeof(in_state1));
    memset(in_city2, SPACE, sizeof(in_city2));
    memset(in_cnty2, SPACE, sizeof(in_cnty2));
    memset(in_state2, SPACE, sizeof(in_state2));
    memset(in_city3, SPACE, sizeof(in_city3));
    memset(in_cnty3, SPACE, sizeof(in_cnty3));
    memset(in_state3, SPACE, sizeof(in_state3));
    memset(in_city4, SPACE, sizeof(in_city4));
    memset(in_cnty4, SPACE, sizeof(in_cnty4));
    memset(in_state4, SPACE, sizeof(in_state4));
    memset(trailer_length, SPACE, sizeof(trailer_length));
    in_cnt = 0;
    pos_row = cur_row = CITY1_ROW;
    pos_col = cur_col = CITY_COL;
    move(cur_row, cur_col);
    refresh();

    in_char = get_input();
    D(fprintf(log_ptr, "KEY in process_user_rqst %d\n", in_char);)
    D(fflush(log_ptr);)
    while (in_char != F4)
    {
	switch (in_char)
	{
	    case F1:
	    case F2:
	    case F5:
	    case F6:
	    case F7:
	    case F8:
	    case F9:
	    case PAGE_UP:
	    case PAGE_DOWN:
	    case INS:
	    case ESC:
	    case DEL:
	    case FIVE_KEY:
		D(fprintf(log_ptr, "UNUSED Fkeys, HOME, END or DEL\n");)
		D(fflush(log_ptr);)
		break;

	    case PRNT_SCRN:
		D(fprintf(log_ptr, "PRNT_SCRN\n");)
		D(fflush(log_ptr);)
		break;

	    case CAR_RETURN:
		D(fprintf(log_ptr, "CAR_RETURN\n");)
		D(fflush(log_ptr);)
		return_code = process_request();
		pos_row = cur_row = CITY1_ROW;
		pos_col = cur_col = CITY_COL;
		in_cnt = 0;
		move(cur_row, cur_col);
		refresh();
		break;
	    case F3:
		D(fprintf(log_ptr, "F3\n");)
		D(fflush(log_ptr);)
		memset(in_city1, SPACE, sizeof(in_city1));
		memset(in_cnty1, SPACE, sizeof(in_cnty1));
		memset(in_state1, SPACE, sizeof(in_state1));
		memset(in_city2, SPACE, sizeof(in_city2));
		memset(in_cnty2, SPACE, sizeof(in_cnty2));
		memset(in_state2, SPACE, sizeof(in_state2));
		memset(in_city3, SPACE, sizeof(in_city3));
		memset(in_cnty3, SPACE, sizeof(in_cnty3));
		memset(in_state3, SPACE, sizeof(in_state3));
		memset(in_city4, SPACE, sizeof(in_city4));
		memset(in_cnty4, SPACE, sizeof(in_cnty4));
		memset(in_state4, SPACE, sizeof(in_state4));
                memset(trailer_length, SPACE, sizeof(trailer_length));
		paint_scrn(GEO_INQ);
		D(fprintf(log_ptr, "AFTER paint_scrn(GEO_INQ)\n");)
		D(fflush(log_ptr);)
		in_cnt = 0;
		pos_row = cur_row = CITY1_ROW;
		pos_col = cur_col = CITY_COL;
		move(cur_row, cur_col);
		refresh();
		break;

	    case TAB_HORIZONTAL:
		D(fprintf(log_ptr, "TAB_HORIZONTAL pos_row %d\n", pos_row);)
		D(fflush(log_ptr);)
		switch (pos_row)
		{
		    case CITY1_ROW:
			if (pos_col == CITY_COL)
			{
			    pos_col = cur_col = CNTY_COL;
			}
			else if (pos_col == CNTY_COL)
			{
			    pos_col = cur_col = STATE_COL;
			}
			else
			{
			    pos_col = cur_col = CITY_COL;
			    pos_row = cur_row = CITY2_ROW;
			}
			break;
		    case CITY2_ROW:
			if (pos_col == CITY_COL)
			{
			    pos_col = cur_col = CNTY_COL;
			}
			else if (pos_col == CNTY_COL)
			{
			    pos_col = cur_col = STATE_COL;
			}
			else
			{
			    pos_col = cur_col = CITY_COL;
			    pos_row = cur_row = CITY3_ROW;
			}
			break;
		    case CITY3_ROW:
			if (pos_col == CITY_COL)
			{
			    pos_col = cur_col = CNTY_COL;
			}
			else if (pos_col == CNTY_COL)
			{
			    pos_col = cur_col = STATE_COL;
			}
			else
			{
			    pos_col = cur_col = CITY_COL;
			    pos_row = cur_row = CITY4_ROW;
			}
			break;
		    case CITY4_ROW:
			if (pos_col == CITY_COL)
			{
			    pos_col = cur_col = CNTY_COL;
			}
			else if (pos_col == CNTY_COL)
			{
			    pos_col = cur_col = STATE_COL;
			}
			else
			{
			    pos_col = cur_col = TYPE_COL;
			    pos_row = cur_row = TYPE_ROW;
			}
			break;
		    case TYPE_ROW:
			pos_col = cur_col = TRAILER_COL;
			pos_row = cur_row = TRAILER_ROW;
			break;
		    case TRAILER_ROW:
			pos_col = cur_col = CITY_COL;
			pos_row = cur_row = CITY1_ROW;
			break;
		}  /* switch(pos_row) */ 
		D(fprintf(log_ptr, "AFTER TAB_HORIZONTAL switch\n");)
		D(fflush(log_ptr);)
		in_cnt = 0;
		move(cur_row, cur_col);
		refresh();
		break;

	    case CURSOR_LEFT:
	    case BACKSPACE:
		switch(pos_col)
		{
		    case CITY_COL:
			if(in_cnt == 0)
			{
			    pos_col = STATE_COL;
			    cur_col = STATE_COL + 1;
			    in_cnt = 1;
			    if(cur_row == CITY1_ROW)
			    {
				pos_row = cur_row = TYPE_ROW;
				pos_col = TRAILER_COL;
				cur_col = TRAILER_COL + 1;
			    }
			    else if(cur_row == CITY2_ROW)
			    {
				cur_row = pos_row = CITY1_ROW;
			    }
			    else if(cur_row == CITY3_ROW)
			    {
				cur_row = pos_row = CITY2_ROW;
			    }
			    else
			    {
				cur_row = pos_row = CITY3_ROW;
			    }
			}
			else
			{
			    cur_col--;
			    in_cnt--;
			}
			break;

		    case CNTY_COL:
			if(in_cnt == 0)
			{
			    pos_col = CITY_COL;
			    cur_col = CITY_COL + 17;
			    in_cnt = 17;
			}
			else
			{
			    cur_col--;
			    in_cnt--;
			}
			break;

		    case STATE_COL:
			if(in_cnt == 0)
			{
			    pos_col = CNTY_COL;
			    cur_col = CNTY_COL + 1;
			    in_cnt = 1;
			}
			else
			{
			    cur_col--;
			    in_cnt--;
			}
			break;

		    case TYPE_COL:
			if(in_cnt == 0)
			{
			    pos_col = STATE_COL;
			    cur_col = STATE_COL + 1;
			    pos_row = cur_row = CITY4_ROW;
			    in_cnt = 1;
			}
			else
			{
			    cur_col--;
			    in_cnt--;
			}
			break;

		    case TRAILER_COL:
			if(in_cnt == 0)
			{
			    pos_col = TYPE_COL;
			    cur_col = TYPE_COL + 1;
			    pos_row = cur_row = TYPE_ROW;
			    in_cnt = 1;
			}
			else
			{
			    cur_col--;
			    in_cnt--;
			}
			break;

		    default:
			break;
		}
		move(cur_row, cur_col);
		refresh();
		break;
	    /* END BACKSPACE */

	    case HOME:
		pos_row = cur_row = CITY1_ROW;
		pos_col = cur_col = CITY_COL;
		in_cnt = 0;
		move(cur_row, cur_col);
		refresh();
		break;

	    case END:
		pos_row = cur_row = TRAILER_ROW;
		pos_col = TRAILER_COL;
		cur_col = TRAILER_COL + 1;
		in_cnt = 1;
		move(cur_row, cur_col);
		refresh();
		break;

	    case CURSOR_UP:
		if(pos_row == TRAILER_ROW)
		{
		    pos_row = cur_row = TYPE_ROW;
		    cur_col = pos_col = TYPE_COL;
		    in_cnt = 0;
		}
		else if(pos_row == TYPE_ROW)
		{
		    pos_row = cur_row = CITY4_ROW;
		    cur_col = pos_col = CITY_COL;
		    in_cnt = 0;
		}
		else if(pos_row == CITY1_ROW)
		{
		    pos_row = cur_row = TRAILER_ROW;
		    cur_col = pos_col = TRAILER_COL;
		    in_cnt = 0;
		}
		else
		{
		    pos_row--;
		    cur_row--;
		}
		move(cur_row, cur_col);
		refresh();
		break;

	    case CURSOR_DOWN:
		if(pos_row == TRAILER_ROW)
		{
		    pos_row = cur_row = CITY1_ROW;
		    cur_col = pos_col = CITY_COL;
		    in_cnt = 0;
		}
		else if(pos_row == TYPE_ROW)
		{
		    pos_row = cur_row = TRAILER_ROW;
		    cur_col = pos_col = TRAILER_COL;
		    in_cnt = 0;
		}
		else if(pos_row == CITY4_ROW)
		{
		    pos_row = cur_row = TYPE_ROW;
		    cur_col = pos_col = TYPE_COL;
		    in_cnt = 0;
		}
		else
		{
		    pos_row++;
		    cur_row++;
		}
		move(cur_row, cur_col);
		refresh();
		break;

	    case CURSOR_RIGHT:
		switch(pos_col)
		{
		    case CITY_COL:
			if(in_cnt == 17)
			{
			    pos_col = cur_col = CNTY_COL;
			    in_cnt = 0;
			}
			else
			{
			    cur_col++;
			    in_cnt++;
			}
			break;

		    case CNTY_COL:
			if(in_cnt == 1)
			{
			    pos_col = cur_col = STATE_COL;
			    in_cnt = 0;
			}
			else
			{
			    cur_col++;
			    in_cnt++;
			}
			break;

		    case STATE_COL:
			if(in_cnt == 1)
			{
			    in_cnt = 0;
			    if(pos_row == CITY4_ROW)
			    {
				pos_col = cur_col = TYPE_COL;
				pos_row = cur_row = TYPE_ROW;
			    }
			    else
			    {
				pos_col = cur_col = CITY_COL;
				pos_row++;
				cur_row++;
			    }
			}
			else
			{
			    in_cnt++;
			    cur_col++;
			}
			break;

		    case TYPE_COL:
			if(in_cnt == 1)
			{
			    pos_col = cur_col = TRAILER_COL;
			    pos_row = cur_row = TRAILER_ROW;
			    in_cnt = 0;
			}
			else
			{
			    cur_col++;
			    in_cnt++;
			}
			break;

		    case TRAILER_COL:
			if(in_cnt == 1)
			{
			    pos_col = cur_col = CITY_COL;
			    pos_row = cur_row = CITY1_ROW;
			    in_cnt = 0;
			}
			else
			{
			    cur_col++;
			    in_cnt++;
			}
			break;

		    default:
			break;
		}
		move(cur_row, cur_col);
		refresh();
		break;

	    case 0x1d /* Decimal 29 or BACKTAB */:
		switch(pos_col)
		{
		    case CITY_COL:
			if(in_cnt > 0)
			{
			    cur_col = pos_col;
			}
			else if (pos_row == CITY1_ROW)
			{
			    cur_col = pos_col = TYPE_COL;
			    cur_row = pos_row = TYPE_ROW;
			}
			else
			{
			    cur_row--;
			    pos_row--;
			    cur_col = pos_col = STATE_COL;
			}
			in_cnt = 0;
			break;

		    case CNTY_COL:
			if(in_cnt > 0)
			{
			    cur_col = pos_col;
			}
			else
			{
			    cur_col = pos_col = CITY_COL;
			}
			in_cnt = 0;
			break;

		    case STATE_COL:
			if(in_cnt > 0)
			{
			    cur_col = pos_col;
			}
			else
			{
			    cur_col = pos_col = CNTY_COL;
			}
			in_cnt = 0;
			break;

		    case TYPE_COL:
			if(in_cnt > 0)
			{
			    cur_col = pos_col;
			}
			else
			{
			    cur_col = pos_col = STATE_COL;
			    cur_row = pos_row = CITY4_ROW;
			}
			in_cnt = 0;
			break;

		    case TRAILER_COL:
			if(in_cnt > 0)
			{
			    cur_col = pos_col;
			}
			else
			{
			    cur_col = pos_col = TYPE_COL;
			    cur_row = pos_row = TYPE_ROW;
			}
			in_cnt = 0;
			break;

		    default:
			break;
		}
		move(cur_row, cur_col);
		refresh();
		break;

	    default:	/* Typed a city/state/county character */
		D(fprintf(log_ptr, "default pos_row %d\n", pos_row);)
		D(fflush(log_ptr);)
		switch(pos_row)
		{
		    case CITY1_ROW:
		    if (pos_col == CITY_COL)
		    {
			in_city1[in_cnt] = toupper(in_char);
			addch(in_city1[in_cnt]);
			in_cnt++;
			if (in_cnt == 18)
			{
			    cur_col = pos_col = CNTY_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    else if (pos_col == CNTY_COL)
		    {
			in_cnty1[in_cnt] = toupper(in_char);
			addch(in_cnty1[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = STATE_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    else
		    {
			in_state1[in_cnt] = toupper(in_char);
			addch(in_state1[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = CITY_COL;
			    cur_row = pos_row = CITY2_ROW;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    break;
		case CITY2_ROW:
		    if (pos_col == CITY_COL)
		    {
			in_city2[in_cnt] = toupper(in_char);
			addch(in_city2[in_cnt]);
			in_cnt++;
			if (in_cnt == 18)
			{
			    cur_col = pos_col = CNTY_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    else if (pos_col == CNTY_COL)
		    {
			in_cnty2[in_cnt] = toupper(in_char);
			addch(in_cnty2[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = STATE_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    else
		    {
			in_state2[in_cnt] = toupper(in_char);
			addch(in_state2[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = CITY_COL;
			    cur_row = pos_row = CITY3_ROW;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    break;
		case CITY3_ROW:
		    if (pos_col == CITY_COL)
		    {
			in_city3[in_cnt] = toupper(in_char);
			addch(in_city3[in_cnt]);
			in_cnt++;
			if (in_cnt == 18)
			{
			    cur_col = pos_col = CNTY_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    else if (pos_col == CNTY_COL)
		    {
			in_cnty3[in_cnt] = toupper(in_char);
			addch(in_cnty3[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = STATE_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    else
		    {
			in_state3[in_cnt] = toupper(in_char);
			addch(in_state3[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = CITY_COL;
			    cur_row = pos_row = CITY4_ROW;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    break;
		case CITY4_ROW:
		    if (pos_col == CITY_COL)
		    {
			in_city4[in_cnt] = toupper(in_char);
			addch(in_city4[in_cnt]);
			in_cnt++;
			if (in_cnt == 18)
			{
			    cur_col = pos_col = CNTY_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    else if (pos_col == CNTY_COL)
		    {
			in_cnty4[in_cnt] = toupper(in_char);
			addch(in_cnty4[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = STATE_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
			}
			else
			{
			    in_state4[in_cnt] = toupper(in_char);
			    addch(in_state4[in_cnt]);
			    in_cnt++;
			    if (in_cnt == 2)
			    {
				cur_col = pos_col = TYPE_COL;
				cur_row = pos_row = TYPE_ROW;
				in_cnt = 0;
			    }
			    else
				cur_col++;
			}
			break;

		    case TYPE_ROW:
			request[in_cnt] = toupper(in_char);
			addch(request[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = TRAILER_COL;
			    cur_row = pos_row = TRAILER_ROW;
			    in_cnt = 0;
			}
			else
			    cur_col++;
			break;

		    case TRAILER_ROW:
			trailer_length[in_cnt] = in_char;
			addch(trailer_length[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = CITY_COL;
			    cur_row = pos_row = CITY1_ROW;
			    in_cnt = 0;
			}
			else
			    cur_col++;
			break;

		}  /* switch(pos_row) */
		move(cur_row, cur_col);
		refresh();
		break;
	} /* switch (in_char) */
	in_char = get_input();
    }  /* while*/
    return(0);
} /* int process_input(pf_key) */


int process_input_53(pf_key)
char pf_key;
{
    int cur_row, cur_col;
    int pos_row, pos_col;
    char in_char;
    short i, in_cnt;

    memset(in_city1, SPACE, sizeof(in_city1));
    memset(in_cnty1, SPACE, sizeof(in_cnty1));
    memset(in_state1, SPACE, sizeof(in_state1));
    memset(in_city2, SPACE, sizeof(in_city2));
    memset(in_cnty2, SPACE, sizeof(in_cnty2));
    memset(in_state2, SPACE, sizeof(in_state2));
    memset(in_city3, SPACE, sizeof(in_city3));
    memset(in_cnty3, SPACE, sizeof(in_cnty3));
    memset(in_state3, SPACE, sizeof(in_state3));
    memset(in_city4, SPACE, sizeof(in_city4));
    memset(in_cnty4, SPACE, sizeof(in_cnty4));
    memset(in_state4, SPACE, sizeof(in_state4));
    in_cnt = 0;
    pos_row = cur_row = CITY1_ROW;
    pos_col = cur_col = CITY_COL;
    move(cur_row, cur_col);
    refresh();

    in_char = get_input();
    D(fprintf(log_ptr, "KEY in process_user_rqst %d\n", in_char);)
    D(fflush(log_ptr);)
    while (in_char != F4)
    {
	switch (in_char)
	{
	    case F1:
	    case F2:
	    case F5:
	    case F6:
	    case F7:
	    case F8:
	    case F9:
	    case PAGE_UP:
	    case PAGE_DOWN:
	    case INS:
	    case ESC:
	    case DEL:
	    case FIVE_KEY:
		D(fprintf(log_ptr, "UNUSED Fkeys, HOME, END or DEL\n");)
		D(fflush(log_ptr);)
		break;

	    case PRNT_SCRN:
		D(fprintf(log_ptr, "PRNT_SCRN\n");)
		D(fflush(log_ptr);)
		break;

	    case CAR_RETURN:
		D(fprintf(log_ptr, "CAR_RETURN\n");)
		D(fflush(log_ptr);)
		return_code = process_request();
		pos_row = cur_row = CITY1_ROW;
		pos_col = cur_col = CITY_COL;
		in_cnt = 0;
		move(cur_row, cur_col);
		refresh();
		break;
	    case F3:
		D(fprintf(log_ptr, "F3\n");)
		D(fflush(log_ptr);)
		memset(in_city1, SPACE, sizeof(in_city1));
		memset(in_cnty1, SPACE, sizeof(in_cnty1));
		memset(in_state1, SPACE, sizeof(in_state1));
		memset(in_city2, SPACE, sizeof(in_city2));
		memset(in_cnty2, SPACE, sizeof(in_cnty2));
		memset(in_state2, SPACE, sizeof(in_state2));
		memset(in_city3, SPACE, sizeof(in_city3));
		memset(in_cnty3, SPACE, sizeof(in_cnty3));
		memset(in_state3, SPACE, sizeof(in_state3));
		memset(in_city4, SPACE, sizeof(in_city4));
		memset(in_cnty4, SPACE, sizeof(in_cnty4));
		memset(in_state4, SPACE, sizeof(in_state4));
		paint_scrn(GEO_INQ);
		D(fprintf(log_ptr, "AFTER paint_scrn(GEO_INQ)\n");)
		D(fflush(log_ptr);)
		in_cnt = 0;
		pos_row = cur_row = CITY1_ROW;
		pos_col = cur_col = CITY_COL;
		move(cur_row, cur_col);
		refresh();
		break;

	    case TAB_HORIZONTAL:
		D(fprintf(log_ptr, "TAB_HORIZONTAL pos_row %d\n", pos_row);)
		D(fflush(log_ptr);)
		switch (pos_row)
		{
		    case CITY1_ROW:
			if (pos_col == CITY_COL)
			{
			    pos_col = cur_col = CNTY_COL;
			}
			else if (pos_col == CNTY_COL)
			{
			    pos_col = cur_col = STATE_COL;
			}
			else
			{
			    pos_col = cur_col = CITY_COL;
			    pos_row = cur_row = CITY2_ROW;
			}
			break;
		    case CITY2_ROW:
			if (pos_col == CITY_COL)
			{
			    pos_col = cur_col = CNTY_COL;
			}
			else if (pos_col == CNTY_COL)
			{
			    pos_col = cur_col = STATE_COL;
			}
			else
			{
			    pos_col = cur_col = CITY_COL;
			    pos_row = cur_row = CITY3_ROW;
			}
			break;
		    case CITY3_ROW:
			if (pos_col == CITY_COL)
			{
			    pos_col = cur_col = CNTY_COL;
			}
			else if (pos_col == CNTY_COL)
			{
			    pos_col = cur_col = STATE_COL;
			}
			else
			{
			    pos_col = cur_col = CITY_COL;
			    pos_row = cur_row = CITY4_ROW;
			}
			break;
		    case CITY4_ROW:
			if (pos_col == CITY_COL)
			{
			    pos_col = cur_col = CNTY_COL;
			}
			else if (pos_col == CNTY_COL)
			{
			    pos_col = cur_col = STATE_COL;
			}
			else
			{
			    pos_col = cur_col = TYPE_COL;
			    pos_row = cur_row = TYPE_ROW;
			}
			break;
		    case TYPE_ROW:
			pos_col = cur_col = CITY_COL;
			pos_row = cur_row = CITY1_ROW;
			break;
		}  /* switch(pos_row) */ 
		D(fprintf(log_ptr, "AFTER TAB_HORIZONTAL switch\n");)
		D(fflush(log_ptr);)
		in_cnt = 0;
		move(cur_row, cur_col);
		refresh();
		break;

	    case CURSOR_LEFT:
	    case BACKSPACE:
		switch(pos_col)
		{
		    case CITY_COL:
			if(in_cnt == 0)
			{
			    pos_col = STATE_COL;
			    cur_col = STATE_COL + 1;
			    in_cnt = 1;
			    if(cur_row == CITY1_ROW)
			    {
				pos_row = cur_row = TYPE_ROW;
				pos_col = TYPE_COL;
				cur_col = TYPE_COL + 1;
			    }
			    else if(cur_row == CITY2_ROW)
			    {
				cur_row = pos_row = CITY1_ROW;
			    }
			    else if(cur_row == CITY3_ROW)
			    {
				cur_row = pos_row = CITY2_ROW;
			    }
			    else
			    {
				cur_row = pos_row = CITY3_ROW;
			    }
			}
			else
			{
			    cur_col--;
			    in_cnt--;
			}
			break;

		    case CNTY_COL:
			if(in_cnt == 0)
			{
			    pos_col = CITY_COL;
			    cur_col = CITY_COL + 17;
			    in_cnt = 17;
			}
			else
			{
			    cur_col--;
			    in_cnt--;
			}
			break;

		    case STATE_COL:
			if(in_cnt == 0)
			{
			    pos_col = CNTY_COL;
			    cur_col = CNTY_COL + 1;
			    in_cnt = 1;
			}
			else
			{
			    cur_col--;
			    in_cnt--;
			}
			break;

		    case TYPE_COL:
			if(in_cnt == 0)
			{
			    pos_col = STATE_COL;
			    cur_col = STATE_COL + 1;
			    pos_row = cur_row = CITY4_ROW;
			    in_cnt = 1;
			}
			else
			{
			    cur_col--;
			    in_cnt--;
			}
			break;

		    default:
			break;
		}
		move(cur_row, cur_col);
		refresh();
		break;
	    /* END BACKSPACE */

	    case HOME:
		pos_row = cur_row = CITY1_ROW;
		pos_col = cur_col = CITY_COL;
		in_cnt = 0;
		move(cur_row, cur_col);
		refresh();
		break;

	    case END:
		pos_row = cur_row = TYPE_ROW;
		pos_col = TYPE_COL;
		cur_col = TYPE_COL + 1;
		in_cnt = 1;
		move(cur_row, cur_col);
		refresh();
		break;

	    case CURSOR_UP:
		if(pos_row == TYPE_ROW)
		{
		    pos_row = cur_row = CITY4_ROW;
		    cur_col = pos_col = CITY_COL;
		    in_cnt = 0;
		}
		else if(pos_row == CITY1_ROW)
		{
		    pos_row = cur_row = TYPE_ROW;
		    cur_col = pos_col = TYPE_COL;
		    in_cnt = 0;
		}
		else
		{
		    pos_row--;
		    cur_row--;
		}
		move(cur_row, cur_col);
		refresh();
		break;

	    case CURSOR_DOWN:
		if(pos_row == TYPE_ROW)
		{
		    pos_row = cur_row = CITY1_ROW;
		    cur_col = pos_col = CITY_COL;
		    in_cnt = 0;
		}
		else if(pos_row == CITY4_ROW)
		{
		    pos_row = cur_row = TYPE_ROW;
		    cur_col = pos_col = TYPE_COL;
		    in_cnt = 0;
		}
		else
		{
		    pos_row++;
		    cur_row++;
		}
		move(cur_row, cur_col);
		refresh();
		break;

	    case CURSOR_RIGHT:
		switch(pos_col)
		{
		    case CITY_COL:
			if(in_cnt == 17)
			{
			    pos_col = cur_col = CNTY_COL;
			    in_cnt = 0;
			}
			else
			{
			    cur_col++;
			    in_cnt++;
			}
			break;

		    case CNTY_COL:
			if(in_cnt == 1)
			{
			    pos_col = cur_col = STATE_COL;
			    in_cnt = 0;
			}
			else
			{
			    cur_col++;
			    in_cnt++;
			}
			break;

		    case STATE_COL:
			if(in_cnt == 1)
			{
			    in_cnt = 0;
			    if(pos_row == CITY4_ROW)
			    {
				pos_col = cur_col = TYPE_COL;
				pos_row = cur_row = TYPE_ROW;
			    }
			    else
			    {
				pos_col = cur_col = CITY_COL;
				pos_row++;
				cur_row++;
			    }
			}
			else
			{
			    in_cnt++;
			    cur_col++;
			}
			break;

		    case TYPE_COL:
			if(in_cnt == 1)
			{
			    pos_col = cur_col = CITY_COL;
			    pos_row = cur_row = CITY1_ROW;
			    in_cnt = 0;
			}
			else
			{
			    cur_col++;
			    in_cnt++;
			}
			break;

		    default:
			break;
		}
		move(cur_row, cur_col);
		refresh();
		break;

	    case 0x1d /* Decimal 29 or BACKTAB */:
		switch(pos_col)
		{
		    case CITY_COL:
			if(in_cnt > 0)
			{
			    cur_col = pos_col;
			}
			else if (pos_row == CITY1_ROW)
			{
			    cur_col = pos_col = TYPE_COL;
			    cur_row = pos_row = TYPE_ROW;
			}
			else
			{
			    cur_row--;
			    pos_row--;
			    cur_col = pos_col = STATE_COL;
			}
			in_cnt = 0;
			break;

		    case CNTY_COL:
			if(in_cnt > 0)
			{
			    cur_col = pos_col;
			}
			else
			{
			    cur_col = pos_col = CITY_COL;
			}
			in_cnt = 0;
			break;

		    case STATE_COL:
			if(in_cnt > 0)
			{
			    cur_col = pos_col;
			}
			else
			{
			    cur_col = pos_col = CNTY_COL;
			}
			in_cnt = 0;
			break;

		    case TYPE_COL:
			if(in_cnt > 0)
			{
			    cur_col = pos_col;
			}
			else
			{
			    cur_col = pos_col = STATE_COL;
			    cur_row = pos_row = CITY4_ROW;
			}
			in_cnt = 0;
			break;

		    default:
			break;
		}
		move(cur_row, cur_col);
		refresh();
		break;

	    default:	/* Typed a city/state/county character */
		D(fprintf(log_ptr, "default pos_row %d\n", pos_row);)
		D(fflush(log_ptr);)
		switch(pos_row)
		{
		    case CITY1_ROW:
		    if (pos_col == CITY_COL)
		    {
			in_city1[in_cnt] = toupper(in_char);
			addch(in_city1[in_cnt]);
			in_cnt++;
			if (in_cnt == 18)
			{
			    cur_col = pos_col = CNTY_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    else if (pos_col == CNTY_COL)
		    {
			in_cnty1[in_cnt] = toupper(in_char);
			addch(in_cnty1[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = STATE_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    else
		    {
			in_state1[in_cnt] = toupper(in_char);
			addch(in_state1[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = CITY_COL;
			    cur_row = pos_row = CITY2_ROW;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    break;
		case CITY2_ROW:
		    if (pos_col == CITY_COL)
		    {
			in_city2[in_cnt] = toupper(in_char);
			addch(in_city2[in_cnt]);
			in_cnt++;
			if (in_cnt == 18)
			{
			    cur_col = pos_col = CNTY_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    else if (pos_col == CNTY_COL)
		    {
			in_cnty2[in_cnt] = toupper(in_char);
			addch(in_cnty2[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = STATE_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    else
		    {
			in_state2[in_cnt] = toupper(in_char);
			addch(in_state2[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = CITY_COL;
			    cur_row = pos_row = CITY3_ROW;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    break;
		case CITY3_ROW:
		    if (pos_col == CITY_COL)
		    {
			in_city3[in_cnt] = toupper(in_char);
			addch(in_city3[in_cnt]);
			in_cnt++;
			if (in_cnt == 18)
			{
			    cur_col = pos_col = CNTY_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    else if (pos_col == CNTY_COL)
		    {
			in_cnty3[in_cnt] = toupper(in_char);
			addch(in_cnty3[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = STATE_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    else
		    {
			in_state3[in_cnt] = toupper(in_char);
			addch(in_state3[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = CITY_COL;
			    cur_row = pos_row = CITY4_ROW;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    break;
		case CITY4_ROW:
		    if (pos_col == CITY_COL)
		    {
			in_city4[in_cnt] = toupper(in_char);
			addch(in_city4[in_cnt]);
			in_cnt++;
			if (in_cnt == 18)
			{
			    cur_col = pos_col = CNTY_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
		    }
		    else if (pos_col == CNTY_COL)
		    {
			in_cnty4[in_cnt] = toupper(in_char);
			addch(in_cnty4[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = STATE_COL;
			    in_cnt = 0;
			}
			else
			    cur_col++;
			}
			else
			{
			    in_state4[in_cnt] = toupper(in_char);
			    addch(in_state4[in_cnt]);
			    in_cnt++;
			    if (in_cnt == 2)
			    {
				cur_col = pos_col = TYPE_COL;
				cur_row = pos_row = TYPE_ROW;
				in_cnt = 0;
			    }
			    else
				cur_col++;
			}
			break;

		    case TYPE_ROW:
			request[in_cnt] = toupper(in_char);
			addch(request[in_cnt]);
			in_cnt++;
			if (in_cnt == 2)
			{
			    cur_col = pos_col = CITY_COL;
			    cur_row = pos_row = CITY1_ROW;
			    in_cnt = 0;
			}
			else
			    cur_col++;
			break;

		}  /* switch(pos_row) */
		move(cur_row, cur_col);
		refresh();
		break;
	} /* switch (in_char) */
	in_char = get_input();
    }  /* while*/
    return(0);
} /* int process_input_53(pf_key) */

#ifndef SOLARIS
int get_input()
{
    int return_code;
    term_screen_type = 0;
    if(strncmp(TERM, "ibm3151", 7) == 0)
    {
        term_screen_type = 1;
	return_code = get_input_ibm3151();
    }
    else
    {
        if(strncmp(TERM, "a", 1) ==0)
        {
            if(strncmp(TERM, "ansi", 4) ==0)
            {
                 term_screen_type = 1;
	         return_code = get_input_ansi();
            }
            else
            {
               if(strncmp(TERM, "att705", 6) == 0)
               {
                   term_screen_type = 1;
	           return_code = get_input_att705();
               }
            }

        }
        else
        {
            if(strncmp(TERM, "vt", 2) == 0)
            {
               if(strncmp(TERM, "vt100", 5) ==0)
               {
                   term_screen_type = 2;
	           return_code = get_input_vt100();
               }
               else
               {
                   if(strncmp(TERM, "vt220", 5) ==0)
                   {
                         term_screen_type = 3;
	                 return_code = get_input_vt220();
                   }
               }
                
            }
            else
            {
                if(strncmp(TERM, "w", 1) ==0)
                {
                    if(strncmp(TERM, "wyse50", 6) == 0 ||
                       strncmp(TERM, "wy50", 4) == 0)
                    {
                        term_screen_type = 1;
	                return_code = get_input_wyse60();
                    }
                    else
                    {
                        if(strncmp(TERM, "wyse60", 6) == 0 ||
                           strncmp(TERM, "wy60", 4) == 0 ||
                           strncmp(TERM, "wyse160", 7) == 0 ||
                           strncmp(TERM, "wy160", 5) == 0)
                        {
                             term_screen_type = 1;
	                     return_code = get_input_wyse60();
                        }
                        else
                        {
                             if(strncmp(TERM, "wyse370", 7) ==0)
                             {
                                  term_screen_type = 1;
	                          return_code = get_input_wyse370();
                             }
                        }
                    }
                }
             }
        }
    }
    if (term_screen_type == 0)
    {
         return_code = get_input_ansi();
         term_screen_type = 1;
    }
    return(return_code);
}
#else
int get_input()
{
    int return_code;
    term_screen_type = 0;
    if(strncmp(TERM, "ibm3151", 7) == 0)
    {
        term_screen_type = 1;
	return_code = get_input_ibm3151();
    }
    else
    {
        if(strncmp(TERM, "a", 1) ==0)
        {
            if(strncmp(TERM, "ansi", 4) ==0)
            {
                 term_screen_type = 1;
	         return_code = get_input_ansi();
            }
            else
            {
               if(strncmp(TERM, "att705", 6) == 0)
               {
                   term_screen_type = 1;
	           return_code = get_input_att705();
               }
            }

        }
        else
        {
            if(strncmp(TERM, "vt", 2) == 0)
            {
               if(strncmp(TERM, "vt100", 5) ==0)
               {
                   term_screen_type = 2;
	           return_code = get_input_vt100();
               }
               else
               {
                   if(strncmp(TERM, "vt220", 5) ==0)
                   {
                         term_screen_type = 3;
	                 return_code = get_input_vt220();
                   }
               }
                
            }
            else
            {
                if(strncmp(TERM, "w", 1) ==0)
                {
                    if(strncmp(TERM, "wyse50", 6) == 0 ||
                       strncmp(TERM, "wy50", 4) == 0)
                    {
                        term_screen_type = 1;
	                return_code = get_input_wyse60();
                    }
                    else
                    {
                        if(strncmp(TERM, "wyse60", 6) == 0 ||
                           strncmp(TERM, "wy60", 4) == 0 ||
                           strncmp(TERM, "wyse160", 7) == 0 ||
                           strncmp(TERM, "wy160", 5) == 0)
                        {
                             term_screen_type = 1;
	                     return_code = get_input_wyse60();
                        }
                        else
                        {
                             if(strncmp(TERM, "wyse370", 7) ==0)
                             {
                                  term_screen_type = 1;
	                          return_code = get_input_wyse370();
                             }
                        }
                    }
                }
                else
                {
                     if(strncmp(TERM, "sun", 3) == 0)
                      {
                         term_screen_type = 2;
                         return_code = get_input_suncmd();
                      }
                }     
             }
        }
    }
    if (term_screen_type == 0)
    {
         term_screen_type = 2;
         return_code = get_input_suncmd();
    }
    return(return_code);
}
int get_input_suncmd()
{
   char user_input;
   static char save_input = SPACE;
   int stdin_fd = 0;  /* standard input file descriptor */
   /* long time1, time2; changed for DATA GENERAL*/ 
   clock_t time1, time2;
   struct tms tbuf;

   if (save_input != SPACE)
      {
      user_input = save_input;
      save_input = SPACE;
      /* key is control char */
      if ( user_input < 0x1f)
         {
         switch (user_input)
           {
	    /* BEGIN Smithway PAGE_UP/PAGE_DOWN addition */
	    case 0x04 :return ('\233');  /* if Ctrl/D return PAGE_DOWN */
	    case 0x15 :return ('\226');  /* if Ctrl/U return PAGE_UP */
	    /* END Smithway PAGE_UP/PAGE_DOWN addition */
            case 0x0a :return ('\232');  /* if Ctrl/J return Down Arrow */
            case 0x0b :return ('\225');  /* if Ctrl/K return Up Arrow */
            case 0x0c :return ('\230');  /* if Ctrl/L return Right Arrow */
            case 0x1e :return ('\224');  /* if Ctrl/= return Home Key */
            default : break;
            }
         }
      return(user_input);
      }
   crmode(); /* AIX */
   user_input = getch(); /* AIX */
   D(fprintf(log_ptr, "INPUT 1 = %c %d\n", user_input, user_input);)
   D(fflush(log_ptr);)
   if (user_input < 0x1f)
      {
      switch (user_input)
        {
	 /* BEGIN Smithway PAGE_UP/PAGE_DOWN addition */
	 case 0x04 :return ('\233');  /* if Ctrl/D return PAGE_DOWN */
	 case 0x15 :return ('\226');  /* if Ctrl/U return PAGE_UP */
	 /* END Smithway PAGE_UP/PAGE_DOWN addition */
         case 0x0a :return ('\232');   /* if Ctrl/J return Down Arrow */
         case 0x0b :return ('\225');   /* if Ctrl/K return Up Arrow */
         case 0x0c :return ('\230');   /* if Ctrl/L return Right Arrow */
         case 0x1e :return ('\224');   /* if Ctrl/= return Home Key */
         default : break;
         }
      }

   if (user_input == '\033')
      {
      /* time1 = times(&tbuf);
      for (;;)
         {
          time2 = times(&tbuf);
          if ((time2 - time1) > 1)
             break;
          } */
      crmode();  /* AIX */ 
      user_input = getch(); /* AIX */
      if(user_input == '\033') /* AIX  if char is ESC*/
         return(user_input);   /* AIX */
      if(user_input == '[') /* AIX */   /* ELSE EQUAL TO [ */
      {
        user_input = getch();
        switch (user_input)
        {
        case '2': user_input = getch(); 
                  switch (user_input)
                  {
                     case '1' :user_input = getch(); 
                               return('\226'); /* PAGE UP */
                     case '2': user_input = getch();
                               switch (user_input)
                               {
                                   case '2' : user_input = getch();
                                              return('\233'); /* PAGE DOWN */
                                   case '4': user_input = getch();
                                             if (user_input == 'z')
                                                 return(F1);
                                             else
                                                 return(INVALID_F_KEY);
                                   case '5': user_input = getch(); 
                                              if (user_input == 'z') 
                                                   return(F2); 
                                           else
                                                 return(INVALID_F_KEY);
                                   case '6': user_input = getch(); 
                                           if (user_input == 'z')
                                                 return(F3); 
                                            else 
                                                 return(INVALID_F_KEY);
                                   case '7': user_input = getch();
                                           if (user_input == 'z')
                                                 return(F4); 
                                           else
                                                 return(INVALID_F_KEY);
                                     }
                     } 
           case 'A' : return('\225'); /* UP ARROW */
           case 'B' : return('\232'); /* DOWN ARROW */
           case 'C' : return('\230'); /* RIGHT ARROW */
           case 'D' : return('\227'); /* LEFT ARROW */
           default  : return('\236');/*INVALID KEY*/
             }
        }
        else
           return('\236');/*INVALID KEY*/
      }
      return(user_input);
} /* end of get_input_suncmd() */
#endif 

int get_input_att705 ()
{
   char user_input;
   static char save_input = SPACE;
   int ret_code = 0;
   int stdin_fd = 0;  /* standard input file descriptor */
   long time1, time2;
   struct tms tbuf;
   char	*TERM;		/* Terminal emulation run by user */

/* Begin change for 705 emulation - CL */
   TERM = getenv ("TERM\0");
/* End change for 705 emulation - CL */
   if (save_input != SPACE)
   {
      user_input = save_input;
      save_input = SPACE;
      switch (user_input)
      {
         case 0x0a :return ('\232');
         case 0x0b :return ('\225');
         case 0x0c :return ('\230');
         case 0x1e :return ('\224');
         default : break;
      }
      return(user_input);
   }

   ret_code = read(stdin_fd,&user_input, 1);
   D(fprintf (log_ptr,"USER_INPUT = %c  %d",user_input,user_input);)
   D(fflush(log_ptr);)
   switch (user_input)
   {
      case 0x0a :return ('\232');
      case 0x0b :return ('\225');
      case 0x0c :return ('\230');
      case 0x1e :return ('\224');
      default : break;
   }

   if (user_input != '\033')
      return (user_input);      /* return input if first char not ESC */

   time1 = times(&tbuf);
#ifndef SOLARIS
   for (;;)
   {
      time2 = times(&tbuf);
      if ((time2 - time1) > 1)
         break;
   }
#endif
/*
   if ((rdchk (stdin_fd)) > 0)
   {
      ret_code = read(stdin_fd,&user_input, 1);
      D(fprintf (log_ptr,"USER_INPUT2 = %c  %d",user_input,user_input);)
      D(fflush(log_ptr);)
   }
   else return(user_input);
*/
   crmode();
   user_input = getch();
   D(fprintf(log_ptr, "USER_INPUT2 <%c> %d\n", user_input, user_input);)
   D(fflush(log_ptr);)
   if (user_input == '\033')
       return(user_input);

   if (user_input != '[')
   {
/* Begin change for 705 emulation - CL */
      if (strncmp (TERM, "ansi", 4) == 0)
      {
            switch (user_input)
            {
               case 'J': return ('\226');
               case 'K': return ('\233');
               case 'T': return ('\231');
               case 0x72 : return ('\234');
               default : break;
            }
      }  /* end if ansi */

      else switch (user_input)      /* 705 emulation */
      {
         case 'J': return ('\226');
         case 'K': return ('\233');
         case 'T': return ('\231');
         case 0x72 : return ('\234');
	 case 'O':
	 {
            ret_code = read (stdin_fd, &user_input, 1);
            D(fprintf (log_ptr,"USER_INPUT4 = %c  %d", user_input,user_input);)
            D(fflush(log_ptr);)
            switch (user_input)
            {
               case 'c': return (F1);
               case 'd': return (F2);
               case 'e': return (F3);
               case 'f': return (F4);
               case 'g': return (F5);
               case 'h': return (F6);
               case 'i': return (F7);
               case 'j': return (F8);
               case 'C': return (SHIFT_F1);
               case 'D': return (SHIFT_F2);
               case 'E': return (SHIFT_F3);
               case 'F': return (SHIFT_F4);
               case 'G': return (SHIFT_F5);
               case 'H': return (SHIFT_F6);
               case 'I': return (SHIFT_F7);
               case 'J': return (SHIFT_F8);
	       default:  return (INVALID_F_KEY);
	    }
	    break;
	 }
	 case 'N':
	 {
            ret_code = read (stdin_fd, &user_input, 1);
            D(fprintf(log_ptr,"USER_INPUT4 = %c  %d",user_input,user_input);)
            D(fflush(log_ptr);)
            switch (user_input)
            {
               case 'o': return (F9);
               case 'O': return (SHIFT_F9);
               case 'P': return (SHIFT_F10);
	       default:  return (INVALID_F_KEY);
	    }
	    break;
	 }
         default : break;
      } /* end 705 switch */
/* End change for 705 emulation - CL */

      save_input = user_input;
      return ('\033');
   }
   else    /* ELSE EQUAL TO [ */
   {
      ret_code = read (stdin_fd, &user_input, 1);
      D(fprintf (log_ptr,"USER_INPUT3 = %c  %d",user_input,user_input);)
      D(fflush(log_ptr);)
/* Begin change for 705 emulation - CL */
      if (strncmp (TERM, "ansi", 4) == 0)
      {
         switch (user_input)
         {
            case 'M': return (F1);	/* F1 */
            case 'N': return (F2);	/* F2 */
            case 'O': return (F3);	/* F3 */
            case 'P': return (F4);	/* F4 */
            case 'Q': return (F5);
            case 'R': return (F6);	/* F6 */
            case 'S': return ('\206');
            case 'T': return ('\207');
            case 'U': return ('\210');
            case 'V': return ('\211');
            case 'Y': return ('\212');
            case 'Z': return ('\213');
            case 'a': return ('\214');
            case 'b': return ('\215');
            case 'c': return ('\216');
            case 'd': return ('\217');
            case 'e': return ('\220');
            case 'f': return ('\221');
            case 'g': return ('\222');
            case 'h': return ('\223');
            case 'k': return ('\237');
            case 'l': return ('\240');
            case 'm': return ('\241');
            case 'n': return ('\242');
            case 'o': return ('\243');
            case 'p': return ('\244');

            case 'q': return (-91);  /* V1.1 */
            case 'r': return (-90);  /* V1.1 */
            case 's': return (-89);  /* V1.1 */
            case 't': return (-88);  /* V1.1 */

            case 'H': return ('\224');
            case 'A': return ('\225');
            case 'I': return ('\226');
            case 'D': return ('\227');
            case 'C': return ('\230');
            case 'F': return ('\231');
            case 'B': return ('\232');
            case 'G': return ('\233');
            case 'L': return ('\234');
            default : return ('\235');
         }
      }  /* end if ansi */

      else switch (user_input)      /* 705 emulation */
      {
         case 'A': return (CURSOR_UP);
         case 'B': return (CURSOR_DOWN);
         case 'C': return (CURSOR_RIGHT);
         case 'D': return (CURSOR_LEFT);
         case 'U': return (PAGE_DOWN);
         case 'V': return (PAGE_UP);
         case 'H': return (HOME);
         case '@': return (INS);
         case '2':
	 {
            read (stdin_fd, &user_input, 1);
	    if (user_input == '4')
	    {
               read (stdin_fd, &user_input, 1);
	       if (user_input == ';')
	       {
                  read (stdin_fd, &user_input, 1);
	          if (user_input == '1')
		  {
                     read (stdin_fd, &user_input, 1);
	             if (user_input == 'H')
	                return (END);
		  }
	       }
	    }
	 }  /* end case '2' */
         default : return (INVALID_F_KEY);
      }  /* end 705 switch */
/* End change for 705 emulation - CL */
   }  /* end if second char is '[' */
}
int get_input_wyse60 ()
{
    char user_input;
    static char save_input = SPACE;
    int stdin_fd = 0;  /* standard input file descriptor */
#ifndef NOTIMES
    long times();   
#endif
    long time1, time2;
    struct tms tbuf;

    D(fprintf(log_ptr, "--> ENTERING get_input_wy60()\n");)
    D(fflush(log_ptr);)
    if (save_input != SPACE)
    {
	user_input = save_input;
	save_input = SPACE;
	if (user_input < 0x1f)
	{
	    switch (user_input)
	    {
		case 0x0a :return ('\232');
		case 0x0b :return ('\225');
		case 0x0c :return ('\230');
		case 0x1e :return ('\224');
		default : break;
	    }
	}
	return(user_input);
    }
    D(fprintf(log_ptr, "BEFORE READ\n");)
    D(fflush(log_ptr);)
    crmode();  
    user_input = getch(); 
    D(fprintf(log_ptr, "USER_INPUT1 <%c> %d\n" , user_input, user_input);)
    D(fflush(log_ptr);)
    if (user_input < 0x1f)
    {
	switch (user_input)
	{
	    case 0x0a :return ('\232');	/* Line Feed -> Cursor down */
	    case 0x0b :return ('\225'); /* Cursor Up */
	    case 0x0c :return ('\230'); /* Form Feed -> Cursor right */
	    case 0x1e :return ('\224');	/* Ctrl-^ -> as HOME */
	    default : break;
	}
    }
    if (user_input == '\033')
    {
#ifndef SOLARIS
	time1 = times(&tbuf);
	for (;;)
	{
	    time2 = times(&tbuf);
	    if ((time2 - time1) > 1)
		break;
	}
#endif
	crmode();
	user_input = getch();
	D(fprintf(log_ptr, "USER_INPUT2 <%c> %d\n", user_input, user_input);)
	D(fflush(log_ptr);)
	if (user_input == '\033')
	    return(user_input);

	if (user_input == 'q')
	    return('\234');		/* Insert */
	else if (user_input == 'Q')
	    return('\234');		/* Insert */
	else if (user_input == 'K')
	    return('\233');		/* Page Down */
	else if (user_input == 'J')
	    return('\226');		/* Page Up */
	else if (user_input == 'W')
	    return('\177');		/* Del Char */
	else if (user_input == 'I')
	    return(0x1d);		/* Back Tab */
    }
    else if (user_input == 0x01)
    {
	time1 = times(&tbuf);
#ifndef SOLARIS
	for (;;)
	{
	    time2 = times(&tbuf);
	    if ((time2 - time1) > 1)
	    {
		break;
	    }
	}
#endif
	user_input = getch();
	switch (user_input)
	{
	    case '@' : user_input = getch();
		       return('\200');		/* F1 */
	    case 'A' : user_input = getch();
		       return('\201');		/* F2 */
	    case 'B' : user_input = getch();
		       return('\202');		/* F3 */
	    case 'C' : user_input = getch();
		       return('\203');		/* F4 */
	    case 'D' : user_input = getch();
		       return('\204');		/* F5 */
	    case 'E' : user_input = getch();
		       return('\205');		/* F6 */
	    case 'F' : user_input = getch();
		return('\206');		/* F7 */
	    case 'G' : user_input = getch();
		return('\207');		/* F8 */
	    case 'H' : user_input = getch();
		return('\210');		/* F9 */
	    case 'I' : user_input = getch();
		return('\211');		/* F10 */

	    case '`' : user_input = getch();
		return('\212');		/* SHIFT-F1 */
	    case 'a' : user_input = getch();
		return('\213');		/* SHIFT-F2 */
	    case 'b' : user_input = getch();
		return('\214');		/* SHIFT-F3 */
	    case 'c' : user_input = getch();
		return('\215');		/* SHIFT-F4 */
	    case 'd' : user_input = getch();
		return('\216');		/* SHIFT-F5 */
	    case 'e' : user_input = getch();
		return('\217');		/* SHIFT-F6 */
	    case 'f' : user_input = getch();
		return('\220');		/* SHIFT-F7 */
	    case 'g' : user_input = getch();
		return('\221');		/* SHIFT-F8 */
	    case 'h' : user_input = getch();
		return('\222');		/* SHIFT-F9 */
	    case 'i' : user_input = getch();
		return('\223');		/* SHIFT-F10 */
	    default  : return('\236');
	}
    }
    else
	return(user_input);
}   /* end of get_input_wy60() */
int get_input_wyse370 ()
{
}
int get_input_vt220 ()
{
   char user_input;
   static char save_input = SPACE;
   int ret_code = 0;
   int stdin_fd = 0;  /* standard input file descriptor */
   long time1, time2;
   struct tms tbuf;

   if (save_input != SPACE)
      {
      user_input = save_input;
      save_input = SPACE;
      /* key is control char */
      if ( user_input < 0x1f)
         {
         switch (user_input)
           {
            case 0x0a :return ('\232');  /* if Ctrl/J return Down Arrow */
            case 0x0b :return ('\225');  /* if Ctrl/K return Up Arrow */
            case 0x0c :return ('\230');  /* if Ctrl/L return Right Arrow */
            case 0x1e :return ('\224');  /* if Ctrl/= return Home Key */
            default : break;
            }
         }
      return(user_input);
      }
   crmode(); /* AIX */
   user_input = getch(); /* AIX */
   if (user_input < 0x1f)
      {
      switch (user_input)
        {
         case 0x0a :return ('\232');   /* if Ctrl/J return Down Arrow */
         case 0x0b :return ('\225');   /* if Ctrl/K return Up Arrow */
         case 0x0c :return ('\230');   /* if Ctrl/L return Right Arrow */
         case 0x1e :return ('\224');   /* if Ctrl/= return Home Key */
         default : break;
         }
      }

   if (user_input == '\033')
      {
#ifndef SOLARIS
      time1 = times(&tbuf);
      for (;;)
         {
          time2 = times(&tbuf);
          if ((time2 - time1) > 1)
             break;
          }
#endif
      crmode();  /* AIX */ 
      user_input = getch(); /* AIX */
      if(user_input == '\033') /* AIX  if char is ESC*/
         return(user_input);   /* AIX */

      if (user_input != 'O' && user_input != '[') /*if char not a function key*/
         {
             switch (user_input)
               {
               case 'J': return ('\226'); /* if J return PAGE UP */
               case 'K': return ('\233'); /* if K return PAGE DOWN */
               case 'T': return ('\231'); /* if T return END KEY */
               case 0x72 : return ('\234'); /* if r return INSERT KEY */
               default : break;
               }
         save_input = user_input;
         return ('\033');
         }
       else if(user_input == '[') /* AIX */   /* ELSE EQUAL TO [ */
        {
        user_input = getch();
        switch (user_input)
           {
           case '1': user_input = getch(); /* if 1 get another char */
                     switch (user_input)
                     {
                         case '7': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\204'); /* F5 */
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                         case '8': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\205'); /* F6 */
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                         case '9': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\206'); /* F7 */
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                         default:  return('\234'); /* Insert Key */
                     } 
           case '2': user_input = getch(); /* if 1 get another char */
                     switch (user_input)
                     {
                         case '~': return('\234');
                         case '0': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\207'); /* F8 */
                                        default : return('\236');/*INVALID KEY*/
                                   }
                         case '1': user_input = getch();
                                  switch (user_input)
                                   {
                                        case '~': return('\210'); /* F9 */
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                         case '3': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\212'); /* SHIFT-F1 */
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                         case '4': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\213'); /* SHIFT-F2 */
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                         case '5': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\214'); /* SHIFT-F3 */
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                         case '6': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\215'); /* SHIFT-F4 */
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                         case '8': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\216'); /*SHIFT- F5 */
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                         case '9': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\220'); /*SHIFT- F7 */
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                     } 
           case '3': user_input = getch(); /* if 1 get another char */
                     switch (user_input)
                     {
                         case '1': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\221'); /* SHIFT-F8 */
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                         case '2': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\222'); /* SHIFT-F9 */
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                         case '3': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\217'); /* SHIFT-F6 */
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                         case '4': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\223'); /* SHIFT-F10*/
                                        default : return('\236');/*INVALID KEY*/
                                   } 
           	         default: return('\177'); /* Delete Key */
                     } 
           case '5': return('\226'); /* Page Up */
           case '6': return('\233'); /* Page Down */
           case 'A' : return('\225'); /* UP ARROW */
           case 'B' : return('\232'); /* DOWN ARROW */
           case 'C' : return('\230'); /* RIGHT ARROW */
           case 'D' : return('\227'); /* LEFT ARROW */
             }
        }
        else if (user_input == 'O')
        {
            user_input = getch();
            switch(user_input) /* check the page up/down,end, and insert RW */
            {
              case 'P' : return('\200'); /* F1 */
              case 'Q' : return('\201'); /* F2 */
              case 'R' : return('\202'); /* F3 */
              case 'S' : return('\203'); /* F4 */
              default  : return('\236'); /* INVALID KEY */
            }
        }
      }
      return(user_input);
} /* end of get_input_vt220() */
int get_input_vt100()
{
   char user_input;
   static char save_input = SPACE;
   int ret_code = 0;
   int stdin_fd = 0;  /* standard input file descriptor */
   long time1, time2;
   struct tms tbuf;

   if (save_input != SPACE)
      {
      user_input = save_input;
      save_input = SPACE;
      /* key is control char */
      if ( user_input < 0x1f)
         {
         switch (user_input)
           {
	    /* BEGIN Smithway PAGE_UP/PAGE_DOWN addition */
	    case 0x04 :return ('\233');  /* if Ctrl/D return PAGE_DOWN */
	    case 0x15 :return ('\226');  /* if Ctrl/U return PAGE_UP */
	    /* END Smithway PAGE_UP/PAGE_DOWN addition */
            case 0x0a :return ('\232');  /* if Ctrl/J return Down Arrow */
            case 0x0b :return ('\225');  /* if Ctrl/K return Up Arrow */
            case 0x0c :return ('\230');  /* if Ctrl/L return Right Arrow */
            case 0x1e :return ('\224');  /* if Ctrl/= return Home Key */
            default : break;
            }
         }
      return(user_input);
      }
   crmode(); /* AIX */
   user_input = getch(); /* AIX */
   D(fprintf(log_ptr, "INPUT 1 = %c %d", user_input, user_input);)
   D(fflush(log_ptr);)

   if (user_input < 0x1f)
      {
      switch (user_input)
        {
	 /* BEGIN Smithway PAGE_UP/PAGE_DOWN addition */
	 case 0x04 :return ('\233');  /* if Ctrl/D return PAGE_DOWN */
	 case 0x15 :return ('\226');  /* if Ctrl/U return PAGE_UP */
	 /* END Smithway PAGE_UP/PAGE_DOWN addition */
         case 0x0a :return ('\232');   /* if Ctrl/J return Down Arrow */
         case 0x0b :return ('\225');   /* if Ctrl/K return Up Arrow */
         case 0x0c :return ('\230');   /* if Ctrl/L return Right Arrow */
         case 0x1e :return ('\224');   /* if Ctrl/= return Home Key */
         default : break;
         }
      }

   if (user_input == '\033')
      {
#ifndef SOLARIS
      time1 = times(&tbuf);
      for (;;)
         {
          time2 = times(&tbuf);
          if ((time2 - time1) > 1)
             break;
          }
#endif
      crmode();  /* AIX */ 
      user_input = getch(); /* AIX */
      if(user_input == '\033') /* AIX  if char is ESC*/
         return(user_input);   /* AIX */

      if (user_input != 'O' && user_input != '[') /*if char not a function key*/
         {
             switch (user_input)
               {
               case 'J': return ('\226'); /* if J return PAGE UP */
               case 'K': return ('\233'); /* if K return PAGE DOWN */
               case 'T': return ('\231'); /* if T return END KEY */
               case 0x72 : return ('\234'); /* if r return INSERT KEY */
               default : break;
               }
         save_input = user_input;
         return ('\033');
         }
       else if(user_input == '[') /* AIX */   /* ELSE EQUAL TO [ */
        {
        user_input = getch();
        switch (user_input)
           {
           case '2': user_input = getch(); /* if 1 get another char */
                     switch (user_input)
                     {
                         case '3': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\212'); /* SHIFT-F1 */
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                         case '4': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\212'); 
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                         case '5': user_input = getch();
                                   switch (user_input)
                                   {
                                        case '~': return('\212');
                                        default : return('\236');/*INVALID KEY*/
                                   } 
                     } 
           case 'A' : return('\225'); /* UP ARROW */
           case 'B' : return('\232'); /* DOWN ARROW */
           case 'C' : return('\230'); /* RIGHT ARROW */
           case 'D' : return('\227'); /* LEFT ARROW */
           case 'V' : return('\226'); /* PAGE UP */
           case 'U' : return('\233'); /* PAGE DOWN */
           default  : return('\236');/*INVALID KEY*/
             }
        }
        else if (user_input == 'O')
        {
            user_input = getch();
            switch(user_input) /* check the page up/down,end, and insert RW */
            {
              case 'P' : return('\200'); /* F1 */
              case 'Q' : return('\201'); /* F2 */
              case 'R' : return('\202'); /* F3 */
              case 'S' : return('\203'); /* F4 */
              default  : return('\236'); /* INVALID KEY */
            }
        }
      }
      return(user_input);
} /* end of get_input_vt100() */


int get_input_ibm3151()
{
    char user_input;
    static char save_input = SPACE;
    int stdin_fd = 0;  /* standard input file descriptor */
#ifndef NOTIMES
    long times();   
#endif
    long time1, time2;
    struct tms tbuf;

    D(fprintf(log_ptr, "--> ENTERING get_input_ibm3151()\n");)
    D(fflush(log_ptr);)
    if (save_input != SPACE)
    {
	user_input = save_input;
	save_input = SPACE;
	if (user_input < 0x1f)
	{
	    switch (user_input)
	    {
		case 0x0a :return ('\232');
		case 0x0b :return ('\225');
		case 0x0c :return ('\230');
		case 0x1e :return ('\224');
		default : break;
	    }
	}
	return(user_input);
    }
    D(fprintf(log_ptr, "BEFORE READ\n");)
    D(fflush(log_ptr);)
    crmode();  
    user_input = getch(); 
    D(fprintf(log_ptr, "USER_INPUT1 <%c> %d\n" , user_input, user_input);)
    D(fflush(log_ptr);)
    if (user_input < 0x1f)
    {
	switch (user_input)
	{
	    case 0x0a :return ('\232');	/* Line Feed -> CURSOR down */
	    case 0x0b :return ('\225'); /* CURSOr Up */
	    case 0x0c :return ('\230'); /* Form Feed -> CURSOR right */
	    case 0x1e :return ('\224');	/* Ctrl-^ -> as HOME */
	    default : break;
	}
    }
    D(fprintf(log_ptr, "INPUT 2 <%c> %d\n", user_input, user_input);)
    D(fflush(log_ptr);)
    if (user_input == '\033')
    {
#ifndef SOLARIS
	time1 = times(&tbuf);
	for (;;)
	{
	    time2 = times(&tbuf);
	    if ((time2 - time1) > 1)
		break;
	}
#endif
	crmode();
	user_input = getch();
	D(fprintf(log_ptr, "USER_INPUT2 <%c> %d\n", user_input, user_input);)
	D(fflush(log_ptr);)
	if (user_input == '\033')
	    return(user_input);
	else if(user_input == '!')
	{   /* Probably looking at a shifted fkey */
	    user_input = getch();
	    D(fprintf(log_ptr, "USER_INPUT2 <%c> ", user_input);)
	    D(fprintf(log_ptr, "%d\n", user_input);)
	    D(fflush(log_ptr);)
	    switch(user_input)
	    {
		case 'a': user_input = getch();
			  return('\212');	/* SHIFT_F1 */
		case 'b': user_input = getch();
			  return('\213');	/* SHIFT_F2 */
		case 'c': user_input = getch();
			  return('\214');	/* SHIFT_F3 */
		case 'd': user_input = getch();
			  return('\215');	/* SHIFT_F4 */
		case 'e': user_input = getch();
			  return('\216');	/* SHIFT_F5 */
		case 'f': user_input = getch();
			  return('\217');	/* SHIFT_F6 */
		case 'g': user_input = getch();
			  return('\220');	/* SHIFT_F7 */
		case 'h': user_input = getch();
			  return('\221');	/* SHIFT_F8 */
		case 'i': user_input = getch();
			  return('\222');	/* SHIFT_F9 */
		case 'j': user_input = getch();
			  return('\223');	/* SHIFT_F10 */
		default:  user_input = getch();
			  return('\236');	/* INVALID_F_KEY */
	    }
	}
	else if (user_input == '"')
	{   /* Probably looking at a shift-ctrl fkey */
	    user_input = getch();
	    if(user_input == 'A')
		return('\236');	/* "Jump Partition" function */
	    else
	    {			/* SHIFT_Ctrl fkey */
		user_input = getch();
		return('\236');	/* INVALID_F_KEY */
	    }
	}
	else
	{   /* Handle individual cases */
	    switch(user_input)
	    {
		case 'a':user_input = getch(); /* F1 */
			 return('\200');
		case 'b':user_input = getch();	/* F2 */
			 return('\201');
		case 'c':user_input = getch(); /* F3 */
			 return('\202');
		case 'd':user_input = getch(); /* F4 */
			 return('\203');
                case 'e': user_input = getch();
                          return('\204');       /* F5 */
                case 'f': user_input = getch();
                          return('\205');       /* F6 */
                case 'g': user_input = getch();
                          return('\206');       /* F7 */
                case 'h': user_input = getch();
                          return('\207');       /* F8 */
                case 'i': user_input = getch();
                          return('\210');       /* F9 */
                case 'j': user_input = getch();
                          return('\211');       /* F10 */
		case 'A': return('\225');	/* CURSOR_UP */
		case 'B': return('\232');	/* CURSOR_DOWN */
		case 'C': return('\230');	/* CURSOR_RIGHT */
		case 'D': return('\227');	/* CURSOR_LEFT */
		case 'H': return('\224');	/* HOME */
		case 'I': return('\233');	/* Erase EOF -> PAGE_DOWN */
		case 'L': user_input = getch(); /* Clear->PAGE UP */
			  return('\226');
		case 'P': return('\233');	/* INS */
		case 'Q': return('\177');	/* DEL */
		case '2': return(0x1d);		/* Back tab */

		case 'U': /* Print Line */
		case 'V': /* Print Message */
		case 'W': /* Print Page */
		case '8': /* Send Page */
			  user_input = getch();
			  return('\236');	/* INVALID_F_KEY */

		case ' ': /* Possible: 8 LTA or W LTA */
			  user_input = getch();
			  user_input = getch();
			  return('\236');	/* INVALID_F_KEY */

		default:  return('\236');	/* INVALID_F_KEY */
	    }
	}

    }
    return(user_input);
}   /* get_input_ibm3151() */
int get_input_ansi ()
{
   char user_input;
   static char save_input = SPACE;
   int ret_code = 0;
   int stdin_fd = 0;  /* standard input file descriptor */
   long time1, time2;
   struct tms tbuf;

   if (save_input != SPACE)
   {
      user_input = save_input;
      save_input = SPACE;
      if (user_input < 0x1f)
      {
         switch (user_input)
         {
            case 0x0a :return ('\232');
            case 0x0b :return ('\225');
            case 0x0c :return ('\230');
            case 0x1e :return ('\224');
            default : break;
         }
      }
      return(user_input);
   }

   ret_code = read(stdin_fd,&user_input, 1);
   D(fprintf (log_ptr,"\nUSER_INPUT = %c  %d\n",user_input,user_input);)
   D(fflush(log_ptr);)
   if (user_input < 0x1f)
   {
      switch (user_input)
      {
         case 0x0a :return ('\232');
         case 0x0b :return ('\225');
         case 0x0c :return ('\230');
         case 0x1e :return ('\224');
         default : break;
      }
   }

   if (user_input == '\033')
   {
#ifndef SOLARIS
      time1 = times(&tbuf);
      for (;;)
      {
         time2 = times(&tbuf);
         if ((time2 - time1) > 1)
            break;
      }
#endif
    /*  if ((rdchk (stdin_fd)) > 0)
      {
         ret_code = read(stdin_fd,&user_input, 1);
         D(fprintf (log_ptr,"USER_INPUT2 = %c  %d\n",user_input,user_input);)
         D(fflush(log_ptr);)
      }
      else
         return(user_input);a */

	 crmode();
	 user_input = getch();

      if (user_input != '[')
      {
         switch (user_input)
         {
            case 'J': return ('\226');
            case 'K': return ('\233');
            case 'T': return ('\231');
            case 0x72 : return ('\234');
            default : break;
         }
         save_input = user_input;
         return ('\033');
      }
      else    /* ELSE EQUAL TO [ */
      {
         ret_code = read (stdin_fd, &user_input, 1);
         D(fprintf (log_ptr,"USER_INPUT3 = %c  %d\n",user_input,user_input);)
         D(fflush(log_ptr);)
         switch (user_input)
         {
            case 'M': return ('\200');	/* F1 */
            case 'N': return ('\201');	/* F2 */
            case 'O': return ('\202');	/* F3 */
            case 'P': return ('\203');	/* F4 */
            case 'Q': return ('\204');
            case 'R': return ('\205');	/* F6 */
            case 'S': return ('\206');
            case 'T': return ('\207');
            case 'U': return ('\210');
            case 'V': return ('\211');
            case 'Y': return ('\212');
            case 'Z': return ('\213');
            case 'a': return ('\214');
            case 'b': return ('\215');
            case 'c': return ('\216');
            case 'd': return ('\217');
            case 'e': return ('\220');
            case 'f': return ('\221');
            case 'g': return ('\222');
            case 'h': return ('\223');
            case 'k': return ('\237');
            case 'l': return ('\240');
            case 'm': return ('\241');
            case 'n': return ('\242');
            case 'o': return ('\243');
            case 'p': return ('\244');

            case 'q': return (-91);  /* V1.1 */
            case 'r': return (-90);  /* V1.1 */
            case 's': return (-89);  /* V1.1 */
            case 't': return (-88);  /* V1.1 */

            case 'H': return ('\224');
            case 'A': return ('\225');
            case 'I': return ('\226');
            case 'D': return ('\227');
            case 'C': return ('\230');
            case 'F': return ('\231');
            case 'B': return ('\232');
            case 'G': return ('\233');
            case 'L': return ('\234');
            default : return ('\235');
         }
      }
   }
   else
      return(user_input);
} /* end get_input_ansi() */

/* process_request() sends formatted input to ACA and displays	*/
/* the output from ACA on the screen on a per-page basis.	*/
int process_request()
{
    int bytes_read = 0;
    int bytes_write = 0;
    int ret_val = 0;
    int i;
    int done;		/* Complete response received */
    int in_rec_num;
    int req_compare;
    REQ_U rqst_buf;

    /* Prepare data for first record sent to milemaker */
    memset(out_buf, SPACE, sizeof(out_buf));
    strncpy(out_buf, "HR", 2);
    D(fprintf(log_ptr, "FIRST out_buf HEX <");)
    D(fflush(log_ptr);)
    D(for (i = 0; i < sizeof(out_buf); i++))
    D({)
	D(fprintf(log_ptr, " %02x", out_buf[i]);)
	D(fflush(log_ptr);)
    D(})
    D(fprintf(log_ptr, ">\n");)
    D(fflush(log_ptr);)

    /* This section of code prepares to send the HR record.	*/
    /* Make sure user placed in a request type before copying	*/
    /* screen data for the actual request type. If no request	*/
    /* type was put in by the user, the default used in "MI".	*/
    req_compare = strncmp(out_buf, request, 2);
    if(req_compare != 0)
	strncpy(&out_buf[2], request, 2);
    D(fprintf(log_ptr, "SECOND out_buf HEX <");)
    D(fflush(log_ptr);)
    D(for (i = 0; i < sizeof(out_buf); i++))
    D({)
	D(fprintf(log_ptr, " %02x", out_buf[i]);)
	D(fflush(log_ptr);)
    D(})
    D(fprintf(log_ptr, ">\n");)
    D(fflush(log_ptr);)
    D(fprintf(log_ptr, "B/4 write in pipe_test out_buf <%s>\n", out_buf);)
    D(fflush(log_ptr);)

    /* The next line sends the HR record to ACA	*/
    bytes_write = write(to_aca, out_buf, sizeof(struct req_struct));
    if(bytes_write != sizeof(struct req_struct))
    {
	fprintf(log_ptr, "write() header failed errno %d\n", errno);
	fflush(log_ptr);
	perror("pipe_test write() header failed");
    }
    D(
	fprintf(log_ptr, "THIRD out_buf HEX <");
	fflush(log_ptr);
	for (i = 0; i < sizeof(out_buf); i++)
	{
	    fprintf(log_ptr, " %02x", out_buf[i]);
	    fflush(log_ptr);
	}
	fprintf(log_ptr, ">\nTHIRD out_buf TEXT <");
	fflush(log_ptr);
	for (i = 0; i < sizeof(out_buf); i++)
	{
	    fprintf(log_ptr, "%c", out_buf[i]);
	    fflush(log_ptr);
	}
	fprintf(log_ptr, ">\n");
	fflush(log_ptr);
    )
    D(fprintf(log_ptr, "req_struct size %d out_buf size %d out_buf strlen %d\n",
	sizeof(struct req_struct), sizeof(out_buf), strlen(out_buf));)
    D(fprintf(log_ptr, "1st bytes_write %d data <", bytes_write);)
    D(for(i = 0; i < 24; i++))
	D(fprintf(log_ptr, "%c", out_buf[i]);)
    D(fprintf(log_ptr, ">\n");)
    D(fflush(log_ptr);)

    if (hhg48_enable && memcmp(trailer_length, "  ", 2) != 0)
    {
	memset(&rqst_buf, 0, sizeof(rqst_buf));
        strncpy(rqst_buf.req_struct.rec_type, "TL", 2);
        strncpy(rqst_buf.req_struct.rec_u.trailer_rec.trailer_length, trailer_length, 2);
        bytes_write = write(to_aca, rqst_buf.request, sizeof(struct req_struct));
        if (bytes_write != sizeof(struct req_struct))
        {
	    fprintf(log_ptr, "write() trailer length failed errno %d\n", errno);
	    fflush(log_ptr);
	    perror("pipe_test write() trailer length failed");
        }
    } 


    /* This code block prepares and sends the OR record	*/
    /* to ACA with the origin city from line 1 of input.*/
    strncpy(rqst_buf.req_struct.rec_type, "OR", 2);
    strncpy(rqst_buf.req_struct.rec_u.city_info.city, in_city1, 18);
    strncpy(rqst_buf.req_struct.rec_u.city_info.cnty, in_cnty1, 2);
    strncpy(rqst_buf.req_struct.rec_u.city_info.state, in_state1, 2);
    bytes_write = write(to_aca, rqst_buf.request,
	sizeof(struct req_struct));
    if (bytes_write != sizeof(struct req_struct))
    {
	fprintf(log_ptr, "write() city1 failed errno %d\n", errno);
	fflush(log_ptr);
	perror("pipe_test write() city1 failed");
    }
    D(fprintf(log_ptr, "2nd bytes_write %d data <", bytes_write);)
    D(for(i = 0; i < 24; i++))
	D(fprintf(log_ptr, "%c", rqst_buf.request[i]);)
    D(fprintf(log_ptr, ">\n");)
    D(fflush(log_ptr);)



    /* This code block prepares and sends a VI or DT record to ACA	*/
    /* depending on whether or not a city is found on input line 3.	*/
    if(isalpha(in_city3[0]) || isdigit(in_city3[0])) /* ZIP V1.1 */
    {	/* A third city was inputted since line 3 starts with alphanumeric. */
	strncpy(rqst_buf.req_struct.rec_type, "VI", 2);
    }
    else
    {	/* No city on line 3 so line 2 is assumed to be the destination */
	strncpy(rqst_buf.req_struct.rec_type, "DT", 2);
    }
    strncpy(rqst_buf.req_struct.rec_u.city_info.city, in_city2, 18);
    strncpy(rqst_buf.req_struct.rec_u.city_info.cnty, in_cnty2, 2);
    strncpy(rqst_buf.req_struct.rec_u.city_info.state, in_state2, 2);
    /* Send the request record with either VI	*/
    /* or DT along with the city name to ACA.	*/
    bytes_write = write(to_aca, rqst_buf.request,
	sizeof(struct req_struct));
    if (bytes_write != sizeof(struct req_struct))
    {
	fprintf(log_ptr, "write() city2 failed errno %d\n", errno);
	fflush(log_ptr);
	perror("pipe_test write() city2 failed");
    }
    D(fprintf(log_ptr, "Via 1 bytes_write %d data <", bytes_write);)
    D(for(i = 0; i < 24; i++))
	D(fprintf(log_ptr, "%c", rqst_buf.request[i]);)
    D(fprintf(log_ptr, ">\n");)
    D(fflush(log_ptr);)

    /* This section processes city 3.  It sends a VI record if	*/
    /* city 4 exists, or DT if city 3 exists with no city 4.	*/
    if(isalpha(in_city3[0]) || isdigit(in_city3[0]))  /* ZIP V1.1 */
    {
	D(fprintf(log_ptr, "isalpha(in_city3[0])\n");)
	D(fflush(log_ptr);)
	if(isalpha(in_city4[0]) || isdigit(in_city4[0])) /* ZIP V1.1 */
	{   /* Line 4 has a city, city3 is a second stopoff point. */
	    D(fprintf(log_ptr, "city3 is a VI point\n");)
	    D(fflush(log_ptr);)
	    strncpy(rqst_buf.req_struct.rec_type, "VI", 2);
	}
	else
	{   /* Line 4 has no city, city3 is the destination. */
	    D(fprintf(log_ptr, "city3 is a DT point\n");)
	    D(fflush(log_ptr);)
	    strncpy(rqst_buf.req_struct.rec_type, "DT", 2);
	}
	strncpy(rqst_buf.req_struct.rec_u.city_info.city, in_city3, 18);
	strncpy(rqst_buf.req_struct.rec_u.city_info.cnty, in_cnty3, 2);
	strncpy(rqst_buf.req_struct.rec_u.city_info.state, in_state3, 2);
	/* Send the record to ACA for processing */
	bytes_write = write(to_aca, rqst_buf.request,
	    sizeof(struct req_struct));
	if (bytes_write != sizeof(struct req_struct))
	{
	    fprintf(log_ptr, "write() city3 failed errno %d\n", errno);
	    perror("pipe_test write() city3 failed");
	    fflush(log_ptr);
	}
	D(fprintf(log_ptr, "Via 2 bytes_write %d\n", bytes_write);)
	D(for(i = 0; i < 24; i++))
	    D(fprintf(log_ptr, "%c", rqst_buf.request[i]);)
	D(fprintf(log_ptr, ">\n");)
	D(fflush(log_ptr);)
    }

    if(isalpha(in_city4[0]) || isdigit(in_city4[0])) /* ZIP V1.1 */
    {	/* If a city exists on line 4 it must be the destination */
	strncpy(rqst_buf.req_struct.rec_type, "DT", 2);
	strncpy(rqst_buf.req_struct.rec_u.city_info.city, in_city4, 18);
	strncpy(rqst_buf.req_struct.rec_u.city_info.cnty, in_cnty4, 2);
	strncpy(rqst_buf.req_struct.rec_u.city_info.state, in_state4, 2);
	/* Send the record to ACA for processing */
	bytes_write = write(to_aca, rqst_buf.request,
	    sizeof(struct req_struct));
	if(bytes_write != sizeof(struct req_struct))
	{
	    D(fprintf(log_ptr, "write() city4 failed errno %d\n", errno);)
	    D(perror("pipe_test write() city4 failed");)
	}
	D(fprintf(log_ptr, "3rd bytes_write = %d data <", bytes_write);)
	D(for(i = 0; i < 24; i++))
	    D(fprintf(log_ptr, "%c", rqst_buf.request[i]);)
	D(fprintf(log_ptr, ">\n");)
	D(fflush(log_ptr);)
    }

    /* Loop until the LR record is received as part of the answer */
    done = 0;
    in_rec_num = 0;
    while (!done)
    {
	D(fprintf(log_ptr, "B/4 from_aca %d read()\n", from_aca);)
	D(fflush(log_ptr);)
	bytes_read = read(from_aca, mybuf, 71);
	D(fprintf(log_ptr, "bytes_read %d ", bytes_read);)
	D(fprintf(log_ptr, "in_rec_num %d\n", in_rec_num);)
	D(fflush(log_ptr);)
	mybuf[71] = NULBYT;
	D(fprintf(log_ptr, "mybuf <%s>\n", mybuf);)
	D(fflush(log_ptr);)

	move(11 + in_rec_num, 4);
	printw("%s", mybuf);

	if(strncmp(mybuf, "LR", 2) == 0)
	{   /* LR record received.  Done processing */
	    done = 1;
	    move(24, 28);
	    printw("%s", PRESSKEY);
	    refresh();
	    user_rqst = get_input();

	    for(i = 0; i <= 13; i++)
	    {
		move(11 + i, 4);
		printw("%s", BLANKS);
	    }
	    refresh();
	}
	else if(in_rec_num == 12)
	{   /* Maximum of 12 lines are shown on the display at one time. */
	    move(24, 28);
	    printw("%s", PRESSKEY);
	    refresh();
	    user_rqst = get_input();

	    for(i = 0; i <= 13; i++)
	    {
		move(11 + i, 4);
		printw("%s", BLANKS);
	    }
	    in_rec_num = 0;

	    /* Need to get more response data from ACA */
	    memset(rqst_buf.request, SPACE, sizeof(rqst_buf.request));
	    memcpy(rqst_buf.request, "HRSM", 4);
	    bytes_write = write(to_aca, rqst_buf.request,
		sizeof(struct req_struct));
	    if(bytes_write != sizeof(struct req_struct))
	    {
		D(fprintf(log_ptr, "HRSM write() failed errno %d\n", errno);)
		D(fflush(log_ptr);)
	    }
	    refresh();
	}
	else
	{   /* Increment number of output lines displayed on the screen. */
	    in_rec_num++;
	}
	refresh();
    }
    for(i = in_rec_num + 1; i <= 13; i++)
    {	/* Blank out all non-used lines on the screen */
	move(11 + i, 4);
	printw("%s", BLANKS);
    }
    move(CITY1_ROW, CITY1_ROW);
    refresh();
}
