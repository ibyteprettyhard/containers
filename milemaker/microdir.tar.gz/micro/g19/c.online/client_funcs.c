/*********************************************************************
*    Source Name:       client_funcs.c
*
*    Description:       This source file contains functions to create
*                       requests and display answers using TCP/IP.
*
*    Functions Called:  process_requests()
*                       format_req()
*                       write_to_socket()
*                       read_from_socket()
*                       display_answers()
*                       convert_city_cty_state()
*
*    Called By:         NONE.
*
*    History:
*
*        Name         Date           Description Of Change
*   --------------  --------    --------------------------------------
* Rick Christiansen  11/21/95   Original code                     V1.0
**********************************************************************/

#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <errno.h>

#include "client_app.h"

/* #define DEBUG */
#ifdef      DEBUG
#   define   D(x)  x
#else
#   define   D(x)
#endif

/* #define SHOW_REQ_ANS */
#ifdef      SHOW_REQ_ANS
#   define   S(x)  x
#else
#   define   S(x)
#endif

/* extern int errno; */
#ifdef LINUX
#define LINUXSYSTEM
#endif

#ifdef LINUXBIG
#define LINUXSYSTEM
#endif 

#ifndef LINUXSYSTEM
extern char *sys_errlist[];
#endif

extern FILE    *log_ptr;
extern int hhg48_enable;

void convert_city_cty_state ();
/* void convert_city_cty_state (); */
int write_to_socket ();

/****************************************************************************/
/*  Name         :  PROCESS_REQUESTS ()                                     */
/*                                                                          */
/*  Description  :                                                          */
/*                                                                          */
/*  Input        :                                                          */
/*                                                                          */
/*  Output       :                                                          */
/*                                                                          */
/*  Called By    :                                                          */
/*                                                                          */
/*  REVISIONS                                                               */
/*                                                                          */
/*          Name                Date        Description of Change     Nbr   */
/* -------------------------  --------  ----------------------------  ----  */
/* Rick Christiansen          11/22/95  Original Code                 V1.0  */
/****************************************************************************/

int process_requests (socket_fd)
int socket_fd;
{
   USER_IN_STRUCT user_input;
   REQ_RECORDS req_recs;
   int cont = YES;
   int i, j, k;
   int ret_val = 0;

   D(fprintf(log_ptr,"---> process_requests()\n");)
   D(fflush(log_ptr);)

   /* start block of code to get city, SPLC or ZIP input from keyboard */

   bzero((char *)&user_input, sizeof(user_input));
   D(fprintf(log_ptr,"sizeof(user_input) = %d\n", sizeof(user_input));)
   D(fflush(log_ptr);)
   memcpy(user_input.req_type, "ZZ", 2);

   while ((memcmp (user_input.req_type,
      "MI", (size_t)2) != 0)  &&
      (memcmp (user_input.req_type,
      "OP", (size_t)2) != 0)  &&
      (memcmp (user_input.req_type,
      "MD", (size_t)2) != 0)  &&
      (memcmp (user_input.req_type,
      "HA", (size_t)2) != 0)  &&
      (memcmp (user_input.req_type,
      "HS", (size_t)2) != 0)  &&
      (memcmp (user_input.req_type,
      "HB", (size_t)2) != 0)  &&
      (memcmp (user_input.req_type,
      "PR", (size_t)2) != 0)  &&
      (memcmp (user_input.req_type,
      "PS", (size_t)2) != 0)  &&
      (memcmp (user_input.req_type,
      "PB", (size_t)2) != 0)  &&
      (memcmp (user_input.req_type,
      "PM", (size_t)2) != 0)  &&
      (memcmp (user_input.req_type,
      "Q", (size_t)1) != 0))

   {
      D(fprintf(log_ptr,"INSIDE memcmp whiles\n");)
      D(fflush(log_ptr);)
      bzero((char *)&user_input, sizeof(user_input));
      
	  fprintf(stdout,"Enter request type MI, OP, MD, HA, HS, HB,");
      fprintf(stdout," PR, PS, PB, PM or Q (to quit)\n");
      for (k = 0; k < sizeof (user_input.req_type); k++)
      {
         user_input.req_type[k] = toupper(getc(stdin));
         if (user_input.req_type[k] == '\n')
         {
            user_input.req_type[k] = '\0';
            break;
         }
      }
   }
   if (user_input.req_type[0] == 'Q')
      return (QUIT);
   
   /* krishna koney - 48ft support */
   memset(user_input.trailer_length, ' ', 2);
   if (hhg48_enable)
   {
      while(1)
      {
	   if( (strcmp(user_input.trailer_length,"48") != 0) && (strcmp(user_input.trailer_length,"53") != 0))
	   {
		   fprintf(stdout,"Trailer Length is either 48 or 53 ... Please enter Trailer Length( 48 or 53 )\n");
		   for (k = 0; k < sizeof (user_input.trailer_length); k++)
		   {
			 user_input.trailer_length[k] = toupper(getc(stdin));
			 if (user_input.trailer_length[k] == '\n')
			 {
				user_input.trailer_length[k] = '\0';
				break;
			 }
		   }
                   if(user_input.trailer_length[0] == 0)
                   {
                        strcpy(user_input.trailer_length,"99");
                        break;
                   }
	           else if( (strcmp(user_input.trailer_length,"48") != 0) && (strcmp(user_input.trailer_length,"53") != 0))
		   {
                        strcpy(user_input.trailer_length,"95");
			break;
		   }
	   }
	   else
		   break;

      }
   }

   while (cont == YES)
   {
      for (i = 0; i < MAX_CITIES; i++)
      {
		 fprintf(stdout,
         "Enter city name, SPLC or zip code for location %d "
         , i + 1);
         if(i > 1) /* user needs to input 2 or more locations */
            fprintf(stdout,"or ENTER to process request\n");
         else
            fprintf(stdout,"\n");

         for (k = 0; k < sizeof(user_input.req_city[k]); k++)
         {
            user_input.req_city[i][k] = toupper(getc(stdin));
            if (user_input.req_city[i][k] == '\n')
            {
               user_input.req_city[i][k] = '\0';
               break;
            }
         }
         if (user_input.req_city[i][0] == '\0')
         {
            cont = NO;
            break;
         } /* end of if */
      } /* end of for */
      cont = NO;
   } /* end of while */

   /* end block of code to get city, SPLC or ZIP input from keyboard */

   /* call format_req() to properly format requests */
   ret_val = format_req(&user_input, &req_recs);
   D(fprintf(log_ptr,"ret_val from format_req() = %d\n", ret_val);)
   D(fprintf(log_ptr,"req_recs after format_req() = <%s>\n",req_recs);)
   D(fflush(log_ptr);)

   /* write request records to TCP socket */
   ret_val = write_to_socket(socket_fd, &req_recs);
   D(fprintf(log_ptr,"ret_val from write_to_socket() = %d\n", ret_val);)
   if (ret_val != 0)
   {
      errexit("ret_val = %d from write_to_socket\n", ret_val);
   } /* ret_val no good print error and exit */

   /* read answer records from TCP socket */
   ret_val = read_from_socket(socket_fd, &req_recs);
   D(fprintf(log_ptr,"ret_val from read_from_socket() = %d\n", ret_val);)
   if (ret_val != 0)
   {
      errexit("ret_val = %d from read_from_socket\n", ret_val);
   } /* ret_val no good print error and exit */
   return(ret_val);
}

/****************************************************************************/
/*  Name         :  FORMAT_REQ ()                                           */
/*                                                                          */
/*  Description  :                                                          */
/*                                                                          */
/*  Input        :                                                          */
/*                                                                          */
/*  Output       :                                                          */
/*                                                                          */
/*  Called By    :                                                          */
/*                                                                          */
/*  REVISIONS                                                               */
/*                                                                          */
/*          Name                Date        Description of Change     Nbr   */
/* -------------------------  --------  ----------------------------  ----  */
/* Rick Christiansen          11/22/95  Original Code                 V1.0  */
/****************************************************************************/

int format_req (user_input, req_recs)
USER_IN_STRUCT *user_input;
REQ_RECORDS *req_recs;
{
   int j;
   char city[19];
   char county[3];
   char state[3];
   int jj = 0;

   D(fprintf(log_ptr,"----> format_req() function\n");)

   memset ((char *)req_recs, ' ', sizeof(struct request));
   D(fprintf(log_ptr,"Initial setting or req_recs to spaces = <%s>\n",req_recs);)
   D(fflush(log_ptr);)


   jj = 0;
   for (j = 0; ; j++)
   {
      /*
      D(fprintf(log_ptr,"Current req_city[%d] = <%s>\n",
      j, user_input->req_city[j]);)
      D(fprintf(log_ptr,"Next req_city[%d] = <%s>\n",
      j + 1, user_input->req_city[j + 1]);)
      D(fflush(log_ptr);)
      */

      if (j == 0)
      {
         /* build HR (header) record */
         memcpy(req_recs->u_header.header.header_type, "HR", 2);
         memcpy(req_recs->u_header.header.request_type,
         user_input->req_type, 2);
      }
	  /* krishna koney - 48ft support */
	  else if (j == 1)
	  {
		if (!hhg48_enable || memcmp(user_input->trailer_length, "99", 2) == 0)
		{
		   jj = 1;
		   continue;
		}
		memcpy(req_recs->stopoff[j - 1].rtype, "TL", 2);
		memcpy(req_recs->stopoff[j - 1].rtype+2, user_input->trailer_length, 2);
	  }
      else if (j == 2)
      {
         /* build OR (origin) record */
         memcpy(req_recs->stopoff[j - 1- jj].rtype, "OR", 2);
         /* need to take inputted city and convert to city, county, state */

         bzero(city, sizeof(city));
         bzero(county, sizeof(county));
         bzero(state, sizeof(state));

         convert_city_cty_state(user_input->req_city[j - 2],
         city, county, state);
         D(fprintf(log_ptr,"1st city = <%s>..county = <%s>..state = <%s>\n",
         city, county, state);)
         D(fflush(log_ptr);)

         memcpy(req_recs->stopoff[j - 1- jj].city, city, strlen(city));

         if(county[0] != '\0')
            memcpy(req_recs->stopoff[j - 1- jj].county, county, 2);

         if(state[0] != '\0')
            memcpy(req_recs->stopoff[j - 1- jj].state, state, 2);

      }
      else if (user_input->req_city[j-1][0] != '\0' && j < 14 && j > 1)
      {
         /* build VI (via) record */
         memcpy(req_recs->stopoff[j - 1- jj].rtype, "VI", 2);

         bzero(city, sizeof(city));
         bzero(county, sizeof(county));
         bzero(state, sizeof(state));

         convert_city_cty_state(user_input->req_city[j - 2],
         city, county, state);
         D(fprintf(log_ptr,"2nd city = <%s>..county = <%s>..state = <%s>\n",
         city, county, state);)
         D(fflush(log_ptr);)

         memcpy(req_recs->stopoff[j - 1- jj].city, city, strlen(city));

         if(county[0] != '\0')
            memcpy(req_recs->stopoff[j - 1- jj].county, county, 2);

         if(state[0] != '\0')
            memcpy(req_recs->stopoff[j - 1- jj].state, state, 2);

      }
      else
      {
         /* build DT (destination) record */
         memcpy(req_recs->stopoff[j - 1- jj].rtype, "DT", 2);
         /* need to take inputted city and convert to city, county, state */

         bzero(city, sizeof(city));
         bzero(county, sizeof(county));
         bzero(state, sizeof(state));

         convert_city_cty_state(user_input->req_city[j - 2],
         city, county, state);
         D(fprintf(log_ptr,"3rd city = <%s>..county = <%s>..state = <%s>\n",
         city, county, state);)
         D(fflush(log_ptr);)

         memcpy(req_recs->stopoff[j - 1- jj].city, city, strlen(city));

         if(county[0] != '\0')
            memcpy(req_recs->stopoff[j - 1- jj].county, county, 2);

         if(state[0] != '\0')
            memcpy(req_recs->stopoff[j - 1- jj].state, state, 2);

         req_recs->stopoff[j - jj ].rtype[0] = '\0';
         break;  /* break out of for loop */
      }

   } /* end of for loop */

   S(fprintf(log_ptr,"FORMATTED REQUEST RECORDS = \n<%s>\n",
   (char *)req_recs->u_header.header_rec);)
   S(fflush(log_ptr);)
   D(fprintf(stdout,"length of request records = %d btyes\n",
   strlen(req_recs->u_header.header_rec));)
   D(fprintf(log_ptr,"FORMATTED REQUEST RECORDS = \n<%s>\n",
   (char *)req_recs->u_header.header_rec);)
   D(fprintf(log_ptr,"length of request records = %d bytes\n",
   strlen(req_recs->u_header.header_rec));) 
   return (0);
}

/****************************************************************************/
/*  Name         :  WRITE_TO_SOCKET ()                                      */
/*                                                                          */
/*  Description  :                                                          */
/*                                                                          */
/*  Input        :                                                          */
/*                                                                          */
/*  Output       :                                                          */
/*                                                                          */
/*  Called By    :                                                          */
/*                                                                          */
/*  REVISIONS                                                               */
/*                                                                          */
/*          Name                Date        Description of Change     Nbr   */
/* -------------------------  --------  ----------------------------  ----  */
/* Rick Christiansen          11/22/95  Original Code                 V1.0  */
/****************************************************************************/

int write_to_socket(socket_fd, rec_recs)
int socket_fd;
REQ_RECORDS *rec_recs;
{
   int ret_val = 0;

   D(fprintf(log_ptr, "---> write_to_socket()\n");)
   D(fprintf(log_ptr, "rec_recs = <%s>\n", rec_recs);)
   D(fprintf(log_ptr, "length of rec_recs = %d\n", strlen((char *)rec_recs));)
   D(fflush(log_ptr);)
   ret_val = write(socket_fd, rec_recs, strlen((char *)rec_recs));
   if (ret_val == -1)
   {
      errexit("ret_val = %d from write_to_socket\n", ret_val);
   }
   return(0);
}

/****************************************************************************/
/*  Name         :  READ_FROM_SOCKET ()                                     */
/*                                                                          */
/*  Description  :                                                          */
/*                                                                          */
/*  Input        :                                                          */
/*                                                                          */
/*  Output       :                                                          */
/*                                                                          */
/*  Called By    :                                                          */
/*                                                                          */
/*  REVISIONS                                                               */
/*                                                                          */
/*          Name                Date        Description of Change     Nbr   */
/* -------------------------  --------  ----------------------------  ----  */
/* Rick Christiansen          11/22/95  Original Code                 V1.0  */
/* Louis London               8/25/07   For SCO break out of loop     V1.1  */
/*                                      when buflen is 0                    */
/****************************************************************************/

int read_from_socket (socket_fd, rec_recs)
int socket_fd;
REQ_RECORDS *rec_recs;
{
   int curr_rec = 0;
   char *pbuffer;
   int buflen;
   int n = 0;
   int number_ans_recs = 0;
   char buf[MAX_NUB_RECS][ANSWER_REC_SIZE];

   D(fprintf(log_ptr,"---> read_from_socket()\n");)
   D(fflush(log_ptr);)

   bzero(buf, sizeof(buf));

   D(fprintf(log_ptr,
   "\nREQUEST RECORDS BACK FROM SERVER read_from_socket ARE:\n");)
   D(fflush(log_ptr);)
   D(fprintf(stdout,
   "\nREQUEST RECORDS BACK FROM SERVER read_from_socket ARE:\n");)
   D(fflush(stdout);)

   for (curr_rec = 0; curr_rec < MAX_NUB_RECS; curr_rec++)
   {
      D(fprintf(log_ptr,"INSIDE for in read_from_socket\n");)
      D(fprintf(log_ptr,"curr_rec <%d>\n", curr_rec);)
      pbuffer = buf[curr_rec];
      buflen = ANSWER_REC_SIZE;
      /*
      this while loop is necessary since TCP/IP will deliver
      the information but not necessarily in 71 char block sizes
      */
      while ((n = read (socket_fd, pbuffer, buflen)) > 0)
      {
         D(fprintf(log_ptr,"INSIDE while in read_from_socket..");)
         D(fprintf(log_ptr,"buflen = %d", buflen);)
         pbuffer += n;  /* increment pointer to buf by num of bytes read */
         buflen -= n;   /* reduce requested num of bytes to read by the
         num of bytes already read */
#ifdef SCO
         if (buflen <= 0)
            break;
#endif
      }

      if (n < 0)
         errexit ("socket read failed:  %s\n", sys_errlist[errno]);

      D(fprintf(log_ptr, "read_from_socket <%s>\n", &buf[curr_rec]);)
      D(fflush(log_ptr);)
      D(fprintf(stdout, "read_from_socket <%s>\n", &buf[curr_rec]);)
      D(fflush(stdout);)

      number_ans_recs++;
      if (memcmp (&buf[curr_rec], END_RECORD, 2) == 0)
      {
         break;
      }

      if (number_ans_recs >= MAX_NUB_RECS)
      {
         errexit ("TOO many answer records:  %d\n", number_ans_recs);
      }
   }

   display_answers(&buf, number_ans_recs);

   return(0);
}

/****************************************************************************/
/*  Name         :  DISPLAY_ANSWERS ()                                      */
/*                                                                          */
/*  Description  :                                                          */
/*                                                                          */
/*  Input        :                                                          */
/*                                                                          */
/*  Output       :                                                          */
/*                                                                          */
/*  Called By    :                                                          */
/*                                                                          */
/*  REVISIONS                                                               */
/*                                                                          */
/*          Name                Date        Description of Change     Nbr   */
/* -------------------------  --------  ----------------------------  ----  */
/* Rick Christiansen          11/22/95  Original Code                 V1.0  */
/****************************************************************************/

int display_answers(buf, number_ans_recs)
char *buf;
int number_ans_recs;
{
   char curr_ans_rec[ANSWER_REC_SIZE + 1];

   D(fprintf(log_ptr,"---> display_answers()..%d ans recs\n",
   number_ans_recs);)
   D(fflush(log_ptr);)
   S(fprintf(log_ptr,"\nANSWER RECORDS BACK FROM SERVER ARE:\n");)
   S(fflush(log_ptr);)
   fprintf(stdout,"\nANSWER RECORDS BACK FROM SERVER ARE:\n");
   fflush(stdout);

   for ( ; *buf != '\0'; buf += ANSWER_REC_SIZE)
   {
      memcpy(curr_ans_rec, buf, ANSWER_REC_SIZE);
      curr_ans_rec[ANSWER_REC_SIZE] = '\0';
      fprintf(stdout,"<%s>\n", curr_ans_rec);
      S(fprintf(log_ptr,"<%s>\n", curr_ans_rec);)
      S(fflush(log_ptr);)
   }
   return (0);
}

/****************************************************************************/
/*  Name         :  CONVERT_CITY_CTY_STATE()                                */
/*                                                                          */
/*  Description  :                                                          */
/*                                                                          */
/*  Input        :                                                          */
/*                                                                          */
/*  Output       :                                                          */
/*                                                                          */
/*  Called By    :                                                          */
/*                                                                          */
/*  REVISIONS                                                               */
/*                                                                          */
/*          Name                Date        Description of Change     Nbr   */
/* -------------------------  --------  ----------------------------  ----  */
/* Rick Christiansen          11/22/95  Original Code                 V1.0  */
/****************************************************************************/

void convert_city_cty_state (in_city, city, county, state)
char *in_city;
char *city;
char *county;
char *state;
{
   int i = 0;
   int num_commas = 0;

   D(fprintf(log_ptr,"---> convert...() in_city = <%s>\n", in_city);)

   /* determine the number of commas in the user input*/
   /* if none, we have SPLC or ZIP code */
   /* if one, we have city, st */
   /* if two, we have city, county, st */
   for (i = 0; i < LINELEN; i++)
   {
      if (*(in_city + i) == ',')
         num_commas++;
   }

   if(num_commas == 0)   /* SPLC or ZIP */
   {
      for (i = 0; *in_city != '\0' && i < 18; city++, in_city++, i++)
      {
         *city = *in_city;
      }
      *city = '\0';
   }
   else if (num_commas == 1) /* city, state */
   {
      for (i = 0; *in_city != ',' && i < 18; city++, in_city++, i++)
      {
         *city = *in_city;
         D(fprintf(log_ptr,"*city = %c\n", *city);)
         D(fflush(log_ptr);)
      }
      *city = '\0';
      D(fprintf(log_ptr,"city = <%s>\n", city);)

      in_city++; /* move pointer over ',' */

      for (i = 0; i < 2; i++, state++, in_city++)
      {
         *state = *in_city;
      }
      *state = '\0';
      D(fprintf(log_ptr,"state = <%s>\n", state);)

   }
   else   /* city, county, state */
   {
      for (i = 0; *in_city != ',' && i < 18; city++, in_city++, i++)
      {
         *city = *in_city;
      }
      *city = '\0';

      in_city ++; /* move pointer over ',' */

      for (i = 0; i < 2; i++, county++, in_city++)
      {
         *county = *in_city;
      }
      *county = '\0';

      in_city++; /* move pointer over ',' */

      for (i = 0; i < 2; i++, state++, in_city++)
      {
         *state = *in_city;
      }
      *state = '\0';
   }
}
