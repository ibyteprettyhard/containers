/****************************************************************/
/* Version: 17.3                                           */
/* File   : client_app1.c                                           */
/* Changed: 5/28/97                                           */
/****************************************************************/

#include <randcurses.h>
#include <fcntl.h>
#include <memory.h>

#include <paint_menu.h>
#include <keys.h>
#include <errno.h>

/* #define DEBUG */
#ifdef DEBUG
#define D(x) x
#else
#define D(x)
#endif

extern int hhg48_enable;


CONSTANT_STRUCT geo_maint[] =
{
   { 0,  32, "RAND McNALLY"   },
   { 1,  29, "CLIENT APPLICATION"   },
   { 1,  60, "Copyright 2009"       }, /* Guide 18 changes */
   { 2,  60, " Rand McNally"        },
   { 6,  15, "F1 - INQUIRY"         },
   { 7,  15, "F2 - EXIT"            }
};


CONSTANT_STRUCT geo_constant[] =
{
   { 0,  28, "MILEMAKER"           },
   { 1,  24, "CLIENT APPLICATION"  },
   { 4,  60, "F3-CLEAR"            },
   { 5,  60, "F4-PREV MENU"        }
};

USER_MAINT_STRUCT geo_inq[] =
{
   {0, 1, "Copyright 2009"       }, /* Guide 18 changes */
   {1, 1, " Rand McNally"      },
   {0, 59, "Canadian Postal Codes"},
   {1, 67, "(C) 2008"},
   {2, 63, "DMTI Spatial Inc."},
   {5,  5, "CITY:", 5, 10, ".................."},
   {5, 30, "CNTY:", 5, 35, ".."},
   {5, 38, "ST:", 5, 41, ".."},
   {6,  5, "CITY:", 6, 10, ".................."},
   {6, 30, "CNTY:", 6, 35, ".."},
   {6, 38, "ST:", 6, 41, ".."},
   {7,  5, "CITY:", 7, 10, ".................."},
   {7, 30, "CNTY:", 7, 35, ".."},
   {7, 38, "ST:", 7, 41, ".."},
   {8,  5, "CITY:", 8, 10, ".................."},
   {8, 30, "CNTY:", 8, 35, ".."},
   {8, 38, "ST:", 8, 41, ".."},
   {9,  5, "REQUEST:", 9, 13, ".."},
   {10,  5, "TRAILER LENGTH:", 10, 20, ".."},
};

int GEO_MAINT_LINE = ((sizeof(geo_maint))/sizeof(struct constants));
int GEO_CONST_LINE = ((sizeof(geo_constant))/sizeof(struct constants));
int GEO_INQ_LINE = ((sizeof(geo_inq))/sizeof(struct pwd_lines));
int hhg48_enable;

void paint_scrn(scrn_type)
int scrn_type;
{
   int i, j;
   int write_cnt;
   int geo_inq_line;


   if (hhg48_enable)
       geo_inq_line = GEO_INQ_LINE;
   else
       geo_inq_line = GEO_INQ_LINE - 1;

   move(0, 0);
   clear();
   standout();

   switch (scrn_type)
   { /* Paint the screen so text is easier to see against a background. */
      case MAIN_MENU:  /* Painting the main menu */
         for (i = 0; i < 2; i++)
            mvaddstr(geo_maint[i].cy,geo_maint[i].cx,geo_maint[i].cstring);
         standend();
         for (i = 2; i < GEO_MAINT_LINE; i++)
            mvaddstr(geo_maint[i].cy,geo_maint[i].cx,geo_maint[i].cstring);
         break;

      case GEO_INQ:  /* Painting the inquiry screen */
         for (i = 0; i < 2; i++)
            mvaddstr(geo_constant[i].cy, geo_constant[i].cx,
            geo_constant[i].cstring);
         standend();
         for (i = 2; i < GEO_CONST_LINE; i++)
            mvaddstr(geo_constant[i].cy, geo_constant[i].cx,
            geo_constant[i].cstring);

         for (i = 0; i < geo_inq_line; i++)
         {
            mvaddstr(geo_inq[i].yprompt, geo_inq[i].xprompt,
            geo_inq[i].prompt);
            mvaddstr(geo_inq[i].yloc, geo_inq[i].xloc,geo_inq[i].user_inp);
         }
         break;

      default:
         break;
   } /* switch(scrn_type) */
   refresh();
}
