/*********************************************************************
 *    Source Name:       tcp_func.c
 *
 *    Description:       The source file contains the necessary functions
 *                       to setup the TCP/IP sockets for the ACA that 
 *                       uses TCP/IP to integrate with the URMM product.
 *                     
 *
 *    Functions Called:  reaper(), passiveTCP(), passivesock()
 *                       and errexit()
 *
 *    Called By:         NONE.
 *
 *    History:
 *
 *        Name         Date           Description Of Change
 *   --------------  --------    --------------------------------------
 * Rick Christiansen  4/17/96    Original version
 * Girish Deshmukh    7/22/04    Added a check for PID < 32. We refork V1.1
 *                               till the PID is not greater than 32
 *                               We use some hard coded msg ids which
 *                               were interfering with PIDs lower than
 *                               32. 
 **********************************************************************/ 


#include <sys/types.h>

/* #define _INCLUDE_HPUX_SOURCE */
/* #define _PROTOTYPES */
#define _SVID2 
#include <sys/signal.h>

#include <sys/socket.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <strings.h>

#include <stdio.h>
#ifdef HPUX
#include <varargs.h>
#else
#include <stdarg.h>
#endif
#include <envname.h>

/* #define DEBUG */
#ifdef      DEBUG
#   define   D(x)  x
#else
#   define   D(x)
#endif

#define QLEN        5    /* maximum connection queue length */
#define BUFSIZE  4096

#ifdef LINUX
#define SKIPERROR
#endif

#ifdef LINUXBIG
#define SKIPERROR
#endif

#ifndef SKIPERROR
extern int errno;
extern char *sys_errlist[]; 
#endif

FILE *log_ptr2;
char *SERVER_LOG_PATH;
/* #define SERVER_LOG_PATH   "server.log" */

/*********************************************************************
*    Function Name:     errexit()
*
*    Description:       This function is called when a non-recoverable
*                       error has occured and the process needs to be
*                       stopped. It takes as an argument strings that
*                       will print appropiate error messages.
*
*    Called By:         main() and passivesock().
*
*    Returns:           None.
*
*    History:
*
*        Name           Date           Description Of Change
*   --------------    --------    --------------------------------------
*   Rick Christiansen  4/17/96    Original Version
**********************************************************************/
#ifdef HPUX
int errexit (format, va_alist)
char *format;
va_dcl
{
   va_list args;

   va_start (args);
   _doprnt (format, args, stderr);
   va_end (args);
   exit (1);
}
#else
int errexit (char *fmt, ...)
{
   va_list args;

   va_start (args, fmt);
   vprintf(fmt, args);
   va_end (args);
   exit (1);
}
#endif

void  reaper();

/*********************************************************************
*    Function Name:     setup_socket()
*
*    Description:       The is the setup_socket() function for the tcp_aca
*                       process.  It calls various functions to create
*                       and setup a TCP/IP socket and forks copies of 
*                       itself when a TCP/IP client attaches to the main
*                       tcp_aca process.
*
*    Called By:         None.
*
*    Returns:           None.
*
*    History:
*
*        Name           Date           Description Of Change
*   --------------    --------    --------------------------------------
*   Rick Christiansen  4/17/96    Original Version
**********************************************************************/
int setup_socket()
{
   char *service = "echo";        /* service name or port number */
   struct sockaddr_in fsin;       /* the address of a cleint     */
   int alen;                      /* length of client's address  */
   int msock;                     /* master server socket        */
   int ssock;                     /* slave server socket         */
   int pid;
   int pid2;

   get_env();
   SERVER_LOG_PATH = getenv ("SERVER_LOG_PATH\0"); 

   D(log_ptr2 = fopen(SERVER_LOG_PATH, "w");)
   D(if (log_ptr2 == NULL))
   D({)
      D(printf("BAD open(%s)\n", SERVER_LOG_PATH);)
   D(})
   /*
   switch (argc)
   {
      case    1:
              break;
      case    2:
              service = argv[1];
              break;
      default  :
              errexit("usage:  TCPechod [port]\n");
   } */ /* end of "switch (argc)" */

   msock = passiveTCP (service, QLEN);

   (void) sigset (SIGCHLD, reaper);

   while (1)
   {
      alen = sizeof(fsin);
      ssock = accept (msock, (struct sockaddr *)&fsin, &alen);
      if (ssock < 0)
      {
         if (errno == EINTR)
            continue;
         errexit ("accept:  %s\n", sys_errlist[errno]);
      } /* end of "if (ssock < 0)" */
      D(fprintf(log_ptr2,"before fork\n");)
      D(fflush(log_ptr2);)
      while(pid = fork()) /* V1.1 */
      {
	if(pid > 32 || pid == -1) 
	    break;
      }
      switch (pid) 
      {
         case     0:                          /* child process */
                      pid2 = getpid(); /* V1.1 */
                      if (pid2 > 32)
                      {

                      	(void) close (msock);
                        /* change the next line to start the ACA */
      			D(fprintf(log_ptr2,"executed case 0\n");)
      			D(fflush(log_ptr2);)
                        exit (reader (ssock, 0, "TCP"));
                      }
                      else
                      {
		         quit();
                      }

         case    -1:
      D(fprintf(log_ptr2,"executed case -1\n");)
      D(fflush(log_ptr2);)
                      errexit ("fork:  %s\n", sys_errlist[errno]);

         default   :                          /* parent process */
      D(fprintf(log_ptr2,"executed case default\n");)
      D(fflush(log_ptr2);)
                      (void) close (ssock);
      D(fprintf(log_ptr2,"after close\n");)
      D(fflush(log_ptr2);)
                      break;


      } /* end of "switch (fork())" */
      D(fprintf(log_ptr2,"after switch\n");)
      D(fflush(log_ptr2);)
   } /* end of "while (1)" */
      D(fprintf(log_ptr2,"after end while\n");)
      D(fflush(log_ptr2);)
}  /* end of "int main(int argc, char *argv[])" */


/*
int TCPechod (fd)
int fd;
{
   char buf [BUFSIZ];
   int cc;

   while (cc = read (fd, buf, sizeof buf))
   {
      if (cc < 0)
         errexit ("echo read:  %s\n", sys_errlist[errno]);
      if (write (fd, buf, cc) < 0)
         errexit ("echo write:  %s\n", sys_errlist[errno]);
   }    end of "while (cc = read (fd, buf, sizeof(buf)"

   return 0;
}*/  /* end of "int TCPechod (int fd)" */


/*********************************************************************
*    Function Name:     reaper()
*
*    Description:       This function handles the removal of child tcp_aca
*                       processes that were fork and no longer needed.  This
*                       function traps the SIGCHLD signal.
*
*    Called By:         main().
*
*    Returns:           None.
*
*    History:
*
*        Name           Date           Description Of Change
*   --------------    --------    --------------------------------------
*   Rick Christiansen  4/17/96    Original Version
*   Girish Deshmukh    6/10/04    Updated waitpid call 
**********************************************************************/
void reaper(sig)
int sig;
{
   /* union wait status; Guide 18 */
   int status; /* Guide 18 */
   pid_t ret_value;

   D(fprintf(log_ptr2,"Entering %s() function\n", "reaper");)
   D(fflush(log_ptr2);)
   D(fprintf(log_ptr2,"sig <%d>\n", sig);)
   D(fflush(log_ptr2);)
   while (waitpid(-1, &status, WNOHANG) > 0)
             ;   /* no-operation while statement */
   D(fprintf(log_ptr2,"after waitpid call\n");)
   D(fflush(log_ptr2);)
} /* end of "int reaper()" */



/*********************************************************************
*    Function Name:     passiveTCP()
*
*    Description:       This function begins the process of setting up a
*                       passive TCP socket for the tcp_aca process.
*
*    Called By:         main().
*
*    Returns:           It returns an integer file discriptor for the socket.
*
*    History:
*
*        Name           Date           Description Of Change
*   --------------    --------    --------------------------------------
*   Rick Christiansen  4/17/96    Original Version
**********************************************************************/
int passiveTCP(service, qlen)
char *service;     /* service associated with the disired port */
int  qlen;         /* maximum server request queue length      */
{
   return passivesock(service, "tcp", qlen);
} /* end of "int passiveTCP(char *service, int qlen)" */


/*********************************************************************
*    Function Name:     passivesock()
*
*    Description:       This function allocates and binds a server socket
*                       using either TCP or UDP.  In our case we specify
*                       TCP as an argument to the function.
*
*    Called By:         main().
*
*    Returns:           It returns the integer file discriptor for a socket.
*
*    History:
*
*        Name           Date           Description Of Change
*   --------------    --------    --------------------------------------
*   Rick Christiansen  4/17/96    Original Version
**********************************************************************/

/* #define _HPUX_SOURCE */

#include <sys/types.h>
#include <sys/socket.h>

#include <netinet/in.h>

#include <netdb.h>

/* extern int errno;
extern char *sys_errlist[]; */

/* u_short htons(), ntohs(); */

u_short portbase;        /* port base for non-root servers */


/*********************************************************************
*    Function Name:     passivesock()
*
*    Description:       This function allocates and binds a server socket
*                       using either TCP or UDP.  In our case we specify
*                       TCP as an argument to the function.
*
*    Called By:         main().
*
*    Returns:           It returns the integer file discriptor for a socket.
*
*    History:
*
*        Name           Date           Description Of Change
*   --------------    --------    --------------------------------------
*   Rick Christiansen  4/17/96    Original Version
*   Louis London       12/3/07    Change to use Environment var   V1.1
*                                 rather than hard coded port
**********************************************************************/
int passivesock (service, protocol, qlen)
char *service;
char *protocol;
int qlen;
{
   struct servent *pse;    /* pointer to service information entry */
   struct protoent *ppe;   /* pointer to protocol infomation entry */
   struct sockaddr_in sin; /* an Internet endpoint address         */
   int s, type;            /* socket descriptor and socket type    */
	
   bzero ((char *)&sin, sizeof(sin));
   sin.sin_family = AF_INET;
   sin.sin_addr.s_addr = INADDR_ANY;
   portbase = (atoi(TCP_PORT)) - 7; /* V1.1 */

   /* Map service name to port number */
   if (pse = getservbyname(service, protocol))
      sin.sin_port = htons(ntohs((u_short)pse->s_port) + portbase);
   else if ((sin.sin_port = htons((u_short)atoi (service))) == 0)
      errexit ("can't get \"%s\" protocol entry", service);

   /* Map protocol name to protocol number */
   if ((ppe = getprotobyname(protocol)) == 0)
      errexit ("can't get \"%s\" protocol entry\n", protocol);

   /* Use protocol to choose a socket type */
   if (strcmp(protocol, "udp") == 0)
      type = SOCK_DGRAM;
   else
      type = SOCK_STREAM;

   /* Allocate a socket */
   s = socket (PF_INET, type, ppe->p_proto);
   if (s < 0)
      errexit ("can't create socket:  %s\n", sys_errlist[errno]);
   
   /* Bind the socket */
   if (bind(s, (struct sockaddr *)&sin, sizeof (sin)) < 0)
      errexit ("can't bind to %s port:  %s\n", service, sys_errlist[errno]);

   if (type == SOCK_STREAM && listen (s, qlen) < 0)
      errexit ("can't listen on %s port:  %s\n", service,
               sys_errlist[errno]);

   return s;
} /* end of "int passivesock (char *service, char *protocol, int qlen)" */
