/*********************************************************************
 *    Source Name:       tcp_client.c
 *
 *    Description:       This source sets up the TCP/IP sockets for the
 *                       new TCP/IP generic client application process.
 *
 *    Functions Called:  main()
 *                       setup_socket()
 *                       connectTCP()
 *                       connectsock()
 *                       errexit()
 *
 *    Called By:         NONE.
 *
 *    History:
 *
 *        Name         Date           Description Of Change
 *   --------------  --------    --------------------------------------
 * Rick Christiansen  11/21/95   Original code                     V1.0
 **********************************************************************/ 

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#ifdef HPUX
#include <varargs.h>
#else
#include <stdarg.h>
#endif
#include <errno.h>
 
#include "client_app.h"
#include <envname.h>

/* #define DEBUG */
#ifdef      DEBUG
#   define   D(x)  x
#else
#   define   D(x)
#endif


#ifndef INADDR_NONE
#define INADDR_NONE  0xffffffff
#endif /* INADDR_NONE */

#define QUIT 9999

#ifdef LINUX
#define SKIPERROR
#endif

#ifdef LINUXBIG
#define SKIPERROR
#endif

#ifndef SKIPERROR
extern int errno; 
extern char *sys_errlist[]; 
#endif

FILE	*log_ptr;

u_short portbase;        /* port base for non-root servers */
char *CLIENT_LOG_PATH;

/* function declarations */
int setup_socket ();   /* call the client_app functions */
int process_requests ();
int format_req ();
int write_to_socket ();
int read_from_socket ();
int display_answers ();
int checkconfig();
int hhg48_enable;

/****************************************************************************/
/*  Name         :  errexit                                                 */
/*                                                                          */
/*  Description  :                                                          */
/*                                                                          */
/*  Input        :                                                          */
/*                                                                          */
/*  Output       :                                                          */
/*                                                                          */
/*  Called By    :                                                          */
/*                                                                          */
/*  REVISIONS                                                               */
/*                                                                          */
/*          Name                Date        Description of Change     Nbr   */
/* -------------------------  --------  ----------------------------  ----  */
/* Rick Christiansen          11/21/95  Original code                 V1.0  */
/****************************************************************************/
#ifdef HPUX
int errexit (format, va_alist)
char *format;
va_dcl
{
   va_list args;

   va_start (args);
   _doprnt (format, args, stderr);
   va_end (args);
   exit (1);
}
#else
int errexit (char *fmt, ...)
{
   va_list args;

   va_start (args, fmt);
   vprintf(fmt, args);
   va_end (args);
   exit (1);
}
#endif
/****************************************************************************/
/*  Name         :  main                                                    */
/*                                                                          */
/*  Description  :                                                          */
/*                                                                          */
/*  Input        :                                                          */
/*                                                                          */
/*  Output       :                                                          */
/*                                                                          */
/*  Called By    :                                                          */
/*                                                                          */
/*  REVISIONS                                                               */
/*                                                                          */
/*          Name                Date        Description of Change     Nbr   */
/* -------------------------  --------  ----------------------------  ----  */
/* Rick Christiansen          11/21/95  Original Code                 V1.0  */
/****************************************************************************/
main (argc, argv)
int argc;
char *argv[];
{
   char *host = "localhost"; /* host to use if none supplied */
   char *service = "echo";   /* default service name */
   int ret_val = 0;          /* return value from function calls */
   int socket_fd;            /* socket file discriptor           */

   get_env();
   CLIENT_LOG_PATH = getenv ("CLIENT_LOG_PATH\0");
   hhg48_enable = checkconfig(); 

   log_ptr = fopen(CLIENT_LOG_PATH, "w");
   if (log_ptr == NULL)
   {
      printf("BAD open(%s)\n", CLIENT_LOG_PATH);
   }
   switch (argc)
   {
      case 1:
               host = "localhost";
               break;
      case 3:
               service = argv[2];
               /* fall through */
      case 2:
               host = argv[1];
               break;
      default:
               fprintf(stderr, "usage:  tcp_client [host [port]]\n");
               exit (1);
   } /* end of switch (argc) */

   /* call the setup_socket functions */
   socket_fd = setup_socket(host, service);
   D(fprintf(stderr, "Successfully completed the setup_socket\n");)
   D(fflush(stderr);)

   if (socket_fd < 0)
   {
      errexit ("setup_socket failed\n");
   } /* setup_socket() failed print error and exit */

   /* get cities from keyboard */
   /* forever loop that needs some way to exit */
   for (;;)
   {
      ret_val = process_requests(socket_fd);
      if (ret_val != 0 || ret_val == QUIT)  /* this is the exit point */
      {
         if(ret_val == QUIT)
         {
             close (socket_fd);
             exit (0);
         }
         errexit("ret_val = %d from process_requests\n", ret_val);
      } /* ret_val no good print error and exit */

   }
   exit(ret_val);

} /* end of "main (int argc, char *argv[])" */

/****************************************************************************/
/*  Name         :  setup_socket                                              */
/*                                                                          */
/*  Description  :                                                          */
/*                                                                          */
/*  Input        :                                                          */
/*                                                                          */
/*  Output       :                                                          */
/*                                                                          */
/*  Called By    :                                                          */
/*                                                                          */
/*  REVISIONS                                                               */
/*                                                                          */
/*          Name                Date        Description of Change     Nbr   */
/* -------------------------  --------  ----------------------------  ----  */
/* Rick Christiansen          11/21/95  Original Code                 V1.0  */
/****************************************************************************/
int setup_socket (host, service)
char *host;
char *service;
{
   int s;              /* socket descriptor */

   s = connectTCP(host, service);
   return (s);

} /* end of "int setup_socket (char *host, char *service)" */


/****************************************************************************/
/*  Name         :  connectTCP                                              */
/*                                                                          */
/*  Description  :                                                          */
/*                                                                          */
/*  Input        :                                                          */
/*                                                                          */
/*  Output       :                                                          */
/*                                                                          */
/*  Called By    :                                                          */
/*                                                                          */
/*  REVISIONS                                                               */
/*                                                                          */
/*          Name                Date        Description of Change     Nbr   */
/* -------------------------  --------  ----------------------------  ----  */
/* Rick Christiansen          11/21/95  Original code                 V1.0  */
/****************************************************************************/
int connectTCP(host, service)
char *host; 
char *service;
{
   return connectsock(host, service, "tcp");
}

/****************************************************************************/
/*  Name         :  connectsock                                             */
/*                                                                          */
/*  Description  :                                                          */
/*                                                                          */
/*  Input        :                                                          */
/*                                                                          */
/*  Output       :                                                          */
/*                                                                          */
/*  Called By    :                                                          */
/*                                                                          */
/*  REVISIONS                                                               */
/*                                                                          */
/*          Name                Date        Description of Change     Nbr   */
/* -------------------------  --------  ----------------------------  ----  */
/* Rick Christiansen          11/21/95  Original code                 V1.0  */
/* Louis London               12/03/07  Change to allow env var       V1.1  */
/*                                      rather than hard coded port offset  */
/****************************************************************************/
int connectsock (host, service, protocol)
char *host;     
char *service; 
char *protocol;
{
   struct hostent *phe;    /* pointer to host information entry     */
   struct servent *pse;    /* pointer to service information entry  */
   struct protoent *ppe;   /* pointer to protocol information entry */
   struct sockaddr_in sin; /* an Internet endpoint address          */
   int s, type;            /* socket descriptor and socket type     */

   bzero((char *)&sin, sizeof(sin));
   sin.sin_family = AF_INET;
   portbase = (atoi(TCP_PORT)) - 7; /* V1.1 */

   /* Map service name to port number */
   if (pse = getservbyname(service, protocol))
      sin.sin_port = htons(ntohs((u_short)pse->s_port) + portbase);
      /* sin.sin_port = pse->s_port; */
   else if ((sin.sin_port = htons ((u_short)atoi(service))) == 0)
      errexit("can't get \"%s\" service entry\n", service);

   D(printf("Port # = %d\n",sin.sin_port);)

   /* Map host name to IP address, allowing for dotted decimal */
   if (phe = gethostbyname(host))
   {
      bcopy (phe->h_addr, (char *)&sin.sin_addr, phe->h_length);
      D(printf("IP address # = %ld\n",phe->h_addr);)
   }
   else if ((sin.sin_addr.s_addr = inet_addr (host)) == INADDR_NONE)
      errexit("can't get \"%s\" host entry \n", host);


   /* Map protocol name to protocol number */
   if ((ppe = getprotobyname(protocol)) == 0)
       errexit("can't get \"%s\" protocol entry\n", protocol);

   /* Use protocol to choose a socket type */
   if (strcmp (protocol, "udp") == 0)
      type = SOCK_DGRAM;
   else
      type = SOCK_STREAM;

   /* Allocate a socket */
   s = socket (PF_INET, type, ppe->p_proto);
   if (s < 0)
      errexit ("can't create socket:  %s\n", sys_errlist[errno]);

   /* Connect the socket */
   if (connect (s, (struct sockaddr *)&sin, sizeof(sin)) < 0)
      errexit ("can't connect to %s.%s:  %s\n", host, service,
               sys_errlist[errno]);

   return s;
}
