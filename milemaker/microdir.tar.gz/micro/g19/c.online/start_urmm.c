/****************************************************************/
/* Version: 16.3                                           */
/* File   : start_urmm.c                                           */
/* Changed: 5/28/97                                           */
/****************************************************************/
/********************************************************************
 *
 *  Source File:   start_urmm.c
 *
 *  Description:   The source starts the clients application (ie fuel
 *                 tax, drivers payroll, dispatch, etc) and Rand 
 *                 McNally-TDM's Application Communications Area (ACA)
 *                 so that a client's applications can communicate with
 *                 the rest of Micro-MileMaker mileage and routing
 *                 capabilities.  The client's application and the ACA 
 *                 communicate using the Unix function pipe().  This 
 *                 source file will establish the request and answer
 *                 pipes and fork the client's application and ACA
 *                 program with proper file descriptors to use pipes.
 *
 * Rick Christiansen 5/24/95 Remove Envir. variables    V1.1
 *
 ******************************************************************/
#include <stdio.h>  /* standard I/O header file */
#include <fcntl.h>  /* To use open() call */
#include <errno.h>  /* To use errno return values */
#include <signal.h>  /* To kill processes if one dies */

#include <envname.h>

/*******************************************************************/
/*                                                                 */
/* The following environment variables must be changed for each of */
/* your applications.  You must enter the full path and executable */
/* name of your application as in the example below.		   */
/*                                                                 */
/*******************************************************************/
/* APPL_EXE=/usr/micro/exe/client_app;export APPL_EXE	*/
/* RAND_ACA=/usr/micro/exe/aca;export RAND_ACA		*/
/* #define	APPL_EXE	"/usr/micro/g16/exe/client_app"         V1.1 */
/* #define	RAND_ACA	"/usr/micro/g16/exe/aca"                V1.1 */
/* #define	START_LOG_PATH	"/usr/micro/g16/data/start_urmm.log"    V1.1 */

/*********************************************************************/
/*                                                                   */
/*  The follow #define is a macro which will allow a person to turn  */
/*  on and off debug.  If you want debug in just uncomment the line: */
/*  #define DEBUG.                                                   */
/*                                                                   */
/*********************************************************************/
/* #define DEBUG */
#ifdef DEBUG
#define D(x) x
#else
#define D(x)
#endif

void main()
{
    FILE *log_ptr;        /* File pointer for the debug file.*/
    int fd_req_pipe[2];   /* Request pipe array of file discriptor. */
    int fd_ans_pipe[2];   /* Answer pipe array of file discriptor.  */
    int aca_pid;          /* pid of the ACA program. */
    int appl_pid;         /* pid of the client's program.   */
    int ret_val;          /* return value from func. calls. */
    int status;           /* status of running applications.    */
    int rtn_req_pipe;     /* return value of pipe() calls.      */
    int rtn_ans_pipe;     /* return value of pipe() calls.      */

    char fd_read_req[5];  /* These 4 char strings are used for.   */
    char fd_write_req[5]; /* execl() calls.  They to send file    */
    char fd_read_ans[5];  /* descriptors to the ACA and client's  */
    char fd_write_ans[5]; /* application program.                 */

    get_env();

    log_ptr = fopen(START_LOG_PATH, "w");
    if (log_ptr == NULL)
    {
	printf("BAD open(START_LOG_PATH <%s>)\n", START_LOG_PATH);
    }
    D(fprintf(log_ptr, "GOOD open(start_urmm.log)\n");)
    D(fflush(log_ptr);)

    /* Initializations */
    rtn_req_pipe = 0;
    rtn_ans_pipe = 0;
    ret_val = 0;

    /************************************************************/
    /* pipe(ARG) causes 2 file descriptors to be placed in	*/
    /* a 2 element integer array that needs to have been	*/
    /* declared	for ARG.  ARG[0] is used to read messages	*/
    /* sent via pipes from other processes.  ARG[1] is used	*/
    /* to  write messages via pipes to other processes.		*/
    /************************************************************/

    /* Get identifier for pipe used by client communication	*/
    /* program to send requests to the MileMaker program.	*/
    rtn_req_pipe = pipe(fd_req_pipe);

    /* Get identifier for pipe used by client communication	*/
    /* program to receive responses from the MileMaker program.	*/
    rtn_ans_pipe = pipe(fd_ans_pipe);

    /* Make certain that no error took place creating either */
    /* pipe above.  If none took place, prepare to send the  */
    /* pipe id values to the client communication program.   */
    if((rtn_req_pipe != -1) && (rtn_ans_pipe != -1))
    {
	D(fprintf(log_ptr,"read_req_pipe fd %d\n",fd_req_pipe[0]);)
	D(fprintf(log_ptr,"write_req_pipe fd %d\n",fd_req_pipe[1]);)
	D(fprintf(log_ptr,"read_ans_pipe fd %d\n",fd_ans_pipe[0]);)
	D(fprintf(log_ptr,"write_ans_pipe fd %d\n",fd_ans_pipe[1]);)

	/* Convert the numberic value for the pipes to string	*/
	/* values so they can be sent most efficiently to the	*/
	/* client communication using the execl() statements	*/
	/* below and received the the client program using	*/
	/* argv[] which expects (char *) parameters.		*/
	sprintf(&fd_read_req[0],  "%04d", fd_req_pipe[0]);
	sprintf(&fd_write_req[0], "%04d", fd_req_pipe[1]);
	sprintf(&fd_read_ans[0],  "%04d", fd_ans_pipe[0]);
	sprintf(&fd_write_ans[0], "%04d", fd_ans_pipe[1]);

	D(fprintf(log_ptr,"fd_read_req  (char) = <%s>\n",fd_read_req );)
	D(fprintf(log_ptr,"fd_write_req (char) = <%s>\n",fd_write_req);)
	D(fprintf(log_ptr,"fd_read_ans  (char) = <%s>\n",fd_read_ans );)
	D(fprintf(log_ptr,"fd_write_ans (char) = <%s>\n",fd_write_ans);)

        /*************************************************************/
        /*  The following fork() call begins the process of starting */
        /*  TDM's ACA program.                                       */
        /*************************************************************/
	aca_pid = fork();
	D(fprintf(log_ptr,"RAND_ACA pid %d\n", aca_pid);)
	D(fflush(log_ptr);)
	if (aca_pid == 0)
	{
	    D(fprintf(log_ptr,"Just forked RAND_ACA\n");)
	    D(fflush(log_ptr);)

            /****************************************************/
            /* The ACA application requires the fd_read_req and */
            /* fd_write_ans file descriptors to communicate     */
            /* with the client's applications                   */
            /*                                                  */
	    /* The next statement starts the ACA program.	*/
	    /* The fd_read_req parameter is used by ACA to take	*/
	    /* requests from the user communication program.	*/
	    /* The fd_write_ans parameter is used by ACA to	*/
	    /* send responses back to the user communication	*/
	    /* program.  RAND_ACA is the name of the program	*/
	    /* is the name of the ACA.  This is the program	*/
	    /* provided by TDM that allows you to calculate	*/
	    /* hhg mileages by accessing MileMaker using pipes.	*/
            /****************************************************/
	    ret_val = execl(RAND_ACA, RAND_ACA, fd_read_req, fd_write_ans,
		 (char *)0);

	    D(fprintf(log_ptr,"Immediately after EXECL(RAND_ACA)\n");)
	    D(fflush(log_ptr);)
	    if(ret_val != 0)
	    {
		D(fprintf(log_ptr,
		    "1 EXECL to TEST failed ret_val %d\n", ret_val);)
		D(fprintf(log_ptr,
		    "1 EXECL to TEST failed errno = %d\n", errno);)
		D(fflush(log_ptr);)
	 
		perror("start_urmm: 1 EXECL() error ");
		exit(1);
	    }
	    D(fprintf(log_ptr,"After EXECL(RAND_ACA) if\n");)
	    D(fflush(log_ptr);)
	}
	else
	{
	    /* Make an empty process to run the client application */
	    appl_pid = fork();
	    D(fprintf(log_ptr,"APPL_EXE pid %d\n", appl_pid);)
	    D(fflush(log_ptr);)
	    if(appl_pid == 0)
	    {
                /***************************************************/
                /* The client's application requires fd_write_req  */
                /* and fd_read_ans file descriptors to communicate */
                /* with ACA.  fd_write_req sends requests to ACA,  */
		/* fd_read_ans is used by the client program to    */
		/* get responses from the ACA.			   */
                /*                                                 */
		/* The next statement runs the client application. */
		/* To change the application being run, the client */
		/* must change the APPL_EXE environment variable.  */
                /****************************************************/
		ret_val = execl(APPL_EXE, APPL_EXE, fd_write_req,
                                fd_read_ans, (char *)0);
		if(ret_val != 0)
		{
		    D(fprintf(log_ptr, "BAD execl(APPL_EXE) ");)
		    D(fprintf(log_ptr, "ret_val %d ", ret_val);)
		    D(fprintf(log_ptr, "errno %d\n", errno);)
		    D(fflush(log_ptr);)
		    exit(1);
		}
		D(fprintf(log_ptr,"EXECL(APPL_EXE)\n");)
		D(fflush(log_ptr);)
	    }
	    else
	    {
		D(fprintf(log_ptr, "BAD fork(APPL_EXE)\n");)
		D(fprintf(log_ptr, "BEFORE wait (APPL_EXE death)\n");)
		D(fflush(log_ptr);)

                /*************************************************/
                /* The next statement puts start_urmm process    */
                /* to sleep until the user quits the client's    */
                /* software.                                     */
                /*************************************************/
		wait(&status);
		D(fprintf(log_ptr, "AFTER wait(APPL_EXE death)\n");)
		D(fflush(log_ptr);)
	    }
	    D(fprintf(log_ptr,"AFTER else(APPL_EXE)\n");)
	    D(fflush(log_ptr);)
	} /* else branch that forks client application */
	D(fprintf(log_ptr,"AFTER else fork(APPL_EXE)\n");)
	D(fflush(log_ptr);)
    } /* if((pipe(fd_req_pipe) != -1) && (pipe(fd_ans_pipe) != -1)) */

    /* At least one of the pipe() statements failed */
    /* Put useful error information in the log file */
    else
    {
	perror("pipe() failed");
	fprintf(log_ptr,"pipe() failed, errno %d\n", errno);
	fprintf(log_ptr,"rtn_req_pipe %d rtn_ans_pipe %d\n",
                rtn_req_pipe, rtn_ans_pipe);
	fprintf(log_ptr,"fd_req_pipe[0] %d fd_req_pipe[1] %d\n",
                fd_req_pipe[0], fd_req_pipe[1]);
	fprintf(log_ptr,"fd_ans_pipe[0] %d fd_ans_pipe[1] %d\n",
                fd_ans_pipe[0], fd_ans_pipe[1]);
    }
    /* Terminate all functions created/started by this exec */
    D(fprintf(log_ptr,"Before kill(aca_pid, SIGUSR1) lines\n");)
    D(fflush(log_ptr);)
    kill(aca_pid,SIGUSR1);
    kill(appl_pid,SIGKILL);
    D(fprintf(log_ptr,"After if-else of pipe() stmts\n");)
    D(fflush(log_ptr);)
} /* main() */
