/*  Program:  aca_busy.c
 *  
 *  Description: 
 *  
 *  Sample program which keeps the aca up and running until
 *  either: 1) aca_busy dies or 2) the aca process is killed.
 *
 *  NOTE:  aca must be started and be running before this program
 *         is invoked.
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

int fd1;
int fd2;
char *NAMED_PIPE_TO_SERVER;
char *NAMED_PIPE_FROM_SERVER;

void main()
{
   NAMED_PIPE_TO_SERVER = getenv ("NAMED_PIPE_TO_SERVER\0");
   NAMED_PIPE_FROM_SERVER = getenv ("NAMED_PIPE_FROM_SERVER\0");

   fd1 = open(NAMED_PIPE_TO_SERVER, O_WRONLY);
   if(fd1 == -1){
      printf("*** aca_busy failed to open to_server ***\n");
      exit(1);
   }

   fd2 = open(NAMED_PIPE_FROM_SERVER, O_RDONLY);
   if(fd2 == -1){
      printf("*** aca_busy failed to open from_server ***\n");
      exit(1);
   }

   for(;;)
      sleep(10000);
}
