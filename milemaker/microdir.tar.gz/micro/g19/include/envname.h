/****************************************************************/
/* Version: 17.3                                           */
/* File   : envname.h                                           */
/* Changed: 6/24/97                                           */
/****************************************************************/

/****************************************************************************/
/*                                                                          */
/*  Header Name : envname.h                                                 */
/*                                                                          */
/*  Description : Environment Variable. Include data file name,             */
/*                executable path, error log, and data                      */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*  REVISIONS                                                               */
/*                                                                          */
/*          Name                Date        Description of Change     Nbr   */
/* -------------------------  --------  ----------------------------  ----  */
/* Yimin Chen                  7/02/91  Original header.                    */
/* Holly A. Swenson            8/24/92  Corrected compiler directives V1.1  */
/*                                      for 386sx.                          */
/* Holly A. Swenson           10/22/92  Added undef EXTERN to avoid   V1.2  */
/*                                      compiler warnings.                  */
/* Louis London                1/15/93  Add shortest and prac loc     V1.3  */
/*                                      file env variables.                 */
/* Claudia Lenz                2/03/93  Add ALIAS_PATH and TEMP_PATH  V1.4  */
/* Ira Rosen                   2/18/93  Add interface variables       V1.5  */
/* Holly A. Swenson            3/01/93  Removed BATCH_PATH.           V1.6  */
/* Holly A. Swenson            6/09/93  Removed USER_CONV_PATH.       V1.7  */
/* Ira Rosen                   9/29/93  Add variables for URMM only.  V1.8  */
/* Claudia Lenz                3/18/94  Add PRINT_CMD.                V1.9  */
/* Regina Williams CRC         3/23/95  Added Zip Code Processing     V1.10 */
/* Rick Christiansen           4/24 95  Removed #ifdef URMM           V1.11 */
/* Louis London                7/20/95 Add SECONDARY STATUS path      V1.12 */
/* Rick Christiansen           4/10/96  ADDED SERVER_LOG_PATH         V1.13 */
/* Louis London                9/8/96   Add AVOID & PREFER_PATH       V1.14 */
/* Kristopher J. Krause        4/24/97  Added OPTION_PATH             V1.15 */
/* Louis London                6/17/97  Add ENABLE_PATH, WINDOCP_PATH V1.16 */
/* Louis London                5/23/01  Add LONLAT_INDEX_PATH and     V1.17 */
/*                                      LONLAT_FILE_PATH                    */
/* Louis London                6/18/01  Add ZIP_AUX PATH              V1.18 */
/* Louis London                9/21/05  Add Canadian Postal Paths     V1.19 */
/* Tom Newton                  7/30/07  Add Named Pipes               V1.20 */
/* Louis London                12/2/07  Add TCP port                  V1.21 */
/****************************************************************************/

#undef EXTERN      /* V1.2 */
#ifdef DEFINE_HERE
#   define EXTERN  /* V1.1 */
#else
#   define EXTERN extern  /* V1.1 */
#endif

/* The following are for necessary data files used by MileMaker */

EXTERN char *NETWORK_PATH;
EXTERN char *DATA_FILE_PATH;
EXTERN char *STATE_IND_PATH;
EXTERN char *SPLC_IND_PATH;
EXTERN char *CITY_IND_PATH;
EXTERN char *SECMLG_PATH;
EXTERN char *SECRTE_PATH;
EXTERN char *SECHWY_PATH;
EXTERN char *SECSTAT_PATH; /* V1.12 */
EXTERN char *WINDOP_PATH;
EXTERN char *WINDOCP_PATH; /* V1.16 */
EXTERN char *WINDOS_PATH;
EXTERN char *WINDOP48_PATH;
EXTERN char *WINDOCP48_PATH; /* V1.16 */
EXTERN char *WINDOS48_PATH;
EXTERN char *SHORT_LOCATOR_PATH; /* V1.3 */
EXTERN char *PRAC_LOCATOR_PATH;  /* V1.3 */
EXTERN char *BAD_SPLCS_PATH;
EXTERN char *CORP_CODE_PATH;
EXTERN char *KEY_SPLC_PATH;
EXTERN char *BAD_MIL_PATH;
EXTERN char *MIL_MILES_PATH;
EXTERN char *HOT_LINE_PATH;
EXTERN char *GEOX_FILE_PATH;

EXTERN char *ZIP_FILE_PATH;       /* V1.10 */
EXTERN char *ZIP_INDEX_PATH;      /* V1.10 */
EXTERN char *ZIP_AUX_PATH;        /* V1.18 */

EXTERN char *CPOSTAL_FILE_PATH;   /* V1.19 */
EXTERN char *CPOSTAL_INDEX_PATH;  /* V1.19 */

EXTERN char *LONLAT_FILE_PATH;    /* V1.17 */
EXTERN char *LONLAT_INDEX_PATH;   /* V1.17 */
EXTERN char *ABBREV_TBL_PATH;
EXTERN char *COUNTIES_PATH;

EXTERN char *MISC_PATH;
EXTERN char *SYS_USER_PATH;
EXTERN char *SYS_DATE_PATH;
EXTERN char *ALIAS_PATH; /* V1.4 */
EXTERN char *TEMP_PATH;  /* V1.4 */
EXTERN char *USAGE_PATH;
EXTERN char *DISP_REPORT_PATH;
EXTERN char *MINI_USER_PATH;
EXTERN char *SCREEN_PATH;
EXTERN char *MAINT_PATH;
EXTERN char *TRASH_DISK_PATH;

EXTERN char *HHG_TEST_PATH;
EXTERN char *HHG_ANS_PATH;
EXTERN char *PREFER_PATH; /* V1.14 */
EXTERN char *AVOID_PATH; /* V1.14 */
EXTERN char *AVPR_TEMP_PATH; /* V1.14 */

/* EXTERN char *USER_CONV_PATH;  */    /* V1.7 */
/* EXTERN char *BATCH_PATH;   V1.6 */

/*  The following are for executable paths used by MileMaker */
EXTERN char *ROUTPROC_EXE;
EXTERN char *LONGNAME_EXE;
EXTERN char *DEMON_EXE;
EXTERN char *MILEMAKER_EXE;

/*  The following are for error log files used by MileMaker */
EXTERN char *ERROR_LOG_PATH;
EXTERN char *LONGNAME_LOG_PATH;
EXTERN char *TASKROUT_LOG_PATH;
EXTERN char *TASKSCRN_LOG_PATH;
EXTERN char *DEMON_LOG_PATH;
EXTERN char *SERVER_LOG_PATH;  /* V1.3 */
EXTERN char *OPTION_PATH;      /* V1.15 */
EXTERN char *ENABLE_PATH;      /* V1.16 */

/*  The following are for GEO data used by MileMaker */
EXTERN char *G_BLKS;
EXTERN char *STATE_IND;
EXTERN int G_BLKS_WRITTEN;
EXTERN int STATE_IND_POS;

/* The following are for LP option */
EXTERN char *LP_OPTION;
EXTERN int LP_ACTIVE;
EXTERN char *PRINT_CMD;             /* V1.9 */

/* The following are used to integrate Stand Alone with Interface */
EXTERN char *PARMFILE_PATH;
EXTERN char *ONLINE_EXE;            /* Path for enhanced interface executable */
EXTERN char *INTERFACE_EXE;         /* Path for standard interface executable */
EXTERN char *NOIF_EXE;              /* Used for non-interface clients */
EXTERN char *ACCT_LOG_PATH;         /* Accounting file */
EXTERN char *MINI_ACCT_LOG_PATH;    /* Accounting file */

/* New interface variables V1.5 */
EXTERN char *SERIAL_PORT;           /* Device file for custom interface */
EXTERN char *TWINAX_FILE;           /* Device file for IBM midrange */
EXTERN char *READER_LOG_PATH;       /* Log file for interface clients */
EXTERN char *NAMES_LOG_PATH;        /* Log file only for names transfer */

/* Begin V1.5 */
/* #ifdef URMM V1.11 */
EXTERN char *CLIENT_LOG_PATH;     /* Client appln log file */
EXTERN char *APPL_EXE;            /* Client application name */
EXTERN char *RAND_ACA;            /* ACA full path name */
EXTERN char *START_LOG_PATH;      /* start_urmm log file */
/* #endif V1.11 */
/* End V1.5 */
/*                     */
/* Named Pipes - from-server and to-server  V1.20  */
EXTERN char *NAMED_PIPE_TO_SERVER;     /* Named pipe to server */
EXTERN char *NAMED_PIPE_FROM_SERVER;   /* Named pipe from server */

/* TCP Port */
EXTERN char *TCP_PORT;           /* TCP_PORT */
