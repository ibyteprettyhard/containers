/****************************************************************/
/* Version: 17.3                                              */
/* File   : hmgetenv.c                                              */
/* Changed: 6/24/97                                              */
/****************************************************************/

#include <stdlib.h>  /* for getenv */
#include <unistd.h>

#include <hmport.h>
#include <constant.h>
#include <hmtypdef.h>
#include <hmprttyp.h>

#define DEFINE_HERE
#include <envname.h>
#undef DEFINE_HERE

/****************************************************************************/
/*  Name         :  get_env                                                 */
/*                                                                          */
/*  Description  :  All environment variables (data file names, variables,  */
/*                  and executable file names) are read from the .profile   */
/*                  or .login.                                              */
/*                                                                          */
/*  Input        :  None.                                                   */
/*                                                                          */
/*  Output       :  Variables are set.                                      */
/*                                                                          */
/*  Called By    :                                                          */
/*                                                                          */
/*  REVISIONS                                                               */
/*                                                                          */
/*          Name                Date        Description of Change     Nbr   */
/* -------------------------  --------  ----------------------------  ----  */
/* Louis London               1/15/93   Add calls for short and prac  V1.1  */
/*                                      locator files.                      */
/* Ira Rosen                  2/18/93   Add new interface variables   V1.2  */
/* Holly A. Swenson           3/01/93   Removed duplicate code.       V1.3  */
/* Holly A. Swenson           6/09/93   Removed USER_CONV_PATH call.  V1.4  */
/* Ira Rosen                  9/29/93   Add variables for URMM only.  V1.5  */
/* Regina Williams (CRC)      3/17/95   Added Zip Code Processing     V1/5  */
/* Rick Christiansen          5/24/95   Removed #ifdef URMM           V1.6  */
/* Louis London               7/28/95   Add Secondary Status Path     V1.7  */
/* Rick Christiansen          4/10/96   Added SERVER_LOG_PATH         V1.8  */
/* Rick Christiansen          4/10/96   Added CLIENT_LOG_PATH         V1.8  */
/* Louis London               9/8/96    Added AVOID & PREFER_PATH     V1.9  */
/* Kristopher J Krause        4/24/97   Added OPTION_PATH             V1.10 */
/* Louis London               6/13/97   Add ENABLE_PATH               V1.11 */
/* Louis London               6/17/97   Add WINDOCP_PATH              V1.12 */
/* Louis London               5/23/01   Add LONLAT_INDEX_PATH and     V1.13 */
/*                                      LONLAT_FILE_PATH                    */
/* Louis London               6/18/01   Add ZIP_AUX_PATH              V1.14 */
/* Louis London               9/21/05   Add Canadian Postal Paths     V1.15 */
/* Tom Newton                 7/30/07   Add Named Pipes               V1.16 */
/* Louis London              12/2/07    Add TCP port                  V1.17 */
/****************************************************************************/
void get_env()
{
   /* get batch file names - inhouse only */
   HHG_TEST_PATH = getenv ("HHG_TEST_PATH\0");
   HHG_ANS_PATH = getenv ("HHG_ANS_PATH\0");

   /* get Guide dependent file names */
   NETWORK_PATH = getenv ("NETWORK_PATH\0");
   DATA_FILE_PATH = getenv ("DATA_FILE_PATH\0");
   STATE_IND_PATH = getenv ("STATE_IND_PATH\0");
   SPLC_IND_PATH = getenv ("SPLC_IND_PATH\0");
   CITY_IND_PATH = getenv ("CITY_IND_PATH\0");
   SECMLG_PATH = getenv ("SECMLG_PATH\0");
   SECRTE_PATH = getenv ("SECRTE_PATH\0");
   SECHWY_PATH = getenv ("SECHWY_PATH\0");
   SECSTAT_PATH = getenv ("SECSTAT_PATH\0"); /* V1.7 */
   WINDOP_PATH = getenv ("WINDOP_PATH\0");
   WINDOCP_PATH = getenv ("WINDOCP_PATH\0"); /* V1.12 */
   WINDOS_PATH = getenv ("WINDOS_PATH\0");
   WINDOP48_PATH = getenv ("WINDOP48_PATH\0");
   WINDOCP48_PATH = getenv ("WINDOCP48_PATH\0"); /* V1.12 */
   WINDOS48_PATH = getenv ("WINDOS48_PATH\0");
   SHORT_LOCATOR_PATH = getenv ("SHORT_LOCATOR_PATH\0"); /* V1.1 */
   PRAC_LOCATOR_PATH = getenv ("PRAC_LOCATOR_PATH\0"); /* V1.1 */
   BAD_SPLCS_PATH = getenv ("BAD_SPLCS_PATH\0");
   CORP_CODE_PATH = getenv ("CORP_CODE_PATH\0");
   KEY_SPLC_PATH = getenv ("KEY_SPLC_PATH\0");
   BAD_MIL_PATH = getenv ("BAD_MIL_PATH\0");
   MIL_MILES_PATH = getenv ("MIL_MILES_PATH\0");
   HOT_LINE_PATH = getenv ("HOT_LINE_PATH\0");
   GEOX_FILE_PATH = getenv ("GEOX_FILE_PATH\0");

   /* get non Guide-dependent data file names */
   COUNTIES_PATH = getenv ("COUNTIES_PATH\0");
   ABBREV_TBL_PATH = getenv ("ABBREV_TBL_PATH\0");

   /* get other data file names */
   ALIAS_PATH = getenv ("ALIAS_PATH\0");
   TEMP_PATH = getenv ("TEMP_PATH\0");
   MISC_PATH = getenv ("MISC_PATH\0");
   SYS_USER_PATH = getenv ("SYS_USER_PATH\0");
   SYS_DATE_PATH = getenv ("SYS_DATE_PATH\0");
   USAGE_PATH = getenv ("USAGE_PATH\0");
   DISP_REPORT_PATH = getenv ("DISP_REPORT_PATH\0");
   MINI_USER_PATH = getenv ("MINI_USER_PATH\0");
   SCREEN_PATH = getenv ("SCREEN_PATH\0");
   MAINT_PATH = getenv ("MAINT_PATH\0");
   LONLAT_FILE_PATH = getenv("LONLAT_FILE_PATH\0");    /* V1.13 */
   LONLAT_INDEX_PATH = getenv("LONLAT_INDEX_PATH\0");  /* V1.13 */
   ZIP_AUX_PATH = getenv("ZIP_AUX_PATH\0");    /* V1.14 */
   ZIP_FILE_PATH = getenv("ZIP_FILE_PATH\0");    /* V1.6 */
   ZIP_INDEX_PATH = getenv("ZIP_INDEX_PATH\0");  /* V1.6 */
   CPOSTAL_FILE_PATH = getenv("CPOSTAL_FILE_PATH\0");    /* V1.15 */
   CPOSTAL_INDEX_PATH = getenv("CPOSTAL_INDEX_PATH\0");  /* V1.15 */
   AVOID_PATH = getenv("AVOID_PATH\0");    /* V1.9 */
   PREFER_PATH = getenv("PREFER_PATH\0");  /* V1.9 */
   AVPR_TEMP_PATH = getenv("AVPR_TEMP_PATH\0");  /* V1.9 */
   OPTION_PATH = getenv("OPTION_PATH\0"); /* V1.10 */
   ENABLE_PATH = getenv("ENABLE_PATH\0"); /* V1.11 */

   /* USER_CONV_PATH = getenv ("USER_CONV_PATH\0"); V1.4 */
   /* BATCH_PATH = getenv ("BATCH_PATH\0");  V1.3 */

   /* get executable file names */
   ROUTPROC_EXE = getenv ("ROUTPROC_EXE\0");
   LONGNAME_EXE = getenv ("LONGNAME_EXE\0");
   DEMON_EXE = getenv ("DEMON_EXE\0");
   MILEMAKER_EXE = getenv ("MILEMAKER_EXE\0");

   /* get log file names */
   ERROR_LOG_PATH = getenv ("ERROR_LOG_PATH\0");
   LONGNAME_LOG_PATH = getenv ("LONGNAME_LOG_PATH\0");
   TASKROUT_LOG_PATH = getenv ("TASKROUT_LOG_PATH\0");
   TASKSCRN_LOG_PATH = getenv ("TASKSCRN_LOG_PATH\0");
   TRASH_DISK_PATH =  getenv ("TRASH_DISK_PATH\0");
   DEMON_LOG_PATH = getenv ("DEMON_LOG_PATH\0");
   SERVER_LOG_PATH = getenv ("SERVER_LOG_PATH\0");    /* V1.8 */
   CLIENT_LOG_PATH = getenv ("CLIENT_LOG_PATH\0");    /* V1.8 */

   /* get variables */
   STATE_IND = getenv ("STATE_IND\0");
   STATE_IND_POS = atoi (STATE_IND);
   G_BLKS = getenv ("G_BLKS\0");
   G_BLKS_WRITTEN = atoi (G_BLKS);
   LP_OPTION = getenv ("LP_OPTION\0");
   LP_ACTIVE = atoi (LP_OPTION);

   /* The following are to integrate Stand Alone with Interface */
   PARMFILE_PATH = getenv ("PARMFILE_PATH");
   ONLINE_EXE = getenv ("ONLINE_EXE");  /* Enhanced interface exec */
   INTERFACE_EXE = getenv ("INTERFACE_EXE"); /* Standard interface exec */
   NOIF_EXE = getenv ("NOIF_EXE");  /* For non-interface clients */
   ACCT_LOG_PATH = getenv ("ACCT_LOG_PATH"); /* Accounting file */
   MINI_ACCT_LOG_PATH = getenv ("MINI_ACCT_LOG_PATH"); /* Accounting file */

   /* Begin new V1.2 variables */
   SERIAL_PORT = getenv ("SERIAL_PORT"); /* Device file for custom interface */
   TWINAX_FILE = getenv ("TWINAX_FILE"); /* Device file for IBM midrange */
   READER_LOG_PATH = getenv ("READER_LOG_PATH"); /* Log file for interface */
   NAMES_LOG_PATH = getenv ("NAMES_LOG_PATH"); /* Log file for names xfer */
   /* End new V1.2 variables */

   /* Begin V1.5 */
   /* #ifdef URMM V1.6 */
   CLIENT_LOG_PATH = getenv("CLIENT_LOG_PATH"); /* Client appln log file */
   APPL_EXE = getenv("APPL_EXE");               /* Client application name */
   RAND_ACA = getenv("RAND_ACA");               /* ACA full path name */
   START_LOG_PATH = getenv("START_LOG_PATH");   /* start_urmm log file */
   /* #endif URMM V1.6 */
   /* End V1.5 */
   PRINT_CMD = getenv ("PRINT_CMD\0");           /* print command  V1.5 */

   /* Named Pipes - Added V1.16 */
   NAMED_PIPE_TO_SERVER = getenv("NAMED_PIPE_TO_SERVER");  /* to-server  */
   NAMED_PIPE_FROM_SERVER = getenv("NAMED_PIPE_FROM_SERVER");  /* to-server */

   
   /* Named Pipes - Add V1.17 */
   TCP_PORT = getenv("TCP_PORT");  /* tcp-port  */
}
