/****************************************************************/
/* Version: 17.2                                           */
/* File   : network.h                                           */
/* Changed: 5/28/97                                           */
/****************************************************************/

/***********************************************************************
*
*   Header name : Network.h
*
*   Description :This is the header file which defines the highway
*   network structure layout.
*
*   History :
*
*   Name         Date      Description of Change
* ------------- --------  ----------------------------------------------
*
*
* Anne L'laub   5/12/87     Original header
*
* Rick Christ'n 10/1/87     Guide 13 BETA test version.
*
* Claudia Lenz  l0/07/87    Added struct nts_hwy_bits_0 to NTS_HWY_BITS.
*
* John McCloskey 12/01/87   Fixed HEX_FF and HEX_FE definitions
*
* Ray Ward      12/10/87    Added secondary file pointers (2) and end
*                           of string pointer to RT_SG_TB
*
* Louis London   9/9/93     Make rout_st_miles long          V1.1
* Louis LOndon   7/8/01     LONLAT Changes                   V1.2
**********************************************************************/

#undef EXTERN
#ifdef DEFINE_HERE          /* used in source modules so */
#    define EXTERN          /* that variables are defined*/
#else                       /* in only one module, and   */
#    define EXTERN extern   /* then externally defined   */
#endif                      /* in other modules          */

/****************************************************
*                #defines
****************************************************/

/* number of possible entries in one malloc() area of network change list */
#define CHG_LIST_LEN     10  /* number of possible entries*/

/* length of malloc table pointer array */
/* #define MAL_TBL_LEN     207 LJL eliminate for G17   8/26/96       */

/*#define NUM_STACK_WINS    2 */           /* number of stack windows   */
#define NUM_STACK_WINS    3     /* number of stack windows for the router */

#define BLK_SIZE        512  /* secondary buf block size  */

/* number of possible states router can put you thru   */
/* #define RT_STATES   96 */ /* 64 for G15 became STATE_IND_LEN */

#define CALC_BOX_SIZE (double) 3.98 /* Guide 16 */
/* Guide 16 removed HEX_FE, HEX_FF, HEX_EF definitions - in constants.h */
/* #define HEX_FE (unsigned char) 0xfe */   /* check for secondary point */ 
/***********************************************************************
*                    Guide 14 Information                              *
*  After converting to Guide 14 comment out HEX_FF & HEX_EF above.     *
*                                                                      *
***********************************************************************/
/* #define HEX_FF (unsigned char) 0xff */   /* check for calc point   */
/* #define HEX_EF (unsigned char) 0xef */   /* check for network point*/

#define OPT_WORK_AREA    91  /* len of opt_int work area  */

#define SECONDARY_PT 'S'  /* point is a secondary point*/
#define NETWORK_PT 'N'  /* point is a network point  */
#define CALC_PT  'C'  /* point is a calc point     */

#define OPEN_JAW_LVL   3  /* router lvl for open tour  */
#define CLOSED_JAW_LVL    5  /* router lvl for closed tour*/
#define DEST_LVL   5  /* router lvl for 2 - 14 tour*/

/****************************************************
*            variable definitions
****************************************************/

EXTERN  long rout_st_miles[2][STATE_IND_LEN + 2]; /* Guide 16 V1.1 V1.2 */
/* within each state, the  */
/* first value is the total  */
/* # of miles for the route  */
/* in the state, and the     */
/* second is the number of   */
/* toll miles in the state   */

/* number of states with non-zero mileages in rout_st_miles array above */
EXTERN  short rt_num_states;


/****************************************************
*                 typedefs
*****************************************************/

#include <nettype.h>
/*************************************************
*       struct and union definitions
*************************************************/

/* calc and secondary point  */
/* info work area            */
EXTERN CALC_SEC_INFO calc_sec_data[2][NUM_IN_LINES];


EXTERN NETWORK_PREFIX prefix_area; /* used in system init       */


EXTERN RT_SG_TB r_s_t;   /* router segment table      */
EXTERN NTS_HWY_BITS alias_tbl_entry[3]; /* alias names for highways  */
/* ptr = ntp_alias_ptr_1 or  */
/* ntp_alias_ptr_2           */

EXTERN NETWORK_TABLE hwy_network_tbl;  /* highway network table     */

EXTERN ROUTE_DISP_LINES route_disp_lines, *rdl_ptr;

EXTERN int mal_tbl_len; /* eliminate constants LJL 8-26-96 */
