/****************************************************************/
/* Version: 16.2                                           */
/* File   : alias.h                                           */
/* Changed: 5/28/97                                           */
/****************************************************************/

/****************************************************************************/
/*  Header File  :  alias.h						    */
/*                                                                          */
/*  Description  :  This header file contains type definitions for route    */
/*                  aliasing.  It is a combination of select contents from  */
/*		    several header files from stand-alone code.		    */
/*                                                                          */
/*  REVISIONS                                                               */
/*	 Name	       Date		Description		     Nbr    */
/*  ---------------  --------   ----------------------------------  -----   */
/*  Ira Rosen	     3/2/93	Original file			    V?.?    */
/****************************************************************************/

/***************************************************************/
/* Constants added for User Defined Location/Route */
/***************************************************************/
#define ALIAS_NOT_FOUND	 2
#define EMPTY		 0
#define END_OFFSET	-1
#define ERROR		-1
#define EXISTS		 3
#define	LOC_STR_SIZE	22
#define NUM_ALIAS_LINES	14

#ifdef HPUX
#define REORDER
#endif

#ifdef SOLARIS
#define REORDER
#endif

#ifdef REORDER
typedef struct
{
   char splc[4]; /* GDB V1.5 */        /* from IN_PUT_LINE->g_data.g_splc */
   char in_data[LOC_STR_SIZE];         /* from IN_PUT_LINE->in_data */
} ARTE_LOC;                            /* alias location info */
#else
typedef struct
{
   char in_data[LOC_STR_SIZE];         /* from IN_PUT_LINE->in_data */
   char splc[4]; /* GDB V1.5 */        /* from IN_PUT_LINE->g_data.g_splc */
} ARTE_LOC;                            /* alias location info */
#endif

typedef struct
{
    char alias[LOC_STR_SIZE];		/* user description */
    char frags[2]; /* GDB */		/* number of stops including origin */
    char next_addr[4]; /* GDB */	/* file offset of next ALIAS_HEADER */
} ALIAS_HEADER;                         /* location/route alias header */
             /* In the ALIAS_PATH, each ALIAS_HEADER is followed immediately */
             /*              by ARTE_LOC records (one for each of its frags) */
