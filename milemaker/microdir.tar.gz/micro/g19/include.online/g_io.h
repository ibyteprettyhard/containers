/****************************************************************/
/* Version: 17.6                                           */
/* File   : g_io.h                                           */
/* Changed: 7/17/97                                           */
/****************************************************************/

/******************************************************************************
*    Header name : g_io.h
*
*    Description : This is the header file for geo file processing
*
*    History :
*
*        Name    Date         Description of change
* -----------------    ---------- --------------------------------------
*
* Peter Murphy     Original header
*
* Anne Lindenlaub 6/16/87  Added #defines for browse module, and
*     #ifdef logic for #includes.
*     Removed state_abbrev_tbl definition and
*     put it in milemaker.h instead.
*     Removed *g_buf_head_ptr; it was unused.
*
* Anne Lindenlaub       6/24/87  Added city_ind_rec union typedef.  Also
*     several #defines:
*      ST_ABB_LEN
*      CITY_ABBREV_LEN
*      ST_ABBREV_LEN
*      ST_BUF_LEN
*      CITY_IND_BLKS
*      HALF_CITY_BLKS
*
* Anne Lindenlaub       7/22/87         Added #defines for G_BLKS_WRITTEN and
*                                       STATE_IND_POS.  These are used within
*                                       g_io and need to be checked each time
*                                       the city/state indexes are rebuilt to
*                                       make sure they are still correct.
******************************************************************************/

/************************************************************************
*  Revision :
*
*  Name        Date  Description       Nbr
*  ---------------  --------   ----------------------------------  -----
* Ira Rosen          5/18/93   GDB NF on G_BUF_DATA_STRUCT for     V1.0
*                              NCR computer.
* Rick Christiansen  4/18/95   Added ACA Zip Code Access           V1.1
* Louis London       6/19/01   Changes for LON/LAT lookup and      V1.2
*                              ZIP Aux file
* Louis London       9/23/05   Canadian Postal Changes             V1.3
************************************************************************/

#undef EXTERN
#ifdef DEFINE_HERE
#    define EXTERN
#else
#    define EXTERN extern
#endif

/***************************************
*    I/O FUNCTIONS
***************************************/
#define   IO_LOOKUP       1
#define   IO_UPDATE       2
#define   IO_DISPLAY        3
#define   IO_BROWSE_SEARCH  4
#define   IO_BROWSE_READ    5
#define   IO_BROWSE_NEXT    6
#define   IO_BROWSE_PREV    7
#define   IO_REPLACE        8
#define   IO_ADD            9

/*************************************
*    G_IO DEFINITIONS
*************************************/
#define   BUFFERSIZ       512
#define   SPLC_BLK_LEN    128
#define   CITY_BLK_LEN    256
#define   ST_ABB_LEN      128
#define   ST_BUF_LEN      (STATE_IND_LEN * 4)
#define   ST_ABBREV_LEN     2
#define   CITY_ABBREV_LEN   2

#define   START_POS         0
#define   CURR_POS          1
#define   G_BUF_CITY_LEN   18
#define   G_BUF_STATE_LEN   6

/*****************************************************************************
*  These next two values are set according to the make_index program.  The
*  G_BLKS_WRITTEN is the number of 512K geo data blocks written out while
*  the indexes are being created.  The STATE_IND_POS is the number of entries
*  in the state index array (this is 63 instead of 64 now because Hawaii is
*  not included in the geo file).  THESE TWO VALUES MAY NEED TO BE UPDATED
*  IF THE MAKE_INDEX PROGRAM IS RERUN TO BUILD NEW INDEXES.  These values
*  are printed out to the end of the log file when make_index is run.  Only
*  one set of values are needed depending on the present Guide.
******************************************************************************/
/***************************
*     GUIDE 13 DATA       *
#define G_BLKS_WRITTEN   9615
#define STATE_IND_POS      63
***************************/

/***************************
*     GUIDE 14 DATA       *
**************************
#define G_BLKS_WRITTEN   9550
#define STATE_IND_POS      63
****************************/

/***************************
*     GUIDE 15 DATA - OLD *
***************************/
/* #define G_BLKS_WRITTEN   9459 */
/* #define STATE_IND_POS      63 */

/***************************
*     GUIDE 15 DATA - NEW *
***************************/
/* #define G_BLKS_WRITTEN   9449 */
/* #define STATE_IND_POS      63 */
/************************************
*  GLOBAL VARIABLE DEFINITIONS
************************************/
EXTERN char g_calc_flag;                   /* turned on and off by calc */
/* routine for use in gio    */
EXTERN char g_gen_key;                          /* generic key, CITY or SPLC */
EXTERN char g_gen_city[19];                     /* generic city              */
EXTERN long g_gen_splc;                         /* generic splc              */
EXTERN char g_gen_state[3];                     /* generic state             */
EXTERN int  g_gen_cnt;                          /* generic in_ch_cnt         */

/************************************
*    STRUCTURES & UNIONS DECLARATIONS
************************************/
typedef struct g_buf_rec
{
   long                g_buf_splc; /* GDB */
   char                g_int_loc_off[2]; /* geo location offset in network
   GDB NF V1.0 */
   short               g_int_loc_pg;    /* Guide 17 change LJL 8-28-96 */
   char                g_buf_long[4];   /* Changed data type - GDB */
   char                g_buf_lat[4];    /* Changed data type - GDB */
   short               g_buf_state;
   char                g_buf_city[G_BUF_CITY_LEN];
} G_BUF_DATA_STRUCT;


typedef struct g_io_block
{
   char                g_buf_prefix[G_PREFIX_LEN]; 
   char                g_buf_block[BUFFERSIZ-G_PREFIX_LEN]; /* GDB NF V1.0 */
} G_BUF_BLOCK_STRUCT;


typedef struct io_state
{
   char state_abbrev[ST_ABBREV_LEN]; /* state abbrev, no null */
   char state_first_blk[2];  /* GDB V1.3 State block code */
} IO_STATE_INFO;


typedef struct io_city
{
   char city_abbrev[CITY_ABBREV_LEN];     /* First 2 bytes of city, no null */
} IO_CITY_INFO;


typedef struct io_splc
{
   char   g_splc_num[2]; /* GDB V1.3 */
   char   g_splc_block_num[2]; /* GDB V1.3 */
} IO_SPLC_INFO;


EXTERN union g_in_data
{
   char  g_buf_data[BUFFERSIZ];
   G_BUF_BLOCK_STRUCT g_block_buf_data;
   char  g_buf_temp[1024];
   long g_buf_align; /* 8-31-96  Change for Guide 17 alignment */
} g_buf_overl;


EXTERN union out_state_data
{
   char  state_buf[ST_BUF_LEN];
   IO_STATE_INFO state_index[STATE_IND_LEN];
   long state_align; /* 8-31-96  Change for Guide 17 alignment */
} out_state_rec;


EXTERN union out_city_data
{
   char  city_buf[BUFFERSIZ];
   IO_CITY_INFO city_index[CITY_BLK_LEN];
} out_city_rec;


EXTERN union out_splc_data
{
   char  splc_buf[BUFFERSIZ];
   IO_SPLC_INFO splc_index[SPLC_BLK_LEN];
   long splc_align; /* 8-31-96  Change for Guide 17 alignment */
} out_splc_rec;


EXTERN union city_ind_data
{
   char  g_city_buf[BUFFERSIZ * 50]; /* Increase for Guide 17 */
   IO_CITY_INFO g_city_index[BUFFERSIZ * 25]; /* Increase For Guide 17 */
} city_ind_rec;


#define MAX_GEOX 30
EXTERN int G_RECS_PER_BLK;
EXTERN int Geox_Fd;
EXTERN int Geox_Tot;
EXTERN long Geox_Lseek;

typedef struct
{
   long  Geo_Slot; /* Louis London Change for alignment G17 8-31-96 */
   G_BUF_DATA_STRUCT G;
} GEO_AUX;
EXTERN GEO_AUX *P_GeoX;

/* Start Block ZIP V1.1 */
typedef struct
{
   char  zip[5];                        /* 5 digit zip code */
   char  po_default;                    /* post office default LJL 6-23-97 */
   char  zip_type;                      /* HHG or PRACTICAL    LJL 6-25-97 */
   unsigned char  off;                  /* offset into file    LJL 6-23-97 */
   short page;                          /* page zip is found in file */
} ZIP_RECORD;

typedef struct
{
   ZIP_RECORD zip_blk [64];           /* Blocks of zip records */
} ZIP_BLOCK;
/* End Block ZIP V1.1 */

/* Begin V1.2 */

typedef struct 
{
   long muX;
   long muY;
} MU_POINT;

typedef struct
{ 
   long  lon;
   long  lat;
   short off;                 
   short page;                     
} LONLAT_RECORD;

typedef struct
{
   LONLAT_RECORD lonlat_blk [64];           /* Blocks of lonlat records */
} LONLAT_BLOCK;

typedef  struct {
   short   x;
   short  y; }  NPOINT;

typedef struct{

	     char zip[5];
	     char pos;
	     char city[18];
	     char state[2];
             char po_default;
	     char zip_type;
             long splc;
             long lat;
             long longi;
	     short corp;
 	     short vic;
} ZIPAUX_RECORD;

/* End V1.2 */

/* Begin V1.3 */

typedef struct
{
   char  zip[6];                        /* 7 byte zip code encrypted*/
   char  lLon[4];                       /* Longitude */
   char  lLat[4];                       /* Latitude */
   short  sState;
} CAN_ZIP_RECORD;

typedef struct
{
   CAN_ZIP_RECORD zip_blk [100];           /* Blocks of zip records */
} CAN_ZIP_BLOCK;

typedef struct
{
   char zipind[3];
}CAN_ZIP_INDEX;

/* End V1.3 */
