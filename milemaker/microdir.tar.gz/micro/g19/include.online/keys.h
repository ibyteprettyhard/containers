/****************************************************************/
/* Version: 16.3                                           */
/* File   : keys.h                                           */
/* Changed: 5/28/97                                           */
/****************************************************************/

/*********************************************************************
*
*    Header Name:       keys.h
*
*    Description:       This header file contains the definitions
*                       of the function keys.
*
*    History:
*
*        Name         Date           Description Of Change
*   --------------  --------    --------------------------------------
* Rick Christiansen  4/29/87    Original header file.
* Holly A. Swenson   8/31/92    Added control-f7 thru control-f10.
* Kristopher Krause  4/12/96    Added F0 for PRAC. MILEAGE INQUIRY
*                               through the ACA
**********************************************************************/
#ifdef AIX
#define IBM
#endif

#ifdef LINUXBIG
#define IBM
#endif

#ifdef IBM
#define F0               169     /* KJK - for PRACTICAL MILEAGE INQ. */
#define F1               128
#define F2               129
#define F3               130
#define F4               131
#define F5               132
#define F6               133
#define F7               134
#define F8               135
#define F9               136
#define F10              137
#define SHIFT_F1         138
#define SHIFT_F2         139
#define SHIFT_F3         140
#define SHIFT_F4         141
#define SHIFT_F5         142
#define SHIFT_F6         143
#define SHIFT_F7         144
#define SHIFT_F8         145
#define SHIFT_F9         146
#define SHIFT_F10        147

#define HOME             148
#define CURSOR_UP        149
#define PAGE_UP          150
#define CURSOR_LEFT      151
#define FIVE_KEY         157
#define CURSOR_RIGHT     152
#define END              153
#define CURSOR_DOWN      154
#define PAGE_DOWN        155
#define INS              156

#define INVALID_F_KEY    158

#define CTRL_F1          159
#define CTRL_F2          160
#define CTRL_F3          161
#define CTRL_F4          162
#define CTRL_F5          163
#define CTRL_F6          164

#define CTRL_F7          165
#define CTRL_F8          166
#define CTRL_F9          167
#define CTRL_F10         168

#else

#define F0               -87
#define F1               -128
#define F2               -127
#define F3               -126
#define F4               -125
#define F5               -124
#define F6               -123
#define F7               -122
#define F8               -121
#define F9               -120
#define F10              -119
#define SHIFT_F1         -118
#define SHIFT_F2         -117
#define SHIFT_F3         -116
#define SHIFT_F4         -115
#define SHIFT_F5         -114
#define SHIFT_F6         -113
#define SHIFT_F7         -112
#define SHIFT_F8         -111
#define SHIFT_F9         -110
#define SHIFT_F10        -109

#define HOME             -108
#define CURSOR_UP        -107
#define PAGE_UP          -106
#define CURSOR_LEFT      -105
#define FIVE_KEY          -98
#define CURSOR_RIGHT     -104
#define END              -103
#define CURSOR_DOWN      -102
#define PAGE_DOWN        -101
#define INS              -100

#define INVALID_F_KEY     -99

#define CTRL_F1           -97
#define CTRL_F2           -96
#define CTRL_F3           -95
#define CTRL_F4           -94
#define CTRL_F5           -93
#define CTRL_F6           -92
#define CTRL_F7           -91
#define CTRL_F8           -90
#define CTRL_F9           -89
#define CTRL_F10          -88

#endif

#define DEL               127
#define ESC                27
#define CAR_RETURN         13
#define TAB_HORIZONTAL      9
#define BACKSPACE           8
#define PRNT_SCRN          42
