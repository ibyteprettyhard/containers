/****************************************************************/
/* Version: 16.4                                           */
/* File   : sysmaint.h                                           */
/* Changed: 5/28/97                                           */
/****************************************************************/

/****************************************************************************
* Header Name :   sysmaint.h
*
* Description :   This header file contains system maintenance #defines,
*   variables, and structure definitions.  This includes
*                       password maintenance, user conversion, and program/data
*                       fixes.
*
* History :
*
*     Name    Date   Description
*   --------------------  ----------   -------------------------------------
*   Anne Lindenlaub    7/07/87 Created
*   Anne Lindenlaub        7/22/87      Added typedef for USER_CONV_STRUCT
*                                       and variable definition for user_conv.
*                                       Changed values for UC_INQUIRE, UC_ADD,
*                                       UC_CHANGE, UC_DELETE, and UC_CLEAR.
*   Claudia Lenz           9/25/87      Added field length, row and column
*                                       definitions; also audit-row variable.
*   Claudia Lenz          10/05/87      Added definitions for LOCATOR_R_CHG,
*                                       LOCATOR_M_CHG, USAGE_CHG; replaced
*     GEO_CHG with SECONDARY_CHG.
*   Claudia Lenz   10/22/87 Added definition for BUFSIZE.
*   Claudia Lenz   12/02/87 Changed definition for M_DESC_LEN
*     from 26 to 31.
*   Claudia Lenz   12/03/87 Added definition for DATE_CHG.
*   Claudia Lenz   12/10/87 Added definition for PKG_CHG.
*   Claudia Lenz   12/11/87 Combined locator file changes and
*     replaced LOCATOR_M_CHG with HTBL_CHG.
*     Changed GEO_ADD to GEO_CHG.
*   Claudia Lenz   12/28/87 Added definition for FILE_CHG.
*   Ira Rosen    11/13/92 Removed unneeded interface entries.
*   Ira Rosen     5/18/93 GDB NF changes for NCR.
*   Kristopher Krause      4/12/96      Added TRANS_PM for transaction
*                                       accounting for PRACTICAL MILEAGE
*                                       INQUIRY - ACA PM request type
*   Kristopher Krause      4/12/96      Added char usr_cnt_pm[2] to struct.
*                                       for transaction accounting
*   Louis London           1/10/02      Increase MAX_SYS_USERS         V1.2
*****************************************************************************/
#undef EXTERN
#ifdef DEFINE_HERE   /* used in source modules    */
#    define EXTERN    /* so that variables are     */
#else     /* defined within the header */
#    define EXTERN extern  /* module, and then defined  */
#endif     /* externally in the other   */
/* source modules.           */
#define MAX_CONV 250 /* added 1-11-88 for stack overflow problem */
#define MAX_SYS_USERS 1000 /* V1.2 */
#define UC_REC_LEN 60
#define M_LOC_LEN 23

/******************************************************
*  The following are the different possible          *
*  transaction types that are written to the audit   *
*  trail file.  This audit trail file is then used   *
*  as input to the print usage report routine as     *
*  subscripts into the trans_info structure.         *
*  Which one to use depends upon the current         *
*  transaction type information being printed.       *
******************************************************/
#define TRANS_PN          0 /* (F6) Practical, route Only */
#define TRANS_PO          1 /* (F7) Practical, state breakdown Only */
#define TRANS_PB          2 /* (F8) Practical, route and state breakdown */
#define TRANS_SO          3 /* (F4) HHG state breakdown only */
#define TRANS_SB          4 /* (F5) HHG route and state breakdown */
#define TRANS_AN          5 /* (F3) HHG audit route only */
#define TRANS_MO          6 /* (F1) HHG optimized mileage request */
#define TRANS_M           7 /* (F1) HHG non-optimized mileage request */
#define TRANS_O           8 /* (F2) HHG mileage origin request */
#define TRANS_PM          9     /* (F0) Practical Mileage Inquiry - KJK */
#ifdef HPUX
#define REORDER
#endif

#ifdef SOLARIS
#define REORDER
#endif

#ifdef REORDER
typedef struct /* sym_user_info V1.9 */
{
   char           user_cnt_pm[2]; /* PRACTICAL MILEAGE INQ.  V1.8 */
   char           user_cnt_pn[2]; /* Practical: No SMB      GDB V1.2 */
   char           user_cnt_po[2]; /* Practical: State only  GDB V1.2 */
   char           user_cnt_pb[2]; /* Practical: Both        GDB V1.2 */
   char           user_cnt_so[2]; /* Shortest: State Only   GDB V1.2 */
   char           user_cnt_sb[2]; /* Shortest: State Mileage  GDB V1.2 */
   char           user_cnt_an[2]; /* Audit Route Only         GDB V1.2 */
   char           user_cnt_mo[2]; /* Mileage Inq with Opt     GDB V1.2 */
   char           user_cnt_m[2];  /* Mileage Req              GDB V1.2 */
   char           user_cnt_o[2];  /* Origin Req               GDB V1.2 */
   char           user_id[11];
   char           user_emp_name[36];
   char           user_pswd[11];
   char           user_old_pswd[11];
   char           filler;         /*                          GDB NF V1.5 */
} USER_DATA;
#else
typedef struct /* sym_user_info V1.9 */
{
   char           user_id[11];
   char           user_emp_name[36];
   char           user_pswd[11];
   char           user_old_pswd[11];
   char           user_cnt_pm[2]; /* PRACTICAL MILEAGE INQ.  V1.8 */
   char           user_cnt_pn[2]; /* Practical: No SMB      GDB V1.2 */
   char           user_cnt_po[2]; /* Practical: State only  GDB V1.2 */
   char           user_cnt_pb[2]; /* Practical: Both        GDB V1.2 */
   char           user_cnt_so[2]; /* Shortest: State Only   GDB V1.2 */
   char           user_cnt_sb[2]; /* Shortest: State Mileage  GDB V1.2 */
   char           user_cnt_an[2]; /* Audit Route Only         GDB V1.2 */
   char           user_cnt_mo[2]; /* Mileage Inq with Opt     GDB V1.2 */
   char           user_cnt_m[2];  /* Mileage Req              GDB V1.2 */
   char           user_cnt_o[2];  /* Origin Req               GDB V1.2 */
   char           filler;         /*                          GDB NF V1.5 */
} USER_DATA;
#endif

/*******************************************************
*  This structure contains the user conversion record
*  layout - 21 character user conversion code plus
*  corresponding geo file information.  The geo file
*  information is stored here to cut down on geo I/O
*  while processing user conversion functions.
*********************************************************/
typedef struct uc_in_rec
{
   char              uc_in_code[21];
   G_BUF_DATA_STRUCT uc_in_g_rec;
} UC_IN_STRUCT;

/*******************************************************
*  This is a union with the above structure and a
*  data buffer to allow reading and writing of the
*  union information to a file.
*******************************************************/
typedef union uc_rec_union
{
   char              uc_file_buf[60];
   UC_IN_STRUCT      uc_g_struct;
} UC_UNION;

/********************************************************
*  This typedef is used throughout the program to write
*  audit information to the audit trail file.  It is
*  also read by usage monitoring when the usage report
*  is being printed.
********************************************************/
typedef struct audit_struct
{
   char user_id[11];
   short  trans_type;
   short  num_trans;
   char   filler;        /* GDB NF */
} AUDIT_STRUCTURE;

/********************************************************
*  This typedef defines the structure used to hold user
*  conversion information.  It is much the same as the
*  in_scrn structure.  It occurs only once (not 14 times)
*  and is used in user conversion, get_in_line, g_io, and
*  main control processing.
*********************************************************/
typedef struct user_conversion
{
   char uc_key;                /* SPLC, CITY, or UC                         */
   char uc_alpha_flag;
   char alpha_flag;            /* set if an alpha character is found        */
   char uc_digit_flag;
   char digit_flag;            /* set if a digit character is found         */
   char other_flag;            /* set if a non alphanumeric character found */
   char uc_g_flag;             /* set before and after calls to g_io module */
   char in_city[19];           /* city entered in desc/loc fields           */
   char in_county[3];          /* county entered in desc/loc fields         */
   char in_state[3];           /* state entered in desc/loc fields          */
   char desc_data[22];         /* destination field from user conv screen   */
   char loc_data[22];          /* location fields from user conv screen     */
   char splc_data[11];         /* splc field from user conv screen          */
   short  splc_cnt;            /* length of data in splc field              */
   long splc_num;              /* numeric representation of splc field      */
   short  desc_cnt;            /* length of data in destination field       */
   long desc_num;              /* numeric representation of dest field      */
   short  loc_cnt;             /* length of data in location field          */
   short  desc_comma_flag_1;   /* set if there is a comma in desc/loc field */
   short  desc_comma_pos_1;
   short  desc_comma_flag_2;   /* set if there is a comma in desc/loc field */
   short  desc_comma_pos_2;
   short  comma_flag_1;        /* set if there is a comma in desc/loc field */
   short  comma_pos_1;         /* position of first comma in desc/loc field */
   short  comma_flag_2;        /* set of there is a 2nd comma in desc/loc   */
   short  comma_pos_2;         /* position of 2nd comma in desc/loc field   */
   char splc_space_flag;       /* set of there is a space in splc field     */
   short  splc_space_pos;      /* position of space in splc field           */
   char desc_space_flag;       /* set of there is a space in dest field     */
   short  desc_space_pos;      /* location of space in dest field           */
   short  g_rec_found;         /* indicates if geo record is found          */
} USER_CONV_STRUCT;


EXTERN USER_DATA system_user[MAX_SYS_USERS];   /* used in user pwd processing */
EXTERN USER_DATA *system_user_ptr; /* used in user pwd processing */
EXTERN USER_CONV_STRUCT user_conv; /* used in user conv processing*/
EXTERN UC_UNION g_conv_info;  /* used in user conv maint     */
EXTERN AUDIT_STRUCTURE rmc_audit;
