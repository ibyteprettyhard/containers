/****************************************************************/
/* Version: 17.5                                           */
/* File   : miletype.h                                           */
/* Changed: 8/22/97                                           */
/****************************************************************/

/************************************************************************
*  Revision :
*
*  Name               Date     Description                         Nbr
*  ---------------  --------   ----------------------------------  -----
*  Ira Rosen         5/18/93   Add filler to misc file to make      V1.0
*                              structure even for NCR computer. GDB NF
*  Louis London      9/9/93    Make stat_total and stat_toll long   V1.1
*  Rick Christiansen 4/18/95   Added ACA Zip Code Access            V1.2
*  Louis London      6/19/01   Add Lon/Lat Access                   V1.3
*  Louis London      9/23/05   Canadian Postal Changes              V1.4
************************************************************************/

#ifdef HPUX
#define REORDER
#endif

#ifdef SOLARIS
#define REORDER
#endif

#ifdef AIX
#define BIGENDIAN
#endif
#ifdef HPUX
#define BIGENDIAN
#endif
#ifdef SOLARIS
#define BIGENDIAN
#endif
#ifdef LINUXBIG
#define BIGENDIAN
#endif
#ifdef SCO
#define LITTLEENDIAN
#endif
#ifdef LINUX
#define LITTLEENDIAN
#endif

typedef struct geo_router_rec
{
   long g_rel_rec_no;           /* geo rr# for geo_io lookup - a #  */
   char g_rt_city[19];          /* city from geo_io to be displayed */
   char g_rt_state[3];          /* state from geo_io to be displayed*/
   short g_rt_state_num;        /* state number from geo file       */
} G_ROUTER_REC;


typedef struct g_loc   /* defines geo file location layout */
{
   char  g_int_loc_off[2];  /* GDB geo loc'n offset in network */
   short g_int_loc_pg;  /* Change for G17 geo location page in network    */
} GEO_INT_LOC_STRUCT;


typedef struct g_rec   /* defines geo rec - 1 rec per city */
{
   char               g_splc[4];    /* GDB was long geo splc of city */
   GEO_INT_LOC_STRUCT g_int_loc;    /* geo location - see above typedef   */
   char               g_corp[2];    /* geo corporate limit of city
   GDB was short */
   char               g_long[4];    /* GDB was short geo longitude of city*/
   char               g_lat[4];     /* GDB was short geo latitude of city */
   char               g_vic;        /* geo vicinity  of city              */
   char               g_zip[7];     /* geo zip code - Canadian zips OK    */
   char               g_state[3];   /* geo state of city - alpha format   */
   char               g_city[19];   /* geo city described - see typedef   */
} GEO_DATA_STRUCT;


typedef struct rt_aud_entry
{
   long      rt_pr_miles;            /* router request poshort pair mileage */
   char      rt_aud_g[3];            /* geo rel rec # of from audit point */
   long      rt_aud_miles;           /* mileage from point to audit point */
   char      rt_aud_g_to[3];         /* geo rel rec # of to audit point   */
   long      rt_aud_miles_to;        /* miles from to point to audit point*/
   short     rt_aud_flag;   /* V1.3 LONLAT Changes */
   short     rt_aud_flag_to;   /* V1.3 LONLAT Changes */
} RT_AUD_ENT;


typedef struct in_point  /* defines one input line on screen */
{
   char            in_data[22];        /* entire line of input - 21 chars  */
   char            g_search_city[19];  /* city searched for in geo file    */
   long            g_search_splc;      /* splc searched for in geo file    */
   long            g_search_zip;       /* V1.2 ZIP                         */
   char            in_city[19];        /* city,county input by user        */
   char            in_city_abbrev[19]; /* city, as represented w/abbrevs   */
   char            in_state[3];        /* state input by user - 2 chars    */
   char            in_county[3];       /* county input by user - 2 chars   */
   long            in_splc;            /* splc input by user - int format  */
   long            in_zip;             /* ZIP V1.2                         */
   long            in_lat;             /* Lon/Lat V1.3                     */
   long            in_lon;            /* Lon/Lat V1.3                     */
   GEO_DATA_STRUCT g_data;             /* geo record area - see above      */
   /* 8-31-96  Move for alignment G17 */
   char            alpha_flag;         /* indicates alpha char(s) input    */
   char            digit_flag;         /* indicates digit(s) input         */
   char            space_flag;         /* indicates space input            */
   short           space_pos;          /* position where space was input   */
   char            comma_flag_1;       /* indicates 1 comma was input      */
   char            comma_flag_2;       /* indicates 2nd comma was input    */
   short           comma_pos_1;        /* position where 1st comma input   */
   short           comma_pos_2;        /* position where 2nd comma input   */
   short           in_ch_cnt;          /* position within in_data array    */
   short           old_in_ch_cnt;      /* old position within in_data array*/
   char            in_key;             /* input key - city (C) or splc (S) */
   short           opt_seq;            /* optimization sequence - 1..n     */
   RT_AUD_ENT      rt_int;             /* router/display module interface  */
   char            g_status;           /* E, C, or S - router point status */
   char            g_rec_found;        /* indicates successful geo lookup  */
   char            *in_net_ptr;        /* pointer to network table record  */
   char            *rule_2_g_ptr;      /* pointer to geo record for rule 2 */
   char            czip_state[3];      /* V1.4 */
} IN_PUT_LINE;


typedef struct data_in   /* defines one screen of data        */
{
   char         req_user_seq_num[6];   /* interface user sequence number    */
   char         req_rrn[6];            /* interface relative rec number     */
   char         req_ws_addr[5];        /* workstation id for interface      */
   char         req_del_flag[2];       /* interface delete flag             */
   char         rout_rqst_type;        /* request type - short,prac,origin  */
   char         rout_state_miles;      /* indicates state mileage breakdown */
   char         rout_rules_on;         /* indicates hhg rules on or off     */
   short        in_line_cnt;           /* input line count - # of locations */
   short        pfkey;                 /* F1,F2,F3,F4,F5,F6,F7 or F8        */
   IN_PUT_LINE  in_line[14];           /* input line structure - see above  */
   char         in_dest_ascii[3];      /* input destination - ascii format  */
   short        in_dest;               /* input destination line #          */
   char         in_opt_rqst;           /* input optimization request - Y/N  */
   char         in_batch_rqst;         /* input batch request - Y/N         */
   char         in_batch_prt;          /* input print batch file - Y/N      */
   char         in_batch_del;          /* input delete batch file - Y/N     */
} IN_PUT_SCRN;


typedef struct req_msg_buf
{                                       /* request message buffer            */
   long         mtype;
   union
   {
      IN_PUT_SCRN       in_scrn;
      char              msg[sizeof(struct data_in)];
   } msg_u;
} REQ_MSG_BUF;

typedef struct state_abbrev
{                                      /* holds the state abbrevs and their */
   char st_abbrev[3];                  /* corresponding names. Initialized  */
   char st_name[19];                   /* in system init module.            */
   short st_order;                     /* Alpha name order w/in country */
} ST_ABBREV_TBL;

typedef struct abbrev_entry             /* structure for city name abbrevs   */
{                                       /* and corresponding names.  Read in */
   char        city_abbrev[5];          /* by system init module.            */
   char        city_phrase[35];
} ABBREV_TABLE;

typedef struct geo_calc_record          /* used to pass information between  */
{                                       /* orig/desc module and g_io module  */
   long               g_calc_splc;
   GEO_INT_LOC_STRUCT g_calc_pg_off;
} GEO_CALC_REC;


typedef struct month_table              /* used to convert month from a num  */
{                                       /* to a string for usage reporting   */
   char month_name[10];
} MONTH_STRUCT;

/* GDB change unsigned short to unsigned */
#ifdef BIGENDIAN
typedef struct /* trans_purch V1.10 */
{
   unsigned year_or_month:1;       /* LJL - AIX 2-26 */
   unsigned trans_purchased:15;    /* LJL - AIX 2-26 */
} TRANS_PURCH;
#else
typedef struct /* trans_purch V1.10 */
{
   unsigned trans_purchased:15;    /* LJL - AIX 2-26 */
   unsigned year_or_month:1;       /* LJL - AIX 2-26 */
} TRANS_PURCH;
#endif

typedef union    /* GDB V1.6 */
{
   TRANS_PURCH        tr_flags;        /* trans purch bit fields     */
   unsigned           tr_value;        /* trans purch numeric value  */
} TRANS_PURCH_UNION;

/* GDB change unsigned short to unsigned */
#ifdef BIGENDIAN
typedef struct /* curr_month_roll_over V1.10 */
{
   unsigned unused:4;      /* LJL - AIX 2-26 V1.13 */
   unsigned hhg_flag:1;    /* LJL - V1.13 */
   unsigned prac_flag:1;   /* LJL - V1.13 */
   unsigned opt_flag:1;    /* LJL - AIX 2-26 */
   unsigned roll_over:1;   /* LJL - AIX 2-26 */
   unsigned curr_month:8;  /* LJL - AIX 2-26 */
} MONTH_ROLL_OVER;
#else
typedef struct /* curr_month_roll_over V1.10 */
{
   unsigned curr_month:8;              /* KJK - AT&T */
   unsigned roll_over:1;               /* KJK - AT&T */
   unsigned opt_flag:1;                /* KJK - AT&T */
   unsigned prac_flag:1;               /* LJL 8-22-97 */
   unsigned hhg_flag:1;                /* LJL 8-22-97 */
   unsigned unused:4;                  /* LJL 8-22-97 */
} MONTH_ROLL_OVER;
#endif

typedef union    /* GDB V1.6 */
{
   MONTH_ROLL_OVER    mo_flags;        /* month roll over bit fields     */
   unsigned           mo_value;        /* month roll over numeric value  */
} MONTH_ROLL_UNION;

#ifdef REORDER
typedef union misc_values               /* stores miscellaneous values which */
{                                       /* must be saved between each use of */
   struct misc_fields
   {
#ifdef SEED_CODES /*{*/
      char customer_number[4];    /* Seed code 1 from accounting */
      char update_number[2];      /* Contains current transaction update */
      char key[2];                /* Contains encrypted key from accounting */
#endif SEED_CODES /*}*/
      char elapse_date[4];         /* payment check date GDB V1.6       */
      char trans_struct[2];        /* GDB V1.6 formerly TRANS_PURCH */
      char trans_used[2];          /* # of transactions used GDB V1.6   */
      char mon_roll[2];            /* current month for monthly turnover*/
      char curr_year[2];     /* current year for monthly turnover  GDB V1.6*/
      char interface_present;
      char interface_running;
      char supr_user_pwd[11];      /* super user password               */
      /* GDB V1.6 formerly MONTH_ROLL_OVER */
      char filler;      /* GDB NF V1.0 */
   } misc_struct;

   char misc_buf[sizeof (struct misc_fields)];
   long misc_align; /* LJL 9-5-96  Add for full word alignment */

} MISC_VAL_UNION;
#else
typedef union misc_values               /* stores miscellaneous values which */
{                                       /* must be saved between each use of */
   struct misc_fields
   {
      char supr_user_pwd[11];      /* super user password               */
      char trans_struct[2];        /* GDB V1.6 formerly TRANS_PURCH */
      char trans_used[2];          /* # of transactions used GDB V1.6   */
      char elapse_date[4];         /* payment check date GDB V1.6       */
      char mon_roll[2];            /* current month for monthly turnover*/
                                   /* GDB V1.6 formerly MONTH_ROLL_OVER */
      char curr_year[2];     /* current year for monthly turnover  GDB V1.6*/
      char interface_present;
      char interface_running;
#ifdef SEED_CODES 
      char customer_number[4];    /* Seed code 1 from accounting */
      char update_number[2];      /* Contains current transaction update */
      char key[2];                /* Contains encrypted key from accounting */
#endif 
      char filler;                /* GDB NF V1.0 */
   } misc_struct;

   char misc_buf[sizeof (struct misc_fields)];
   long misc_align; /* LJL 9-5-96  Add for full word alignment */

} MISC_VAL_UNION;
#endif

typedef struct message_buffer
{
   long mtype;

   union
   {
      char mtext[2];
      short msg_num;
   } msg_union;
} MM_MSG_BUF;

typedef struct state_lines
{
   short    stat_numb;
   long     stat_total; /* V1.1 */
   long     stat_toll;  /* V1.1 */
} STATE_LINES;

typedef struct
{   /**  Store mileage file structure for unresolved hotline **/
   long orig_splc; /* Change for alignment G17 8-31-96 */
   long dest_splc; /* Change for alignment G17 8-31-96 */
   long miles; /* Change for alignment G17 8-31-96 */
} HOT_LINE;

/* Below here are the data structures for the interface enhancements */
/* project according to the "Micro-MileMaker INTERFACE ENHANCEMENT   */
/* PROJECT TECHNICAL CONSIDERATIONS" - October 26, 1990.      */

/* Structure to contain city names for input request data - size: 24 bytes */
typedef struct city_req_rec
{
   char rtype[2]; /* Possible values: "OR", "VI", "DT". */
   char city[18];
   char county[2]; /* County qualifier - USUALLY blank */
   char state[2]; /* State abbreviation */
} CITY_REQ_RECORD;

/* To read in a header record - size: 24 bytes */
typedef struct header_req_rec
{
   char header_type[2]; /* Should contain "HR" for this record */
   char request_type[2]; /* Request type for the cities to follow */
   char dest_city_num[2]; /* Destination city number in "OP" requests */
   char user_info[18];  /* User supplied information as desired */
} HEADER_REQ_RECORD;

/* The next structure is to read a complete request - size: 360 bytes */
typedef struct request
{
   HEADER_REQ_RECORD header;  /* Header record */
   CITY_REQ_RECORD stopoff[14]; /* All city names */
} REQ_RTE;

/* This structure is for sending request structures via     */
/* message queues using the mtype field for a message type. */
typedef struct msg_req
{
   long mtype;
   REQ_RTE req_rte;
} MSG_REQ;



/* All structures from here on down are for response data */

/* This structure is for the answer record header - size: 69 bytes */
typedef struct header_ans_rec
{
   char request_type[2]; /* Request type for the cities to follow */
   char user_info[18];  /* User supplied information as desired */
   char filler[49];  /* Will contain all blanks */
} HEADER_ANS_REC;


/* This structure is for a mileage answer record - size: 69 bytes */
/* Multiples of this record will be used for "MD" type records.   */
typedef struct mileage_ans_rec
{
   char city_1[18];
   char county_1[2];
   char state_1[2];
   char city_2[18];
   char county_2[2];
   char state_2[2];
   union
   {
      char c_total[7];
      long n_total;
   } total;
   union
   {
      char c_toll[7];
      long n_toll;
   } toll;
   union
   {
      char c_non_toll[7];
      long n_non_toll;
   } non_toll;
   char filler[7];  /* Will contain all blanks */
} MILEAGE_ANS_REC;

/* This structure is for stopoff records - size: 69 bytes */
/* Relevant only for "MI" and "OP" type request records.  */
typedef struct via_ans_rec
{
   char city[18];
   char county[2];
   char state[2];
   char miles_from_last[7];
   char filler[40];  /* Will contain all blanks */
} VIA_ANS_REC;

/* This structure is for detail route records - size: 69 bytes */
/* Relevant for all request types involving routing responses. */
typedef struct route_ans_rec
{
   char hwy[16];  /* Highway name for this route segment */
   char dirxn[2];  /* Travel direction for this segment */
   union
   {
      char c_miles[6];
      long n_miles;
   } miles;   /* Miles Travelling on this segment */

   char place[27];  /* Ending location for this segment */
   char accum_time[6];  /* Accumulated time: origin to end_place[] */
   union
   {
      char c_miles[8];
      long n_miles;
   } accum_miles;  /* Accumulated miles: origin to end_place[] */
   char notes[6];  /* e.g. Toll booths, ferries, ... */
} ROUTE_ANS_REC;

/* This structure is used for state mileage breakdowns - size: 69 bytes */
typedef struct smb_ans_rec
{
   struct smb_recs
   {
      char state[2];  /* State abbreviation */
      union
      {
         char c_total[5];
         long n_total;
      } total;   /* Total miles travelled in state */
      union
      {
         char c_toll[5];
         long n_toll;
      } toll;   /* Total toll miles travelled in state */
      union
      {
         char c_non_toll[5];
         long n_non_toll;
      } non_toll;   /* Total non-toll miles travelled in state */
   } state_recs[4];  /* To contain 4 state mileage breakdowns */

   char filler[1];  /* This field will contain all blanks */
} SMB_ANS_REC;

/* This structure is for returning errors - size: 69 bytes */
typedef struct error_ans_rec
{
   union
   {
      char c_err[2];
      short n_err;
   } code; /* Contains the relevant error code for the request */
   char filler[67]; /* This field will contain all blanks */
} ERROR_ANS_REC;

/* This structure indicates the last answer record - size: 69 bytes */
typedef struct last_ans_rec
{
   char filler[69];  /* This field will contain all blanks */
} LAST_ANS_REC;

/* This structure will contain the answer going back */
/* to the host.  All members in the union are 69     */
/* bytes long, so this structure is 71 bytes.      */
typedef struct answer
{
   char record_type[2];
   union
   {
      HEADER_ANS_REC head_rec;
      MILEAGE_ANS_REC mile_rec;
      VIA_ANS_REC via_rec;
      ROUTE_ANS_REC rte_rec;
      SMB_ANS_REC smb_rec;
      ERROR_ANS_REC err_rec;
      LAST_ANS_REC last_rec;
   } a_u;
} ANS_RTE;

/* This structure is for sending the answer via */
/* message queues with the message type field.  */
typedef struct msg_ans
{
   long mtype;
   ANS_RTE ans;
} MSG_ANS;
