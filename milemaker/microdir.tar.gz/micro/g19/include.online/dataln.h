/****************************************************************/
/* Version: 17.2                                           */
/* File   : dataln.h                                           */
/* Changed: 5/28/97                                           */
/****************************************************************/

/*********************************************************************
*    Header Name:       dataln.h
*
*    Description:       This file contains information used to process
*                       line of data after it has been keyed in.
*
*    History:
*
*        Name         Date           Description Of Change
*   --------------  --------    --------------------------------------
* John McCloskey    11/05/88    Original header file.
* Louis London       7/25/08    Changes for 48 ft trailer length  V1.1
**********************************************************************/

typedef struct
{
   long           Splc; /* SPLC FOR KEYED IN POINT     */
   long           Calc_Splc; /* SPLC FOR NODE FOR CALC      */
   long           Long; /* LONGITUDE                   */
   long           Lat;  /* LATITUDE                    */
   short          Corp; /* CORPORATION CODE            */
   short          Vic;  /* VICINITY                    */
   short          Line_No; /* LINE NUMBER OF ENTRY        */
   short          Page; /* Change for G17 LJL 8-28-96      */
   short          Offset; /* OFFSET FROM PAGE            */
}  DATA_LINE;

typedef struct
{
   DATA_LINE Or;
   DATA_LINE De;
   short Status;
   long  Miles;
   long        Calc_Miles_0; /* LJL 3-23-94 opt fix */
   long        Calc_Miles_1; /* LJL 3-23-94 opt fix */
   long        Or_Splc;      /* LJL 3-29-94 opt fix */
   long        De_Splc;      /* LJL 3-29-94 opt fix */
   unsigned char     trailer_length; /* V1.1 */
}  SHM_OPT;

typedef struct
{
   char      Rqst_Type; /* REQUEST TYPE                */
   char      Rules_On;  /* INDICATES IF RULES INVOKED  */
   unsigned char     tollbs;  /* Toll bias added with Guide 16 */
   unsigned char     trailer_length; /* V1.1 */
   DATA_LINE Or;  /* ORIGIN POINT INFO           */
   DATA_LINE De;  /* DESTINATION POINT INFO      */
}  PASSED_INFORMATION_IN;

typedef struct
{
   long Miles; /* # MILES FOUND BY CALCULATION*/
   long  Shm_Key; /* SHARED MEMORY BLOCK KEY     */
   short Cnt_Lines; /* # LINES TO DISPLAY ON SCREEN*/
   /* TECHNICALLY, SHOULD BE KEY_T*/
   char  Status; /* STATUS OF TRANSACTION       */
   CALC_SEC_INFO Calc_Infrm[2];
   long  Or_Return;
   long  De_Return;
   char  filler[16]; /* Make structure size equal PASSED_INFORMATION_IN */
}  PASSED_INFORMATION_OUT;
