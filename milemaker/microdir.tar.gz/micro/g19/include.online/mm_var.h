/****************************************************************/
/* Version: 16.2                                           */
/* File   : mm_var.h                                           */
/* Changed: 5/28/97                                           */
/****************************************************************/

#undef EXTERN
#ifdef DEFINE_HERE
#define EXTERN
#else
#define EXTERN extern
#endif

#define STATE_INVALID	2
#define CITY_INVALID	3
#define SPLC_INVALID	4
#define MILE_INVALID	5
#define DIR_INVALID	6
#define NULBYT		'\0'
#define SPACE		' '
#define BLANKS		"                                                                       "


EXTERN char in_city1[19];
EXTERN char in_cnty1[3];
EXTERN char in_state1[3];
EXTERN char in_city2[19];
EXTERN char in_cnty2[3];
EXTERN char in_state2[3];
EXTERN char in_city3[19];
EXTERN char in_cnty3[3];
EXTERN char in_state3[3];
EXTERN char in_city4[19];
EXTERN char in_cnty4[3];
EXTERN char in_state4[3];
EXTERN char request[3];
EXTERN char trailer_length[3];
