/****************************************************************/
/* Version: 17.2                                           */
/* File   : milemaker.h                                           */
/* Changed: 7/17/97                                           */
/****************************************************************/

/************************************************************************
*    Header Name:       Milemaker.h
*
*    Description:       This is the main header file for the
*                       Milemaker project.  It defines the
*                       mega-structure and external variables.
*
*    History:
*
*        Name         Date           Description Of Change
*   --------------  --------    --------------------------------------
* Rick Christiansen  4/23/87    Original header
*
* Rick Christiansen  4/23/87    Added 1 to the length of each char
*                               array declaration.  Initialized row
*                               and col variables to zero.  Added
*                               new variable NUM_IN_LINES to contain
*                               the no of input lines on our screens.
*
* Anne Lindenlaub    4/27/87    Changed zip in geo_rec from an integer
*                               field to a 7 byte char field in order
*                               to handle Canadian zip codes.
*
* Anne Lindenlaub    4/27/87    Now input_screen is actually declared
*                               within this header, not just its type.
*
* Anne Lindenlaub    4/27/87    Changed variable names 'row' and 'col'
*                               to 'scrn_row' and 'scrn_col' so names
*                               would not conflict with CURSES function
*                               variable names.
*
* Anne Lindenlaub    4/27/87    Added several #define and variables.
*
* Anne Lindenlaub    4/30/87    Changed data names to shorten them for
*                               easier programming.  Standard abbrevs
*                               include :
*                                         input       ---> in
*                                         geo         ---> g
*                                         request     ---> rqst
*                                         screen      ---> scrn
*                                         destination ---> dest
*                                         location    ---> loc
*                                         block       ---> blk
*                                         length      ---> len
*
*                               Also added a few more #defines.
*
* Anne Lindenlaub    5/07/87    Added three more #defines.
*
*                               Also commented out the g_city_data
*                               structure, and made the field g_city
*                               within the structure g_rec simply an 18
*                               byte character string (plus 1 for NULL).
*
*                               Also changed the fields g_int_loc_pg,
*                               g_vic, and g_state to be single byte char
*                               fields instead of 2 byte int fields.
*
* Anne Lindenlaub    5/14/87    Added error processing variables,
*                               abbreviation table variables, and two
*                               orig/dest setup pointers.  Also combined
*                               rqst_type and mile_or_route fields into
*                               just rqst_type.
*
* Anne Lindenlaub    5/26/87    Updated G_PREFIX_LEN to be 5 instead of
*                               8.  Took out CITY_IND_LEN, because this
*                               is a variable which will be determined
*                               when the geo indexes are built.  Added
*                               SPLC_IND_LEN, as we have decided on
*                               its length prior to index building.
*                               The types for variables in_net_ptr and
*                               rule_2_g_ptr were changed from long to
*                               character pointers. Put an EXTERN in
*                               front of the abbrev_tbl variable.
*
* Anne Lindenlaub    6/5/87     Added file descriptiors for geo index
*                               files as external.  Added some variables
*                               and #defines for the router and display
*                               modules:
*                                        rt_status
*                                        *batch_ptr
*                                        MILE_INQ
*                                        ORIG_INQ
*                                        PRAC_INQ
*                                        SHORT_INQ
*                               Changed router interface names to
*                               be shorter, and added a typedef
*                               G_ROUTER_REC.
*
* Anne Lindenlaub    6/9/87     Added four new #defines -- SPACE, NULBYT,
*                               SPACENUL, and DOTNUL.
*
* Anne Lindenlaub    6/16/87    Added state lookup table definition.
*                               Added 2 new #defines - RETURN_NON_FATAL
*                               and BROWSE_LIST_LEN.  Changed SEC_KEYPT
*                               name to SYS_MAINT. Added browse_flag variable.
*                               In GEO_DATA_STRUCT, changed g_state to
*                               g_state[3].  In IN_PUT_SCRN, changed the
*                               variables rout_rqst_type, rout_state_miles,
*                               rout_rules_on, in_opt_rqst, and in_batch_rqst
*                               from int to char.  Changed g_rel_rec_no from
*                               int to char (g_rel_rec_no[3]).  Added
*                               g_blks_written as a global variable.
*
* Anne Lindenlaub    6/25/87    Return codes and router request types
*                               removed from milemaker.h and placed in
*                               constants.h.  Four new request types added.
*                               Changed #define values for OPT_Y, DEST_Y,
*                               and BATCH_Y.  Added new #defines:
*                                       BATLP_Y
*                                       BATLP_X
*                                       BATRM_Y
*                                       BATRM_X
*                               File descriptors state_abb_fd, data_file_fd,
*                               and g_bin_file_fd were added. A field was
*                               also added to the G_ROUTER_REC structure.
*
* Anne Lindenlaub    6/30/87    Added #defines for USER_ID_ROW  and
*                               USER_ID_COL.  Also the file pointer
*                               *acct_log_ptr and the variable system_user_cnt.
*                               Deleted variable g_rel_rec_char -- don't need.
*
* Anne Lindenlaub    7/6/87     Added several new #defines.  Also added new
*                               num_inputted_lines, last_stroke, prac_loc_fd,
*                               and short_loc_fd variables.  Added the field
*                               st_name to the st_abbrev_tbl typedef.  Changed
*                               LAST_LOC_ROW from 20 to 19.  Added g_rt_rec_num
*                               variable to G_ROUTER_REC.
*
* Anne Lindenlaub    7/22/87    Added #defines for ROUT_ERROR, MISC_BUF_LEN,
*                               BROWSE_X, BROWSE_Y, BROWSE_DIGITS, and UC. The
*                               #defines for COUNTY_Y, COUNTY_X_1 and
*                               COUNTY_X_2 have been taken out.
*                               Added variables user_rqst, browse_num_in,
*                               br_sub, and browse_choice.  Added structure
*                               typedefs for MONTH_STRUCT, GEO_CALC_REC,
*                               MISC_VAL_UNION.  Added structure definitions
*                               for month_tbl, g_calc_info, and misc_vals.
*                               Deleted abbrev_union structure - not needed
*                               when binary instead of sequential search used.
* Louis London       9/9/93     Make disp_tot_miles long    V1.1
* Rick Christiansen  4/18/95    Added ACA Zip Code Access   V1.2
* Kristopher Krause  4/17/97    Added file handle and zero_flag   V1.3
*                               variable for ZERO MILES PROCESSING
* Louis London       6/23/97    Add praczip_flag and zipdefault_flag V1.4
* Louis London       6/25/97    Remove practical zip logic   V1.5
* Louis London       6/22/01    LONLAT Lookup changes        V1.6
* Louis London       5/9/07     NF/NL Changes                V1.7
* Louis London       7/28/08    Changes for 48 ft trailers   V1.8
**********************************************************************/
#undef EXTERN
#ifdef DEFINE_HERE                      /* used in source modules    */
#    define EXTERN                      /* so that variables are     */
#else                                   /* defined within the header */
#    define EXTERN extern               /* module, and then defined  */
#endif                                  /* externally in the other   */
/* source modules.           */

#define PRACTICAL_WHOLE
#include <constants.h>
#include "miletype.h"

/******************************************************
*                                                    *
*  The following are return codes used to check      *
*  true/false returns.  YES/NO are used to set       *
*  and check flags, while RETURN_OK and              *
*  RETURN_NOT_OK are used to check returns from      *
*  functions.  They are commented out here because   *
*  they are within the constants.h header file.      *
*  Constants.h is included in milemaker.h            *
*                                                    *
******************************************************/
EXTERN int pfkey;                       /* pfkey value the user entered     */
EXTERN char uc_maint_flag;              /* Y/N - signals if in uc maint     */
EXTERN char g_calc_flag;                /* Y/N - calc/secondary flag        */
EXTERN char sys_maint_flag;             /* Y/N - signals system maintenance */
EXTERN char uc_func_flag;               /* Y/N - signals user conv function */
EXTERN char payment_due_flag;           /* Y/N - signals poor payment history*/
EXTERN char out_of_trans_flag;          /* Y/N - signals no transactions left*/
EXTERN FILE *r_log;                     /* pointer to error log file        */
EXTERN FILE *acct_log_ptr;              /* pointer to accounting log file   */
EXTERN FILE *mini_acct_log_ptr;         /* ptr to mini accounting log file  */
EXTERN int splc_ind_fd;                 /* geo splc index file descriptor   */
EXTERN int city_ind_fd;                 /* geo city index file descriptor   */
EXTERN int state_ind_fd;                /* geo state index file descriptor  */
EXTERN int state_abb_fd;                /* state abbrev tbl file descriptor */
EXTERN int data_file_fd;                /* input geo file descriptor for geo*/
EXTERN int lonlat_file_fd;  /* V1.6 */  /* lonlat file descriptor           */
EXTERN int lonlat_index_fd; /* V1.6 */  /* lonlat index file descriptor     */
EXTERN int zip_file_fd;  /* ZIP V1.2 */  /* geo zip index file descripto    */
EXTERN int zip_index_fd; /* ZIP V1.2 */  /* input geo file descriptor       */
/*                                         I/O, output for index building   */
EXTERN int prac_loc_fd;                 /* practical locator file descriptor*/
EXTERN int short_loc_fd;                /* shortest locator file descriptor */
EXTERN int last_pg_disp;                /* last route or mileage pg diplayed*/
EXTERN char *first_route_ptr;           /* malloc ptr for route display func*/
EXTERN char pg_up_down;
EXTERN int g_blks_written;              /* # of blks in geo blocked file    */
EXTERN char browse_state[3];            /* formatted by browse, used by I/O */
EXTERN char browse_city[19];            /* formatted by browse, used by I/O */
EXTERN int num_inputted_lines;          /* # of lines input by user         */
EXTERN int last_stroke;                 /* saves last stroke entered by user*/
EXTERN int option_fd;                   /* V1.3 */
EXTERN int zero_flag;                   /* V1.3 */
EXTERN int zipdefault_flag;             /* V1.4 */
EXTERN int Newfoundland_flag;           /* V1.7 */


/******************************************************
*  The following are variables used to handle        *
*  error processing throughout the milemaker source  *
*  programs.  These values are set when an error is  *
*  encountered.  The return_code then != RETURN_OK,  *
*  and processing will drop out of the main loop.    *
*  An error message based upon these variables will  *
*  then be displayed.                                *
******************************************************/
EXTERN long disp_tot_miles;              /* defined 4/18/90 MWL V1.1 */

EXTERN G_ROUTER_REC g_rt_rec;
EXTERN STATE_LINES sdl[STATE_IND_LEN + 2]; /* Guide 16 */ /* V1.6 */
EXTERN ABBREV_TABLE abbrev_tbl[ABBREV_TBL_LEN];
EXTERN ST_ABBREV_TBL state_abbrev_tbl[];
EXTERN MONTH_STRUCT month_tbl[];   
EXTERN GEO_CALC_REC g_calc_info;
EXTERN MISC_VAL_UNION misc_vals;
EXTERN IN_PUT_SCRN in_scrn;   /* data from the inquiry input scrn  */
EXTERN MM_MSG_BUF mm_msg_buf;
EXTERN int msg_q_id;
EXTERN MSG_ANS a_msg;
EXTERN MSG_REQ R_Msg;
EXTERN int count_sends; /* # transmission blocks sent to host */
EXTERN short kount_recs; /* # response records sent to write_answer() */
EXTERN short max_lines_put; /* Maximum response recs per answer transmit */
EXTERN short max_names_recs; /* Maximum response recs per names transmit */
EXTERN short total_hot;
EXTERN int trailer_flag;
EXTERN int hhg48_enable;
