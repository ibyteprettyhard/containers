/****************************************************************/
/* Version: 16.2                                           */
/* File   : paint_menu.h                                           */
/* Changed: 5/28/97                                           */
/****************************************************************/
/****************************************************************************
*
*	Header Name :   paint.h
*
*	Description :   This header file contains data used when dealing with 
*                       screen I/O.  
*
*	History :
*
*	    Name	   Date			Description
*   --------------------  ----------   -------------------------------------
*   Anne Lindenlaub	   7/07/87	Created
*
*****************************************************************************/

#undef EXTERN
#ifdef DEFINE_HERE
#define EXTERN
#else
#define EXTERN extern
#endif


#define MAIN_MENU   1
#define GEO_INQ     2
#define GEO_EDIT    4

#define CITY1_ROW	5
#define CITY_COL	10
#define CNTY_COL	35
#define STATE_COL	41
#define CITY2_ROW	6
#define CITY3_ROW	7
#define CITY4_ROW	8
#define TYPE_ROW	9
#define TRAILER_ROW	10
#define TRAILER_COL	20
#define TYPE_COL	13
EXTERN short current_scrn_type;


typedef struct constants {
    short  cy, cx;	/* position of header string */
    char *cstring;	/* pointer to header string */
} CONSTANT_STRUCT;

typedef struct pwd_lines {
    short  yprompt, xprompt;	/* position of line */
    char *prompt;		/* pointer to line prompt */
    short  yloc, xloc; 		/* position of location input */
    char user_inp[36];          /*                            */
} USER_MAINT_STRUCT;




EXTERN CONSTANT_STRUCT geo_maint[];

EXTERN CONSTANT_STRUCT geo_constant[];

EXTERN USER_MAINT_STRUCT  geo_inq[];
