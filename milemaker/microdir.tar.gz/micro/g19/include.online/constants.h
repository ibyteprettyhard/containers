/****************************************************************/
/* Version: 17.3                                           */
/* File   : constants.h                                           */
/* Changed: 5/28/97                                           */
/****************************************************************/

/***********************************************************************
* Header Name :   constants.h
*
* Description :   This is a header file broken out of milemaker.h
*  so that the router can include this only.  Therefore,
*   milemaker.h includes this header file.
*
* History :
*
*     Name    Date   Description             Ver.
*   ----------------  ----------    ----------------------------------- ----
*   Anne Lindenlaub    6/25/87  Created
*
*   Anne Lindenlaub        7/08/87  Added RETURN_COUNTY.
*   Ira Rosen     5/18/93  GDB NF for NCR                      1.0
*   Rick Christiansen      4/18/95  Added ACA Zip Code Access          V1.1
*   Kristopher Krause      4/12/96  Added record type changes for new  V1.2
*                                   menu option - PRAC. MILEAGE INQ.
*   Louis London           6/19/01  Changes for LONLAT lookups         V1.3
*   Louis London           2/14/02  Add Guide 18 rules changes         V1.4
*   Louis London           9/23/05  Canadian Postal Changes            V1.5
*   Louis London          10/8/08   48 ft changes                      V1.6
****************************************************************************/
#ifdef AIX
#define BIGENDIAN
#endif
#ifdef HPUX
#define BIGENDIAN
#endif
#ifdef SOLARIS
#define BIGENDIAN
#endif
#ifdef LINUXBIG
#define BIGENDIAN
#endif
#ifdef SCO
#define LITTLEENDIAN
#endif
#ifdef LINUX
#define LITTLEENDIAN
#endif

#undef EXTERN
#ifdef DEFINE_HERE   /* used in source modules    */
#    define EXTERN    /* so that variables are     */
#else     /* defined within the header */
#    define EXTERN extern  /* module, and then defined  */
#endif     /* externally in the other   */

#define RULES_OFF /* V1.4 */

/* source modules.           */
/* General constants */
#define YES  'Y'
#define NO  'N'
#ifndef FALSE
#    define FALSE   0
#    define TRUE   1
#endif
#define MATCH   0

/* For Generic Data Base (GDB) conversions from character data types */
#define GDBS(x) *(short *) x  /* Convert to type short */
#define GDBL(x) *(long *) x  /* Convert to type long */
#define GDBU(x) *(unsigned *) x  /* Convert to type unsigned */
#define GDBUS(x) *(unsigned short *) x /* Convert to type unsigned short */

/* Return codes, request codes, etc... */
#define RETURN_OK  0
#define RETURN_NOT_OK  1
#define RETURN_NON_FATAL 2
#define RETURN_COUNTY  3
#define RETURN_BAD_CALC  4
#define RETURN_SECONDARY 8
#define INVALID_REQ -2
#define REC_FOUND 0
#define REC_NOT_FOUND 1

/* One letter indicators for request types */
#define MILE_INQ 'M'
#define ORIG_INQ 'O'
#define PRAC_INQ 'P'
#define SHORT_INQ 'S'
#define AUDIT_INQ 'A'
#define MILES_BOTH 'B'
#define MILES_ONLY 'O'
#define MILES_NO 'N'

/* Interface message queue constants *******/
#define INT_INFO 3L
#define INIT_RETURN 5L

/* Interface record types for requests and answers */
#define DEST_REC "DT" /* Contains destination city in a requests */
#define DETAIL_ROUTE "DR" /* Detail route for a trip segment response */
#define ERR_REC  "ER"
#define HEADER_REC "HR" /* Header record for requests and responses */
#define LAST_REC "LR" /* Last record for a request or response */
#define MILEAGE_REC "MI" /* Total, toll, and non-toll miles: response */
#define ORIGIN_REC "OR" /* Contains origin city in a request */
#define STATE_MILES "SM" /* State mileage breakdown in a response */
#define STOPOFF_REC "VI" /* Contains stopoff cities in a request */
#define DETAIL_MILES    "DM"    /* V1.2 - modified version of VI & DR    */
#define TRAILER_REC     "TL"  /* Trailer length record V1.6 */
#define REQ_TYPE_SIZE 2 /* Request/answer type field record size. */

/* Interface request types */
#define PRAC_MILES      "PM"    /* V1.2 - for practical miles only */
#define OPTIMIZATION "OP" /* Optimized mileage inquiry */
#define MILEAGE_INQ "MI" /* HHG Mileage only - F1 */
#define MULTI_DEST "MD" /* Single origin multiple destination - F2 */
#define HHG_AUDIT "HA" /* HHG audit route only - F3 */
#define HHG_ROUTE_SMB "HS" /* HHG state mileage breakdown only - F4 */
#define HHG_FULL "HB" /* HHG route w/state mileage breakdown - F5 */
#define PRAC_ROUTE "PR" /* Practical route only - F6 */
#define PRAC_ROUTE_SMB  "PS" /* Practical route state breakdown only - F7 */
#define PRAC_FULL "PB" /* Practical route w/state breakdown - F8 */
#define MORE_SCREENS "SM" /* Need to send more response data to host */
#define SEND_NAMES "SN" /* Request to send geo file to host */
#define POLL  "PL" /* Simulated ZZZZPOLL */

/* Interface values for the techland card and communication protocol */
#define AS400  "AS400" /* Interface host is an IBM AS/400 */
#define CUSTOM_HOST "CUSTM" /* Client has a custom interface host */
#define EB_SPACE 64 /* EBCDIC space character */
#define END_READ_CHAR '\012' /* Ascii line feed */
/* removed for ZIP access
#define END_SPLC_OFFSET 7
*/
#define END_SPLC_OFFSET 6       /* ZIP V1.1 */
#define END_ST_OFFSET 23 /* Offset: city record start to end of state */
#define I_II  0x02 /* Input Inhibited indicator for IBM host */
#define I_MW  0x02 /* Message waiting indicator for IBM host */
#define LU_MMM  0 /* Host lu number for milemaker usage */
#define MASK_HI_BIT 0x7f
#define MORE_ANS_POS 3
#define NAMES_CHARS 25 /* Read full SM request for names transfer. */
#define NUM_READ_CHARS 1 /* Serial port holds 256 chars, get 1/read() */
#define OFFSET  0
#define REQ_LEN_CUSTM 361 /* Custom I/F request length */
#define REQ_LEN  1917 /* Standard I/F request length */
#define S36  "SYS36" /* Interface host is an IBM System/36 */
#define S38  "SYS38" /* Interface host is an IBM System/38 */
#define SCAN_ENTER 0x68 /* Scan code for enter key */
#define SCAN_H  0x16 /* Scan code to send 'H' to host */
#define SCAN_SPACE 0x0F /* Scan code for space bar */
#define SCREEN_HEADER "  H1" /* Screen indicating for more/last screen */
#define SCREEN_SIZE 1920 /* Screen size (chars) for sending host data */
#define SECOND_CHAR 'R' /* Second character in data sent from host */
#define SET_HI_BIT 0x80
#define START_CHAR 'H' /* Lead character in data sent from host */
#define START_READ_POS 2  /* Begin reading from screen position 3 */
#define UNLIMITED_TRANS 32767
#define Z_OFFSET 0

/* interface constants for message queue usage*******/
#define INTFC_PID_MSG 66L
#define MSG_KEY  30L
#define MSG_FLAG 0666
#define NO_INTERFACE 99

/* Interface enhancement project error codes */
#define VALID_REQUEST  00
#define INV_REQ_TYPE  01
/* #define FREE_VALUE_1  02 */
/* #define FREE_VALUE_2  03 */
/* #define FREE_VALUE_3  04 */
#define INV_CITY_1  05
/* #define FREE_VALUE_4  19 */
#define INV_ST_1  20
/* #define FREE_VALUE_5  34 */
#define NEED_CT_1  35
/* #define FREE_VALUE_6  49 */
#define ROUTE_ERR_CODE  50
/* #define FREE_VALUE_7  64 */
#define INVALIDE_ZIP_REQ_TYPE 64        /* ZIP V1.1 */
#define SECOND_ERR_CODE         49        /* ZIP V1.1 */
#define MULTI_ZIPS  65        /* ZIP V1.1 */
#define REQUEST_IN_PROGRESS 79
#define CALC_POINT_ERR  80
#define INV_TRAILER_LENGTH 90
#define DUP_OPTIMIZE_CITIES 94
#define PLEASE_CONTACT_TDM 95
#define OUT_OF_TRANSACTIONS 96
#define TOO_MANY_TO_OPTIMIZE 97
#define TOO_FEW_TO_OPTIMIZE 98
#define HAS_NO_OPTIMIZATION 99


/********************************************************
*  The following constants used throughout different *
*  source files, and therefore are declared in this *
*  header so they can be used globally.  The first *
*  group is general text type constants.  The second *
*  group is numerical MileMaker values.  *
********************************************************/
#define BLANKS   "                              "
#define CALC_STAT  'C'
#define CITY   'C'
#define COMMA   ','
#define COMNUL   ",\0"
#define ERROR_STAT  'E'
#define FILE_MODE  0666
#define NULBYT   '\0'
#define PERIOD   '.'
#define PG_UP   'U'
#define PG_DOWN   'D'
#define PG_FIRST  'F'
#define PG_LAST   'L'
#define ROUT_ERROR  'R'
#define ROUTE_LINE  'R'
#define SET   1
#define SPACE   ' '
#define SPACNUL   " \0"
#define SPLC   'S'
#define ZIP   'Z'  /* ZIP V1.1 */
#define LONLAT           'L'     /* V1.3 */
#define CANZIP           'P'     /* V1.5 */
#define LOWLAT            1470   /* V1.3 */
#define HILAT             7128   /* V1.3 */
#define LOWLON            5270   /* V1.3 */
#define HILON             16668  /* V1.3 */
#define SQUARE(a) ((a) * (a)) /* Actually, only in calcdist.c */
#define ROUND( a,b )         round(a,b)
#define TRUNC(a,b)           trunc(a,b)
#define STORE_STAT  'S'
#define SYS_ERROR_STAT  'X'
#define UC   'U'
#define UC_DESC   'D'
#define UC_LOC   'L'
#define ZERO   0

/* MileMaker numerical constants shared by more than one source file */
#define ABBREV_TBL_LEN  312
#define ABBREV_ENTRY_LEN 40
#define BUFFERSIZ  512
#define G_RECS_PER_BLOCK 14 /* 8-31-96 Change for new alignment on geo file */
#define G_REC_LEN  36 /* 8-31-96 Change for new alignment on geo file */
#define G_PREFIX_LEN 8  /* 8-31-96 Change for new alignment on geo file */
#define LOC_FLD_LEN  21
#define NUM_IN_LINES  14 /* 28 for stand-alone */
#define REC_AGE   60
#define SPLC_IND_LEN  1600 /* was 1070 */
#define STATE_IND_LEN  97 /* Was 64 for Guide 15 */
#define STATE_LINE  'S'
#define SUBAMT   1 /* GDB NF V1.0 */
#define STATES_PER_REC  4 /* States per-state mileage breakdown */
#define TOTAL_BAD_SPLC  1 /* Guide 16 */
#define TOTAL_GOOD_SPLC  1 /* Guide 16 */
#define SECONDARY_LOW_PAGE    1000  /* check for secondary point V1.23 */
#define SECONDARY_HIGH_PAGE  32767  /* check for secondary point V1.23 */
#define CALC_PAGE               -1  /* check for calc point      V1.23 */


/************************************************
*  The following are provided to simplify data *
*  access to mega-structure variables.  *
************************************************/
#define CURRENT_SCRN_POSITION &output_buf[CURRENT_POSITION]
#define GEN_ERR  a_msg.ans.a_u.err_rec
#define IN_PREFIX in_scrn.in_line[in_scrn.in_line_cnt]
#define LINE_NO  in_scrn.in_line_cnt
#define MSG  a_msg.ans.a_u
#define O_ERROR  a_msg.ans.a_u.err_rec.code.n_err
#define PREFIX  in_scrn
#define R_PREFIX R_Msg.req_rte.stopoff[in_scrn.in_line_cnt]
#define RECS_SENT ((count_sends * max_lines_put) + kount_recs)

/* Constants broken out of taskscrn.c */
#define ATTACH_MEM  4
#define ATTACH_PROC  5
#define DEFINITE_ERROR   8
#define DETACH_MEM  2
#define DETACH_PROC  6
#define FAILURE  (char *) -1
#define FNULL  (char *) 0
#define HWY_NM_LN  16
#define KILL_MSG  1
#define LNM_KEY  (key_t) 8
#define LNM_SEND  1
#define MAX_TERMINAL  6
#define MAX_TRANS  14
#define NO_NEED_TO_RECEIVE  -1
#define NO_MSG   0
#define PROBABLE_ERROR   4
/* #define RT_STATES   96 */ /* 64 for G15 became STATE_IND_LEN */
#define SHM_SEND  2
#define SIGNAL_RTR  3
#define SIZE   30

/* Louis London 9-2-96 add the following */

#ifdef BIGENDIAN
#define LO_BYTE 1
#define HI_BYTE 0
#else
#define LO_BYTE 0
#define HI_BYTE 1
#endif
