/****************************************************************/
/* Version: 1.2                                                 */
/* File   : client_app.h                                                 */
/* Changed: 5/28/97                                                 */
/****************************************************************/
/******************************************************************************
*    Header name :	client_app.h
*
*    Description :	
*
*    History :
*
*        Name		  Date		       Description of change
* -----------------    ----------	--------------------------------------
* Rick Christiansen    11/22/95         Original Header
*
******************************************************************************/

#define MAX_CITIES 14      /* max # of cities per request */
#define LINELEN    25      /* city - 18; county - 2; state -2; null byte -1 */
#define YES         1
#define NO          0
#define QUIT 9999
#define END_RECORD "LR"    /* First 2 chars of last ans. rec. for request */
#define ANSWER_REC_SIZE 71 /* Answer record size */
#define MAX_NUB_RECS 350   /* Max number of answer recs per request */

typedef struct
{
   char req_type[3];
   char trailer_length[3]; /* Structure to contain Trailer Length - size: 2 bytes */
   char req_city[MAX_CITIES][LINELEN];
} USER_IN_STRUCT;

/* Structure to contain Trailer Length - size: 2 bytes */
typedef struct trailer_record
{
    char trailer_length[3];
} TRAILER_RECORD;

/* Structure to contain city names for input request data - size: 24 bytes */
typedef struct city_req_rec
{
   char rtype[2];     /* Possible values: "OR", "VI", "DT". */
   char city[18];     /* City name, SPLC, user conversion name or ZIP */
   char county[2];    /* County qualifier - ONLY IF NEEDED */
   char state[2];     /* State abbreviation */
} CITY_REQ_RECORD;

/* To read in a header record - size: 24 bytes */
typedef struct header_req_rec
{
   char header_type[2];   /* Should contain "HR" for this record */
   char request_type[2];  /* Request type for the cities to follow */
   char dest_city_num[2]; /* Destination city number in "OP" requests */
   char user_info[18];    /* User supplied information as desired */
} HEADER_REQ_RECORD;

/* The next structure is to read a complete request - size: 360 bytes */
typedef struct request
{
   union
   {
      char header_rec[24];
      HEADER_REQ_RECORD header;  /* Header record */
   } u_header;

   CITY_REQ_RECORD stopoff[MAX_CITIES + 1]; /* All city names */
} REQ_RECORDS;
