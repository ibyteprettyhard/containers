/****************************************************************/
/* Version: 16.2                                           */
/* File   : multi_user.h                                           */
/* Changed: 5/28/97                                           */
/****************************************************************/


/* This header file is used solely for the msgsnd() and msgrcv() between */
/* the milemaker process and the interface process (intf_onlin).         */
typedef struct multi_answer
{
    char a_ws_addr[5];
    union
    {
	char c_user_seq_num[6];
	long n_user_seq_num;        /* numeric field */
    } u_user_seq;
    union
    {
	char c_seq_num[4];
	short n_seq_num;              /*numeric field */
	/* SHORT -> INT FOR TECHLAND TESTING ?? */
    } u_seq;
    union
    {
	char c_rel_rec_num[6];
	long n_rel_rec_num;         /* numeric field */
    } u_rec_num;
    union
    {
	char c_req_type[3];
	short n_req_type;
    } u_req_type;
    union 
    {
	char c_err_code[3];
	short  n_err_code;   	/* SHORT -> INT FOR TECHLAND TESTING ?? */
    } u_err_code;
    union
    {
	struct ans_main_rec
	{
	    char c_req_city_1[19];
	    char c_req_cty_1[4];
	    char c_req_st_1[3];
	    char c_req_city_2[19];
	    char c_req_cty_2[4];
	    char c_req_st_2[3];
	    union
	    {
		char c_tot_mile[6];
		long n_tot_mile;                 /*numeric field */
	    } u_tot_mile;
	    union
	    {
		char c_toll[6];
		long n_toll;                     /* numeric field */
	    } u_toll;
	    union
	    {
		char c_non_toll[6];
		long n_non_toll;                 /* numeric field */
	    } u_non_toll;
	    char filler[39];
	} main;

	struct state_breakdown
	{ 
	    /***** FIRST STATE INFORMATION ******/
	    char st_1[3];
	    union
	    {
		char c_st_tot_1[6];
		long n_st_tot_1;
	    } u_st_tot_1;
	    union
	    {
		char c_toll_1[6];
		long n_toll_1;
	    } u_toll_1;
	    union
	    {
		char c_non_toll_1[6];
		long n_non_toll_1;
	    } u_non_toll_1;

	    /***** SECOND STATE INFORMATION ******/
	    char st_2[3];
	    union
	    {
		char c_st_tot_2[6];
		long n_st_tot_2;
	    } u_st_tot_2;
	    union
	    {
		char c_toll_2[6];
		long n_toll_2;
	    } u_toll_2;
	    union
	    {
		char c_non_toll_2[6];
		long n_non_toll_2;
	    } u_non_toll_2;

	    /***** THIRD STATE INFORMATION *****/
	    char st_3[3];
	    union
	    {
		char c_st_tot_3[6];
		long n_st_tot_3;
	    } u_st_tot_3;
	    union
	    {
		char c_toll_3[6];
		long n_toll_3;
	    } u_toll_3;
	    union
	    {
		char c_non_toll_3[6];
		long n_non_toll_3;
	    } u_non_toll_3;

	    /****** FOURTH STATE INFORMATION *****/
	    char st_4[3];
	    union
	    {
		char c_st_tot_4[6];
		long n_st_tot_4;
	    } u_st_tot_4;
	    union
	    {
		char c_toll_4[6];
		long n_toll_4;
	    } u_toll_4;
	    union
	    {
		char c_non_toll_4[6];
		long n_non_toll_4;
	    } u_non_toll_4;

	    /****** FIFTH STATE INFORMATION *****/
	    char st_5[3];
	    union
	    {
		char c_st_tot_5[6];
		long n_st_tot_5;
	    } u_st_tot_5;
	    union
	    {
		char c_toll_5[6];
		long n_toll_5;
	    } u_toll_5;
	    union
	    {
		char c_non_toll_5[6];
		long n_non_toll_5;
	    } u_non_toll_5;
	    char filler[15];
	} st_brk;

	struct rte_line
	{
	    char hwy[17];
	    char dir[3];
	    union
	    {
		char c_miles[6];
		long n_miles;
	    } u_miles;
	    char to_loc[29];
	    char acc_time[7];
	    union
	    {
		char c_acc_miles[6];
		long n_acc_miles;
	    } u_acc_miles;
	    char notes[10];
	    char filler[29];
	} rte;
    } a_u;
} MULTI_ANSWER;

typedef struct multi_ans_msg_buf
{
    long mtype;
    union
    {
	MULTI_ANSWER ans;
	char msg_buf[sizeof(struct multi_answer)];
    } msg_u; 
} MULTI_ANS_MSG_BUF;
