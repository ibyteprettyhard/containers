/****************************************************************/
/* Version: 17.3                                           */
/* File   : nettype.h                                           */
/* Changed: 6/23/97                                           */
/****************************************************************/

/***********************************************************************
* Header Name :   nettype.h
*
* Description :   This is a header file broken out of network.h
*  so that the router can include this only.
*
* History :
*
*     Name    Date   Description
*   ----------------  ----------   -------------------------------------
*   John McCloskey        11/05/88
*   Louis London           7/28/95 Change num_chg_elements for     V1.1
*                                  alignment
*   Louis London          1/10/02  Guide 18 changes                V1.2
*   Louis London          3/4/08   Practical Zero Miles Processing V1.3
***********************************************************************/
#ifdef AIX
#define BIGENDIAN
#endif
#ifdef HPUX
#define BIGENDIAN
#endif
#ifdef SOLARIS
#define BIGENDIAN
#endif
#ifdef LINUXBIG
#define BIGENDIAN
#endif
#ifdef SCO
#define LITTLEENDIAN
#endif
#ifdef LINUX
#define LITTLEENDIAN
#endif

/** typedefs **/

#ifdef BIGENDIAN
typedef struct /* node_base_flags V1.5 */  /* LJL - AIX 2-26 */
{
   unsigned           nt_f_jct_dir:3; /* junction direction (0-7)  */
   unsigned           nt_f_2ary:1;    /* secondary node            */
   unsigned           nt_f_jct:1;     /* junction only             */
   unsigned           nt_f_st_bx:1;   /* state border point        */
   unsigned           nt_f_natl_bx:1; /* national border point     */
   unsigned           nt_f_hhg:1;     /* HHG keypoint              */
   unsigned           nt_legs:8;     /* # of NT_SEGMENT_ENTRYs    */
   unsigned           nt_page:16;
} NODE_FLAGS;
#else
typedef struct /* node_base_flags V1.5 */  /* LJL - AIX 2-26 */
{
   unsigned           nt_page:16;
   unsigned           nt_legs:8;     /* # of NT_SEGMENT_ENTRYs    */
   unsigned           nt_f_hhg:1;     /* HHG keypoint              */
   unsigned           nt_f_natl_bx:1; /* national border point     */
   unsigned           nt_f_st_bx:1;   /* state border point        */
   unsigned           nt_f_jct:1;     /* junction only             */
   unsigned           nt_f_2ary:1;    /* secondary node            */
   unsigned           nt_f_jct_dir:3; /* junction direction (0-7)  */
} NODE_FLAGS;
#endif

typedef union    /* GDB V1.3 */
{
   NODE_FLAGS         nu_flags;        /* node flags bit fields     */
   unsigned           nu_value;        /* node flags numeric value  */
} NODE_FLAGS_UNION;


#ifdef BIGENDIAN
typedef struct segment_penalties
{
unsigned nts_unassigned:5; /* first 4 bits not used     */
unsigned nts_pen_bx:1; /* border crossing           */
unsigned nts_pen_gb:1; /* green_band       */
unsigned nts_pen_cu:1; /* county unusable           */
unsigned nts_miles:8;  /* whole miles               */
} SEG_PENALTIES;

typedef struct /* nts_values V1.10 */ /* LJL AIX 2-26 */
{
   unsigned char       filler;
   unsigned char       nts_penalty; /* penalties                 */
   unsigned char       nts_miles[4];
   unsigned short      nts_time;    /* time (minutes/100) GDB V1.8 was short */
} NETWORK_VALS;

typedef struct /* ntp_values V1.10 */ /* LJL AIX 2-26 */
{
   unsigned char       filler;
   unsigned char       ntp_penalty;     /* penalties                 */
   unsigned char       ntp_time[2];     /* time (minutes/100)        */
   unsigned long       ntp_miles;
} NETWORK_PRAC;
#else
typedef struct segment_penalties
{
unsigned nts_miles:8;  /* whole miles               */
unsigned nts_pen_cu:1; /* county unusable           */
unsigned nts_pen_gb:1; /* green_band       */
unsigned nts_pen_bx:1; /* border crossing           */
unsigned nts_unassigned:5; /* first 4 bits not used     */
} SEG_PENALTIES;

typedef struct /* nts_values V1.10 */ /* LJL AIX 2-26 */
{
   unsigned short      nts_time;    /* time (minutes/100) GDB V1.8 was short */
   unsigned char       nts_miles[4];
   unsigned char       nts_penalty; /* penalties                 */
   unsigned char       filler;
} NETWORK_VALS;

typedef struct /* ntp_values V1.10 */ /* LJL AIX 2-26 */
{
   unsigned long       ntp_miles;
   unsigned char       ntp_time[2];     /* time (minutes/100)        */
   unsigned char       ntp_penalty;     /* penalties                 */
   unsigned char       filler;
} NETWORK_PRAC;
#endif

typedef union /* router_union V1.10 */
{
   unsigned long long nt_best;       /* best value                  */
   NETWORK_VALS       nts_vals;      /* penalties, whole miles, time*/
   NETWORK_PRAC       ntp_vals;      /* penalties, time, miles      */
} RT_UNION;

typedef struct node_base
{
   RT_UNION           nt_best_val; /* best value - initially splc*/
   /*                                 GDB V1.9 formerly RT_UNION */
   struct node_base  *nt_next_ptr; /* pointer to next node on route*/
   NODE_FLAGS        nt_flags;     /* node flags - GDB V1.3    */
   long             nt_loc_id;     /* location id-geo relative rec#*/
   long               nt_entry_len;/* entry length    */
   /*                                 changed from NODE_FLAGS */
} NODE_BASE;

typedef union change_elements /* used by orig/dest to set   */
{    /* up the change list         */
   struct nts_chg_ptrs
   {
      NODE_BASE **nts_ptr_to_ptr;
      NODE_BASE *nts_old_ptr;
      NODE_BASE *nts_new_ptr;
   } nts_ptr_struct;

   struct nts_chg_vals
   {
      long nts_chg_val_1;
      long nts_chg_val_2;
      long  nts_chg_val_3;
   } nts_chg_struct;
} CHG_ELEMENTS;


typedef struct change_list
{
   long  num_chg_elements;  /* V1.1 */
   CHG_ELEMENTS a_chg_element[1];
} CHG_LIST_STRUCT;


#ifdef BIGENDIAN
typedef struct /* LJL - AIX 2-26 */
{
   unsigned    reserved_flags:4; /* reserved, dynamic flags   */
   unsigned    file_synch:1;     /* file synch, to be defined */
   unsigned    mile_dup:1;       /* mileage duplexed          */
   unsigned    full_dup:1;       /* fully duplexed            */
   unsigned    jct_sum:1;        /* junction summarization    */
   unsigned    ntp_format:8;     /* network format code       */
} PREFIX_FLAGS;
#else
typedef struct /* LJL - AIX 2-26 */
{
   unsigned    ntp_format:8;     /* KJK - AT&T  */
   unsigned    jct_sum:1;        /* KJK - AT&T  */
   unsigned    full_dup:1;       /* KJK - AT&T  */
   unsigned    mile_dup:1;       /* KJK - AT&T  */
   unsigned    file_synch:1;     /* KJK - AT&T  */
   unsigned    reserved_flags:4; /* KJK - AT&T  */
} PREFIX_FLAGS;
#endif

typedef struct start_net
{
   short s_num[2];                  /* s_num[0] = start window of*/
} START_NET;                           /* network windows GDB V1.8  */

typedef struct
{
   long      ntp_net_len;          /* network table length GDB V1.8 */
   long      ntp_tot_len;          /* total length(net+hwy tables) GDB V1.8 */
   char      *ntp_alias_ptr_1;     /* alias hwy codes pointer (area 1)*/
   char      *ntp_alias_ptr_2;     /* alias hwy codes pointer (area 2)*/
   char      *ntp_hwy_names_ptr_1; /* hwy names table ptr (area 1)*/
   char      *ntp_hwy_names_ptr_2; /* hwy names table ptr (area 2)*/
   char      *ntp_hwy_names_ptr_3; /* hwy names table ptr (area 3)*/
   char      *ntp_hwy_names_ptr_4; /* hwy names table ptr (area 4)*/
   char      *ntp_hwy_names_ptr_5; /* hwy names table ptr (area 5)*/
   char      *ntp_hwy_names_ptr_6; /* hwy names table ptr (area 6)*/
   char      *ntp_hwy_names_ptr_7; /* hwy names table ptr (area 7) V1.19 */
   char      *ntp_hwy_names_ptr_8; /* hwy names table ptr (area 8) V1.19 */
   START_NET n_ptr;                /* network pointer union      */
   short     ntp_flags;            /* network flags GDB V1.4 (not used) */
   short     ntp_key;              /* network key (not used) GDB V1.8 */
   short     ntp_rec_len;          /* record length  GDB V1.8       */
   short     ntp_window_len;       /* window length GDB V1.8        */
   short     ntp_alias_no_1;       /* number of alias entries (area 1)*/
   short     ntp_alias_no_2;       /* number of alias entries (area 2)*/
   short     ntp_hwy_names_no_1;   /* # of hwy name entries (area 1) */
   short     ntp_hwy_names_no_2;   /* # of hwy name entries (area 2)*/
   short     ntp_hwy_names_no_3;   /* # of hwy name entries (area 3)*/
   short     ntp_hwy_names_no_4;   /* # of hwy name entries (area 4)*/
   short     ntp_hwy_names_no_5;   /* # of hwy name entries (area 5)*/
   short     ntp_hwy_names_no_6;   /* # of hwy name entries (area 6)*/
   short     ntp_hwy_names_no_7;   /* # of hwy name entries (area 7) V1.19*/
   short     ntp_hwy_names_no_8;   /* # of hwy name entries (area 8) V1.19 */
   char      ntp_name[32];         /* network name               */
   char      ntp_date[32];         /* date created (yy-80 ddd) and time */
} NETWORK_PREFIX;

/* changed unsigned shorts to unsigned for GDB  V1.7 */
#ifdef BIGENDIAN
typedef union /* hwy_bits V1.10 */
{
   struct /* rt_file_recs V1.10 */ /* LJL - AIX 2-26 */
   {
      unsigned         nts_first_rec:13;   /* relative no. of first rec */
      unsigned         nts_rt_recs:3;      /* no. of route_file records */
      unsigned         filler1:16;
   } nts_hwy_bits_0;

   struct /* hwy_hi_bit_on V1.10 */ /* LJL - AIX 2-26 */
   {
      unsigned  nts_hwy_no:10;     /* highway number(1-1023) */
      unsigned  nts_hwy_class:3;   /* classification (0-7)   */
      unsigned  nts_hwy_br:1;      /* business route         */
      unsigned  nts_hwy_st:1;
      unsigned  nts_hwy_num:1;
      unsigned  filler2:16;
   } nts_hwy_bits_1;

   struct /* hwy_hi_bit_off V1.10 */ /* LJL - AIX 2-26 */
   {
      unsigned  nts_element_num:14;    /* element number   */
      unsigned  nts_hwy_st:1;
      unsigned  nts_hwy_num:1;
      unsigned  filler3:16;
   } nts_hwy_bits_2;

   unsigned            nts_hwy_bits_3;
} NTS_HWY_BITS;

typedef union /* hwy_bits V1.10 */
{
   struct /* rt_file_recs V1.10 */ /* LJL - AIX 2-26 */
   {
      unsigned         nts_first_rec:13;   /* relative no. of first rec */
      unsigned         nts_rt_recs:3;      /* no. of route_file records */
      unsigned         filler1:16;
   } nts_hwy_bits_0;

   struct /* hwy_hi_bit_on V1.10 */ /* LJL - AIX 2-26 */
   {
      unsigned  nts_hwy_no:10;     /* highway number(1-1023) */
      unsigned  nts_hwy_class:3;   /* classification (0-7)   */
      unsigned  nts_hwy_br:1;      /* business route         */
      unsigned  nts_hwy_st:1;
      unsigned  nts_hwy_num:1;
      unsigned  filler2:16;
   } nts_hwy_bits_1;

   struct /* hwy_hi_bit_off V1.10 */ /* LJL - AIX 2-26 */
   {
      unsigned  nts_element_num:14;    /* element number   */
      unsigned  nts_hwy_st:1;
      unsigned  nts_hwy_num:1;
      unsigned  filler3:16;
   } nts_hwy_bits_2;

   struct segment_flags
   {
	    unsigned    filler:16;
        unsigned    nts_trav_state:8;       /* state traveled*/
        unsigned 	nts_f_dir:3;	/* direction, 0-7 clockwise  */
        unsigned 	nts_f_limit:1;		/* limit    */
        unsigned 	nts_f_tunnel:1;		/* tunnel   */
        unsigned  	nts_f_bridge:1;		/* bridge   */
        unsigned 	nts_f_ferry:1;		/* ferry    */
        unsigned 	nts_f_toll:1;		/* toll     */
   } seg_flgs;

   struct segment_combine
   {
	    unsigned    filler:16;
        unsigned    seg_filler:12;  /* last twelve bits - unused */
        unsigned    seg_fl:4;	/* first four bits combined  */
   } seg_flgs_4;

   struct hwy_segment
   {
        unsigned short nts_hwy_bits_3;
        unsigned short seg_flgs_i;
   } hwy_seg_flgs;

   unsigned            nts_hwy_seg_bits;

} NTS_HWY_SEG_BITS;

/* changed unsigned shorts to unsigned for GDB  V1.6 */
typedef struct /* LJL - AIX 2-26 */
{
   unsigned      corp_area:13;       /* corporate area */
   unsigned      corp_reserved:2;    /* reserved for future use*/
   unsigned      corp_pres:1;        /* corporate area present*/
} CORP_AREA_NUM;

typedef union    /* GDB V1.6 */
{
   CORP_AREA_NUM      ca_flags;        /* corp flags bit fields     */
   unsigned           ca_value;        /* corp flags numeric value  */
} CORP_AREA_UNION;

/* changed unsigned shorts to unsigned for GDB  V1.5 */
typedef union /* seg_union V1.10 */
{
   struct /* segment_flags V1.10 */ /* LJL AIX 2-26 */
   {
      unsigned  nts_trav_state:8;       /* state traveled*/
      unsigned  nts_f_dir:3;            /* direction, 0-7 clockwise  */
      unsigned  nts_f_limit:1;          /* limit    */
      unsigned  nts_f_tunnel:1;         /* tunnel   */
      unsigned  nts_f_bridge:1;         /* bridge   */
      unsigned  nts_f_ferry:1;          /* ferry    */
      unsigned  nts_f_toll:1;           /* toll     */
   } seg_flgs;

   struct /* segment_combine V1.10 */ /* LJL AIX 2-26 */
   {
      unsigned        seg_filler:12;  /* last twelve bits - unused */
      unsigned        seg_fl:4;       /* first four bits combined  */
   } seg_flgs_4;

   unsigned seg_flgs_i;
} SEG_FLAGS;

typedef union /* seg_union V1.10 */
{
   struct /* segment_flags V1.10 */ /* LJL AIX 2-26 */
   {
      unsigned  corp_area:13;           /* corporate area */
      unsigned  corp_reserved:2;        /* reserved for future use*/
      unsigned  corp_pres:1;            /* corporate area present*/
      unsigned  nts_trav_state:8;       /* state traveled*/
      unsigned  nts_f_dir:3;            /* direction, 0-7 clockwise  */
      unsigned  nts_f_limit:1;          /* limit    */
      unsigned  nts_f_tunnel:1;         /* tunnel   */
      unsigned  nts_f_bridge:1;         /* bridge   */
      unsigned  nts_f_ferry:1;          /* ferry    */
      unsigned  nts_f_toll:1;           /* toll     */
   } corp_seg_flgs;

   struct /* segment_combine V1.10 */ /* LJL AIX 2-26 */
   {
      unsigned        seg_filler2:16;
      unsigned        seg_filler:12;  /* last twelve bits - unused */
      unsigned        seg_fl:4;       /* first four bits combined  */
   } seg_flgs_4;

   unsigned seg_flgs_i;
} CORP_SEG_FLAGS;
#else
typedef union /* hwy_bits V1.10 */
{
   struct /* rt_file_recs V1.10 */ /* LJL - AIX 2-26 */
   {
      unsigned nts_rt_recs:3;    /* KJK - AT&T */
      unsigned nts_first_rec:13; /* KJK - AT&T */
      unsigned filler1:16;       /* KJK - AT&T, unchanged */
   } nts_hwy_bits_0;

   struct /* hwy_hi_bit_on V1.10 */ /* LJL - AIX 2-26 */
   {
      unsigned  nts_hwy_num:1;     /* KJK - AT&T */
      unsigned  nts_hwy_st:1;      /* KJK - AT&T */
      unsigned  nts_hwy_br:1;      /* KJK - AT&T */
      unsigned  nts_hwy_class:3;   /* KJK - AT&T */
      unsigned  nts_hwy_no:10;     /* KJK - AT&T */
      unsigned  filler2:16;        /* KJK - AT&T, unchanged */
   } nts_hwy_bits_1;

   struct /* hwy_hi_bit_off V1.10 */ /* LJL - AIX 2-26 */
   {
      unsigned  nts_hwy_num:1;         /* KJK - AT&T */
      unsigned  nts_hwy_st:1;          /* KJK - AT&T */
      unsigned  nts_element_num:14;    /* KJK - AT&T */
      unsigned  filler3:16;            /* KJK - AT&T, unchanged */
   } nts_hwy_bits_2;

   unsigned            nts_hwy_bits_3;
} NTS_HWY_BITS;

typedef union /* hwy_bits V1.10 */
{
   struct /* rt_file_recs V1.10 */ /* LJL - AIX 2-26 */
   {
      unsigned         nts_rt_recs:3;      /* no. of route_file records */
      unsigned         nts_first_rec:13;   /* relative no. of first rec */
      unsigned         filler1:16;
   } nts_hwy_bits_0;

   struct /* hwy_hi_bit_on V1.10 */ /* LJL - AIX 2-26 */
   {
      unsigned  nts_hwy_num:1;
      unsigned  nts_hwy_st:1;
      unsigned  nts_hwy_br:1;      /* business route         */
      unsigned  nts_hwy_class:3;   /* classification (0-7)   */
      unsigned  nts_hwy_no:10;     /* highway number(1-1023) */
      unsigned  filler2:16;
   } nts_hwy_bits_1;

   struct /* hwy_hi_bit_off V1.10 */ /* LJL - AIX 2-26 */
   {
      unsigned  nts_hwy_num:1;
      unsigned  nts_hwy_st:1;
      unsigned  nts_element_num:14;    /* element number   */
      unsigned  filler3:16;
   } nts_hwy_bits_2;

   struct segment_flags
   {
	unsigned    filler:16;
        unsigned 	nts_f_toll:1;		/* toll     */
        unsigned 	nts_f_ferry:1;		/* ferry    */
        unsigned  	nts_f_bridge:1;		/* bridge   */
        unsigned 	nts_f_tunnel:1;		/* tunnel   */
        unsigned 	nts_f_limit:1;		/* limit    */
        unsigned 	nts_f_dir:3;	/* direction, 0-7 clockwise  */
        unsigned    nts_trav_state:8;       /* state traveled*/
   } seg_flgs;

   struct segment_combine
   {
        unsigned    filler:16;
        unsigned    seg_fl:4;	/* first four bits combined  */
        unsigned    seg_filler:12;  /* last twelve bits - unused */
   } seg_flgs_4;

   struct hwy_segment
   {
        unsigned short nts_hwy_bits_3;
        unsigned short seg_flgs_i;
   } hwy_seg_flgs;

   unsigned            nts_hwy_seg_bits;

} NTS_HWY_SEG_BITS;

typedef struct /* LJL - AIX 2-26 */
{
   unsigned      corp_pres:1;        /* corporate area present*/
   unsigned      corp_reserved:2;    /* reserved for future use*/
   unsigned      corp_area:13;       /* corporate area */
} CORP_AREA_NUM;

typedef union /* seg_union V1.10 */
{
   struct /* segment_flags V1.10 */ /* LJL AIX 2-26 */
   {
      unsigned  nts_f_toll:1;           /* KJK - AT&T */
      unsigned  nts_f_ferry:1;          /* KJK - AT&T */
      unsigned  nts_f_bridge:1;         /* KJK - AT&T */
      unsigned  nts_f_tunnel:1;         /* KJK - AT&T */
      unsigned  nts_f_limit:1;          /* KJK - AT&T */
      unsigned  nts_f_dir:3;            /* KJK - AT&T */
      unsigned  nts_trav_state:8;       /* KJK - AT&T */
   } seg_flgs;

   struct /* segment_combine V1.10 */ /* LJL AIX 2-26 */
   {
      unsigned       seg_fl:4;        /* KJK - AT&T   */
      unsigned       seg_filler:12;   /* KJK - AT&T   */
   } seg_flgs_4;

   unsigned seg_flgs_i;
} SEG_FLAGS;

typedef union /* seg_union V1.10 */
{
   struct /* segment_flags V1.10 */ /* LJL AIX 2-26 */
   {
        unsigned  corp_pres:1;               /* KJK - AT&T */ 
        unsigned  corp_reserved:2;           /* KJK - AT&T */
        unsigned  corp_area:13;              /* KJK - AT&T */
        unsigned  nts_f_toll:1;              /* KJK - AT&T */ 
        unsigned  nts_f_ferry:1;             /* KJK - AT&T */
        unsigned  nts_f_bridge:1;            /* KJK - AT&T */
        unsigned  nts_f_tunnel:1;            /* KJK - AT&T */
        unsigned  nts_f_limit:1;             /* KJK - AT&T */
        unsigned  nts_f_dir:3;               /* KJK - AT&T */
        unsigned  nts_trav_state:8;          /* KJK - AT&T */
   } corp_seg_flgs;

   struct /* segment_combine V1.10 */ /* LJL AIX 2-26 */
   {
      unsigned      seg_filler2:16; /* KJK - AT&T */
      unsigned      seg_fl:4;       /* KJK - AT&T */
      unsigned      seg_filler:12;  /* KJK - AT&T */
   } seg_flgs_4;

   unsigned seg_flgs_i;
} CORP_SEG_FLAGS;
#endif


typedef struct
{
   RT_UNION      nts_seg_vals;    /* penalties, whole miles, time */
   RT_UNION      ntp_seg_vals;    /* penalties, whole miles, time */
   NODE_BASE    *nts_to_ptr;      /* to node pointer              */
   long          segid;
   NTS_HWY_SEG_BITS  nts_hwy;         /* highway code - see above typedef*/
   unsigned short nts_tollcost;
   char filler[2];
} NT_SEGMENT_ENTRY;

typedef struct
{
   NODE_BASE    *nts_to_ptr;/* to node pointer              */
   RT_UNION      nts_seg_vals; /* penalties, whole miles, time */
   NTS_HWY_BITS  nts_hwy; /* highway code - see above typedef*/
   CORP_SEG_FLAGS nts_corp_flags;/* corporate area number        */
   short nts_long;   /* longitude of network point      */
   short nts_lat;    /* latitude  of network point      */
} SC_SEGMILE_ENTRY; /* V1.2 */

typedef struct
{
   unsigned char nts_nd_flag;   /* junction direction           */
   char          nts_loc_id[3]; /* geo id for this sec loc      */
   long          nts_splc;   /* splc of interim point-sec.   */
   RT_UNION      nts_seg_vals;  /* penalties, whole miles, time */
   NTS_HWY_BITS  nts_hwy;         /* highway code - see above typedef*/
   CORP_SEG_FLAGS nts_corp_flags; /* corporate area number        */
} SC_SEGRTE_ENTRY;

typedef struct secondary_segment
{
   NT_SEGMENT_ENTRY sec_seg_entry;
   short               sec_pt_long; /* secondary point's longitude*/
   short  sec_pt_lat; /* secondary point's latitude */
} SEC_SEGMENT_ENTRY;

typedef struct secondary_base
{
   NODE_BASE  *base_ptr;
   short  dummy_1;
   short   dummy_2;
} SEC_BASE;

typedef union base_seg_area
{
   NODE_BASE  *nt_base_ptr;
   NT_SEGMENT_ENTRY *nts_seg_ptr;
} BASE_OR_SEGMENT;

typedef struct network_table
{
   NETWORK_PREFIX ntp_prefix_area;
   BASE_OR_SEGMENT     base_seg;
} NETWORK_TABLE;

typedef union input_secondary_tbl
{
   /* some kind of prefix area needed here */
   SEC_BASE  *sec_base_ptr;
   SEC_SEGMENT_ENTRY *sec_seg_ptr;
} INPUT_SEC_TABLE;

typedef struct setup_secondary_tbl
{
   /* some kind of prefix area needed here */
   BASE_OR_SEGMENT     base_seg;
} SETUP_SEC_TABLE;

typedef struct calc_sec_pt_info {
   int    calc_miles;  /* miles returned from calc function */
   char    *malloc_net_ptr; /* ptr to malloc area if point is a  */
   /* secondary point, and to network if*/
   /* point is a network or calc point  */
   CHG_LIST_STRUCT *chg_list_ptr;  /* ptr to clist area in memory */
} CALC_SEC_INFO;

typedef struct opt_interface {
   short     ncity;  /* number of cities         */
   long     tourtype;  /* type of tour :           */
   /*   0 = open jaw tour   */
   /*     -1 = closed tour    */
   /*   >0 = destination val_code*/
   /* intercity distance matrix  */
   double     dist[NUM_IN_LINES][NUM_IN_LINES];
   /* value codes ordered      */
   long     val_codes[NUM_IN_LINES];
   long      return_code; /* return code             */
} TRAVEL;

typedef struct router_pointers {
   char *mal_net_ptr; /* points to malloc area or network  */
   CHG_LIST_STRUCT *c_list_ptr;  /* point to change list if 2ndary pt */
} ROUTER_PTRS;

typedef struct rt_seg_tbl {
   struct rt_seg_tbl *rt_pt_next;    /* ptr to next rt_seg_tbl     */
   long    rt_loc_id;/* Change for Guide 17 LJL 8-28-96   */
   char    rt_flags; /* node flags-see above NODE_FLAGS */
   CORP_SEG_FLAGS rts_flags;/* Change for Guide 17 LJL 8-28-96 */
   long    rts_mi; /* route segment miles        */
   long    rts_time; /* route segment time(min/100)*/
   NTS_HWY_BITS  rts_hwy; /* Change for Guide 17 LJL 8-28-96 */
   char          st_bx_flag;   /* Add for state border crossings LJL 8-26-96 */
   unsigned char from_state;   /* Add for state border crossings LJL 8-26-96 */
   unsigned char to_state;     /*  Add for state border crossings LJL 8-26-96 */
#ifdef ZEROMILES
   char          display_direction; /* V1.3 */
#endif
} RT_SG_TB;

typedef struct router_int_array {
   ROUTER_PTRS     rt_ptrs; /* malloc/network and chg list ptrs  */
   long      rout_tot_miles; /* mileage returned from the router  */
   RT_SG_TB        *sg_ptr;    /* ptr to rt_seg_tbl                 */
   short           cnt_sg;     /* number of segs in rt_seg_tbl      */
} ROUTER_ARRAY;

typedef struct router_interface {
   char    rt_rqst_type; /* no(N), only(O), or both(B)        */
   char    rt_st_miles; /* mileage(M), origin(O), audit(A)   */
   /* practical(P), or short(S)         */
   char    rt_rules_on; /* yes(Y) or no(NO)                  */
   ROUTER_PTRS   rt_pt_1_info; /* info about first point in pair    */
   short    num_rt_pts;  /* number of elements in array       */
   ROUTER_ARRAY    rt_pt_info[NUM_IN_LINES];
} RT_INTERFACE;

typedef struct loc_key_struct
{
   char mi020d_last_longitude[4];  /* GDB V1.14 */
   char mi020d_last_latitude[4];  /* GDB V1.14 */
} LOCATOR_REC_KEY;

typedef struct loc_table
{
   char mi020d_longitude[4];  /* GDB V1.14 */
   char mi020d_latitude[4];  /* GDB V1.14 */
   char mi020d_internal_key[4];  /* GDB V1.14 */
} LOCATOR_TABLE;


typedef struct locator_struct {
   LOCATOR_REC_KEY loc_rec_key;
   LOCATOR_TABLE   mi020d_table[145];
} LOCATOR_RECORD;

typedef struct rdl_lines
{
   char   disp_hwy[18];
   char   disp_dir[4];
   char   disp_miles[7];
   char   disp_to_locn[28];
   char   disp_acc_time[8];
   char   disp_acc_miles[7];
   char   disp_notes[11];
   char   disp_hilite;
} ROUTE_DISP_LINES;
