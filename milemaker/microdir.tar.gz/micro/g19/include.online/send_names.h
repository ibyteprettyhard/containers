/****************************************************************/
/* Version: 16.2                                           */
/* File   : send_names.h                                           */
/* Changed: 5/28/97                                           */
/****************************************************************/


/* This include file contains constants and structures that */
/* are used for the names transfer utility provided by the  */
/* Micro MileMaker interface enhancements project.  They    */
/* were taken from Rick Christiansens send_names.c file on  */
/* 12/11/90.  Additional constants and structures that were */
/* in that source file were removed in favor of referencing */
/* other header files that already defined such structures. */

#define AUX		1	/* Next record for host is from geo aux file */
#define COMMA_POSITION	15
#define END_ANS		"H0"
#define END_CHAR	'#'
#define GEO		0	/* Next record for host is from geo file */
#define LINE_FEED	'\n'
#define MORE_ANS	"H1"

typedef struct output_record
{  /* This stucture is 31 bytes */
   char st[2];
   char city[18];
   char cnty[2];
   char splc[9];
} OUTPUT_RECORD;

typedef struct twin_scrn
{  /* This stucture is 1919 bytes */
   char filler1[2];
   char comm_parm[2];
   OUTPUT_RECORD name_rec[61];	/* # names recs/IBM Midrange response */
   char filler2[24];
} TWIN_SCRN;
